# Security Specification (`security_spec.md`)

## 1. Data Invariants
1. **Strict Multi-Tenant Ownership Isolation**: Every document in `/colleges/{collegeId}`, `/courses/{courseId}`, `/fee_documents/{docId}`, and `/enquiries/{enquiryId}` must have a `userId` matching `request.auth.uid`. Unauthenticated callers and cross-user callers are strictly rejected on all `get`, `list`, `create`, `update`, and `delete` operations.
2. **Immutable Identity & Creation Metadata**: On `update`, `userId` and `createdAt` must strictly equal `resource.data.userId` and `resource.data.createdAt`.
3. **Path Variable Hardening**: Every single-document operation (`get`, `create`, `update`, `delete`) must validate the document ID via `isValidId(id)` (`^[a-zA-Z0-9_\-]+$`, max 128 chars).
4. **Strict Schema & Enum Validation**: Every `create` and `update` rule must invoke `isValidCollege`, `isValidCourse`, `isValidFeeDocument`, or `isValidEnquiry` and enforce `hasAll` / `hasOnly` key allowlists and string/list `.size()` boundaries.
5. **Query Enforcement on List**: Every `allow list` rule explicitly enforces `isSignedIn() && resource.data.userId == request.auth.uid`, requiring client queries to filter with `.whereEqualTo("userId", uid)`.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Read/List**: `unauthenticatedContext().firestore().collection("colleges").get()` -> Rejects (`request.auth != null`).
2. **Cross-User Read (`get`)**: User `alice_123` reading `bob_456`'s college document -> Rejects (`existing().userId == request.auth.uid`).
3. **Unfiltered List Query**: User `alice_123` querying `collection("colleges")` without `.where("userId", "==", "alice_123")` -> Rejects (`resource.data.userId == request.auth.uid`).
4. **Identity Spoofing on Create**: User `alice_123` creating a college with `userId: "bob_456"` -> Rejects (`incoming().userId == request.auth.uid`).
5. **Shadow Update / Ghost Field Injection**: Updating a college with an undeclared field `isSuperAdmin: true` -> Rejects (`affectedKeys().hasOnly(...)`).
6. **Ownership Transfer Attack**: Updating `userId` on an existing document to another UID -> Rejects (`incoming().userId == existing().userId`).
7. **Creation Timestamp Tampering**: Modifying `createdAt` during an update -> Rejects (`incoming().createdAt == existing().createdAt`).
8. **Future Timestamp Spoofing**: Submitting `createdAt` in the future (`> request.time`) -> Rejects (`incoming().createdAt <= request.time`).
9. **Enum Poisoning**: Setting `ownership: "IllegalCategory"` or `verificationStatus: "Hacked"` -> Rejects (enum allowlist check).
10. **Denial-of-Wallet String Overflow**: Submitting a 10,000-character string into `name` -> Rejects (`data.name.size() <= 200`).
11. **Unbounded Array Injection**: Submitting 50 elements in `regulators` or `entranceExams` -> Rejects (`size() <= 12` / `size() <= 10`).
12. **Document ID Poisoning**: Creating a document with invalid characters or >128 length ID -> Rejects (`isValidId(id)`).
