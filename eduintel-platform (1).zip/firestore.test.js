const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validCollegePayload(userId, now) {
  return {
    userId,
    name: "Kasturba Medical College Manipal",
    shortCode: "KMC-MPL",
    state: "Karnataka",
    city: "Manipal",
    ownership: "Private Unaided",
    institutionType: "Deemed-to-be University",
    degreeAwardingUniversity: "Manipal Academy of Higher Education (MAHE)",
    affiliatedTo: "MAHE Constituent",
    establishedYear: 1953,
    websiteUrl: "https://manipal.edu/kmc-manipal.html",
    verificationStatus: "Verified",
    naacGrade: "A++",
    naacCgpa: 3.65,
    nirfRank: 9,
    regulators: ["UGC", "NMC", "NAAC"],
    regulatorDetailsSummary: "NMC recognized 250 MBBS seats; NAAC A++ valid through 2028",
    needsRefresh: false,
    isDemo: true,
    createdAt: now,
    updatedAt: now,
  };
}

function validSourceQueuePayload(userId, now) {
  return {
    userId,
    collegeId: "demo_col_kmc",
    collegeName: "Kasturba Medical College Manipal",
    courseName: "MBBS",
    researchTarget: "Check NIRF/NAAC Accreditation",
    fieldKey: "regulatorDetailsSummary",
    previousValue: "NMC 250 MBBS seats",
    extractedValue: "NIRF Rank #9 Medical, NMC 250 seats verified",
    hasContradiction: false,
    contradictionNote: "",
    sourceTitle: "NIRF India Rankings Official Portal",
    sourceUrl: "https://www.nirfindia.org",
    sourceType: "Government/Regulator Portal",
    academicYear: "2026-27",
    confidenceScore: 98,
    retrievedAtIso: "2026-10-29T10:30:00Z",
    verificationStatus: "Pending Verification",
    createdAt: now,
    updatedAt: now,
  };
}

function validPlacementPayload(userId, now) {
  return {
    userId,
    collegeId: "demo_col_rvce",
    collegeName: "R.V. College of Engineering",
    courseName: "B.E.",
    specialization: "Computer Science & Engineering",
    academicYear: "2025-26",
    scopeType: "Course-Specific",
    levelType: "UG",
    offerScope: "Domestic",
    highestPackageLpa: 62.0,
    averagePackageLpa: 19.4,
    medianPackageLpa: 17.5,
    placementRatePercent: 94.2,
    eligibleStudents: 210,
    participatingStudents: 198,
    placedStudents: 186,
    totalRecruiters: 142,
    internshipStipendMonthlyInr: 75000,
    topRecruiters: "Microsoft, Atlassian, SAP Labs, Qualcomm",
    commonJobRoles: "Software Development Engineer, AI/ML Engineer",
    sourceCitation: "RVCE Official Placement Cell Report 2025-26",
    verificationStatus: "Verified",
    createdAt: now,
    updatedAt: now,
  };
}

function validCollegeReviewPayload(userId, now) {
  return {
    userId,
    collegeId: "demo_col_kmc",
    collegeName: "Kasturba Medical College Manipal",
    courseFocus: "MBBS & Allied Health",
    reviewCategory: "Internal Consultancy Observation",
    sourceName: "EduIntel Senior Medical Counsellor Field Audit",
    overallRating: 4.6,
    reviewCount: 42,
    retrievedDate: "2026-10-29",
    positiveThemes: "2,032-bed Kasturba Hospital clinical exposure and high USMLE/NEET-PG preparation support.",
    negativeThemes: "High Deemed University tuition fee structure requiring early financial planning.",
    recurringComplaints: "Strict 85% clinical posting attendance requirement.",
    academicExperienceRating: 4.8,
    infrastructureLabsRating: 4.7,
    facultyQualityRating: 4.6,
    hostelMessRating: 4.3,
    placementSupportRating: 4.5,
    clinicalPracticalRating: 4.9,
    campusLifeSupportRating: 4.4,
    dimensionEvidenceSummary: "Synthesized across 7 clinical and campus quality dimensions.",
    isContextualAiSummary: false,
    createdAt: now,
    updatedAt: now,
  };
}

function validAppSettingsPayload(userId, now) {
  return {
    userId,
    enquiryHeader: "ADMISSION ENQUIRIES",
    enquiryPhone: "+91 70122 74141",
    isLocked: true,
    organizationName: "Private Education Consultancy Intelligence Platform",
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read colleges, source_queue, placements, or college_reviews", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("colleges").get());
  await assertFails(unauthDb.collection("source_queue").get());
  await assertFails(unauthDb.collection("placements").get());
  await assertFails(unauthDb.collection("college_reviews").get());
});

test("Authenticated user: can create valid college for self", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("colleges").doc("kmc_manipal").set(validCollegePayload(ALICE_UID, now))
  );
});

test("Authenticated user: can create valid source_queue item and app_settings", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("source_queue").doc("sq_1").set(validSourceQueuePayload(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb.collection("app_settings").doc("locked_settings").set(validAppSettingsPayload(ALICE_UID, now))
  );
});

test("Authenticated user: can create valid placement and college_review records", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("placements").doc("pl_1").set(validPlacementPayload(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb.collection("college_reviews").doc("rev_1").set(validCollegeReviewPayload(ALICE_UID, now))
  );
});

test("Placement classification safeguard: rejects invalid scopeType or offerScope", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const invalidPlacement = {
    ...validPlacementPayload(ALICE_UID, now),
    offerScope: "Blended_Unclassified",
  };
  await assertFails(
    aliceDb.collection("placements").doc("pl_bad").set(invalidPlacement)
  );
});

test("AppSettings tamper guard: rejects non-matching phone number in app_settings", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const tampered = {
    ...validAppSettingsPayload(ALICE_UID, now),
    enquiryPhone: "+91 99999 00000",
  };
  await assertFails(
    aliceDb.collection("app_settings").doc("tampered_settings").set(tampered)
  );
});

test("Authenticated user: cannot spoof another userId on create", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb.collection("colleges").doc("spoof_college").set(validCollegePayload(BOB_UID, now))
  );
});

test("Authenticated user: cannot read another user's college", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("colleges").doc("bob_college").set(validCollegePayload(BOB_UID, now));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("colleges").doc("bob_college").get());
});

test("Authenticated user: can query own colleges with userId filter", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("colleges").doc("alice_college").set(validCollegePayload(ALICE_UID, now));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("colleges").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated user: can create admission_deadlines, team_tasks, team_members, and 9-stage enquiries", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("admission_deadlines").doc("dl_1").set({
      userId: ALICE_UID,
      collegeId: "col_rvce",
      collegeName: "RV College of Engineering",
      courseName: "B.E. CSE",
      quotaCategory: "KCET / COMEDK",
      academicYear: "2026-27",
      applicationOpenDate: "2026-01-10",
      applicationDeadline: "2026-04-15",
      entranceExamDate: "2026-04-22",
      counsellingRound1Date: "2026-06-18",
      counsellingRound2Date: "2026-07-08",
      mopUpStrayRoundDate: "2026-07-28",
      documentVerificationDeadline: "2026-06-10",
      scholarshipDeadline: "2026-08-31",
      feePaymentWindow: "2026-06-20 to 2026-06-28",
      sourceUrl: "https://cetonline.karnataka.gov.in/kea/",
      retrievalDate: "2026-03-30",
      verificationStatus: "Verified",
      hasConflict: false,
      conflictDetails: "",
      isOverdueRefresh: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("team_tasks").doc("tsk_1").set({
      userId: ALICE_UID,
      title: "Resolve RVCE Fee Discrepancy",
      taskType: "Discrepancy Resolution",
      assignedToName: "Karthik Iyer",
      assignedToRole: "Fee Reviewer",
      priority: "Urgent",
      dueDate: "2026-04-02",
      linkedRecordType: "Fee Doc",
      linkedRecordId: "fdoc_1",
      linkedRecordName: "RVCE_Fee_Circular_2026.pdf",
      status: "In Progress",
      notes: "Verify VTU skill lab fee line item.",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("team_members").doc("usr_1").set({
      userId: ALICE_UID,
      fullName: "Arjun Menon",
      email: "arjun.menon@eduintel.in",
      roleName: "Admin",
      department: "Platform Governance",
      isActive: true,
      permissionsSummary: "Full platform governance",
      lastActiveDisplay: "Online — Active Today",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("enquiries").doc("enq_1").set({
      userId: ALICE_UID,
      studentName: "Aarav Sharma",
      phone: "+91 98450 11223",
      targetStream: "Engineering & Tech",
      preferredCourse: "B.E. CSE",
      preferredColleges: "[]",
      entranceExamScore: "KCET Rank 1,420",
      budgetMaxLakhs: 16.0,
      quotaPreference: "Merit / Govt",
      stage: "Offer Received",
      followUpDueToday: true,
      deadlineDate: "2026-11-15",
      counsellorNotes: "Shortlist finalized.",
      createdAt: now,
      updatedAt: now,
    })
  );
});

