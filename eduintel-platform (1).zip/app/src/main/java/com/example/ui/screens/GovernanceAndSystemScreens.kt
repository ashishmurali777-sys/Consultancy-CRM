package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettingsRecord
import com.example.data.model.AuditLogEntry
import com.example.data.model.College
import com.example.data.model.ConsultancyModule
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.StudentEnquiry
import com.example.ui.components.MandatoryAdmissionEnquiryFooter
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.viewmodel.AiTaskState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SpecializedModuleScreen(
    module: ConsultancyModule,
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    enquiries: List<StudentEnquiry>,
    auditLogs: List<AuditLogEntry>,
    appSettings: AppSettingsRecord,
    sourceQueueCount: Int,
    briefingsCount: Int,
    placementsCount: Int = 0,
    reviewsCount: Int = 0,
    deadlinesCount: Int = 0,
    tasksCount: Int = 0,
    teamMembersCount: Int = 0,
    activeRole: ConsultancyRole,
    onSelectRole: (ConsultancyRole) -> Unit,
    aiTaskState: AiTaskState,
    onRunGroundingStream: (String) -> Unit,
    onUpdateFeeDocStatus: (FeeDocument, String) -> Unit,
    onVerifyCollegeStatus: (College, String) -> Unit,
    onOpenAcceptanceSuite: () -> Unit = {},
    supabaseUrl: String = "",
    supabaseAnonKey: String = "",
    geminiApiKey: String = "",
    isSupabaseConnected: Boolean = false,
    supabaseStatusMessage: String = "Hybrid Cloud Firestore + Local Sync Active",
    onSaveSupabaseKeys: (String, String, String) -> Unit = { _, _, _ -> },
    onSaveGeminiApiKey: (String) -> Unit = {},
    onDisconnectSupabaseKeys: () -> Unit = {}
) {
    when (module) {
        ConsultancyModule.QUOTA_FEE_COMPARATOR -> QuotaFeeComparatorView(courses, feeDocs, activeRole, onUpdateFeeDocStatus, appSettings)
        ConsultancyModule.ENTRANCE_EXAM_CUTOFF_HUB -> EntranceExamHubView(courses)
        ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK -> AlliedHealthAndDegreeAuditorView(colleges, courses)
        ConsultancyModule.RBAC_SECURITY_GOVERNANCE -> RbacGovernanceMatrixView(
            activeRole = activeRole,
            onSelectRole = onSelectRole,
            onOpenAcceptanceSuite = onOpenAcceptanceSuite,
            supabaseUrl = supabaseUrl,
            supabaseAnonKey = supabaseAnonKey,
            geminiApiKey = geminiApiKey,
            isSupabaseConnected = isSupabaseConnected,
            supabaseStatusMessage = supabaseStatusMessage,
            onSaveSupabaseKeys = onSaveSupabaseKeys,
            onSaveGeminiApiKey = onSaveGeminiApiKey,
            onDisconnectSupabaseKeys = onDisconnectSupabaseKeys
        )
        ConsultancyModule.SQL_FIRESTORE_SYNC_CENTER -> SqlFirestoreSyncCenterView(
            collegesCount = colleges.size,
            coursesCount = courses.size,
            feeDocsCount = feeDocs.size,
            enquiriesCount = enquiries.size,
            sourceQueueCount = sourceQueueCount,
            briefingsCount = briefingsCount,
            placementsCount = placementsCount,
            reviewsCount = reviewsCount,
            deadlinesCount = deadlinesCount,
            tasksCount = tasksCount,
            teamMembersCount = teamMembersCount,
            auditLogs = auditLogs,
            appSettings = appSettings,
            onOpenAcceptanceSuite = onOpenAcceptanceSuite,
            supabaseUrl = supabaseUrl,
            supabaseAnonKey = supabaseAnonKey,
            geminiApiKey = geminiApiKey,
            isSupabaseConnected = isSupabaseConnected,
            supabaseStatusMessage = supabaseStatusMessage,
            onSaveSupabaseKeys = onSaveSupabaseKeys,
            onSaveGeminiApiKey = onSaveGeminiApiKey,
            onDisconnectSupabaseKeys = onDisconnectSupabaseKeys
        )
        else -> QuotaFeeComparatorView(courses, feeDocs, activeRole, onUpdateFeeDocStatus, appSettings)
    }
}

@Composable
private fun QuotaFeeComparatorView(
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    activeRole: ConsultancyRole,
    onUpdateFeeDocStatus: (FeeDocument, String) -> Unit,
    appSettings: AppSettingsRecord
) {
    var activeTab by remember { mutableStateOf(0) }
    val discrepanciesCount = feeDocs.count { it.hasDiscrepancy || it.reviewStatus == "Flagged Discrepancy" }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                label = { Text("Quota Fee Matrix (${courses.size})") }
            )
            FilterChip(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                label = { Text("Fee Discrepancy Desk ($discrepanciesCount)") }
            )
        }

        if (activeTab == 1) {
            DiscrepancyResolutionView(feeDocs, activeRole, onUpdateFeeDocStatus)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Quota-Wise Fee Structure Comparator Report", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Compare Government/Merit vs COMEDK/Consortium vs Management/Institutional vs NRI fee bands across Indian colleges.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(courses, key = { it.id }) { crs ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${crs.courseName} (${crs.specialization})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(crs.collegeName, style = MaterialTheme.typography.bodySmall, color = SkyCyan400)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("GOVT / MERIT MIN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${formatInrLakhs(crs.annualTuitionMinInr)}/yr", style = MaterialTheme.typography.titleSmall, color = VerifiedEmerald)
                                }
                                Column {
                                    Text("MGMT / NRI MAX", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${formatInrLakhs(crs.annualTuitionMaxInr)}/yr", style = MaterialTheme.typography.titleSmall, color = AmberGold400)
                                }
                                Column {
                                    Text("DURATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${crs.durationYears} Yrs", style = MaterialTheme.typography.titleSmall)
                                }
                            }
                            Text(crs.quotaFeesSummary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                // Mandatory Admission Enquiry Contact Footer at the end of Comparison Report
                item {
                    MandatoryAdmissionEnquiryFooter(
                        enquiryHeader = appSettings.enquiryHeader,
                        enquiryPhone = appSettings.enquiryPhone
                    )
                }
            }
        }
    }
}

@Composable
private fun DiscrepancyResolutionView(
    feeDocs: List<FeeDocument>,
    activeRole: ConsultancyRole,
    onUpdateFeeDocStatus: (FeeDocument, String) -> Unit
) {
    val discrepancies = feeDocs.filter { it.hasDiscrepancy || it.reviewStatus == "Flagged Discrepancy" }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Fee Discrepancy Resolution Desk", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Resolve variances between uploaded institutional circulars and official State Fee Regulatory Committee / MCC notifications (${discrepancies.size} open).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(discrepancies, key = { it.id }) { doc ->
            FeeDocumentAuditCard(
                doc = doc,
                activeRole = activeRole,
                onUpdateReviewStatus = onUpdateFeeDocStatus
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EntranceExamHubView(courses: List<Course>) {
    var selectedExam by remember { mutableStateOf("All") }
    val exams = listOf("All", "NEET", "KCET", "COMEDK", "JEE", "CAT", "University Entrance")
    val filtered = remember(courses, selectedExam) {
        if (selectedExam == "All") courses else courses.filter { it.entranceExams.contains(selectedExam) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Entrance Exam & Eligibility Intelligence Hub", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Filter Indian programs by accepted entrance test (NEET-UG, KCET, COMEDK, JEE, CAT, University Entrance) and Lateral Entry.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                exams.forEach { ex ->
                    FilterChip(
                        selected = selectedExam == ex,
                        onClick = { selectedExam = ex },
                        label = { Text(ex, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }
        items(filtered, key = { it.id }) { crs ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${crs.courseName} — ${crs.collegeName}", style = MaterialTheme.typography.titleMedium)
                    Text("Accepted Exams: ${crs.entranceExams.joinToString(", ")}", style = MaterialTheme.typography.labelMedium, color = AmberGold400)
                    Text("Eligibility: ${crs.eligibility}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun AutonomousDegreeAuditorView(colleges: List<College>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Autonomous vs. Degree-Awarding University Auditor", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Critical Indian Higher Education Rule: An Autonomous College frames its own syllabus and exams, but its degree is legally awarded by its affiliating University (e.g. VTU, RGUHS, Anna University).",
                style = MaterialTheme.typography.bodySmall,
                color = AmberGold400
            )
        }
        items(colleges, key = { it.id }) { col ->
            val isSelfAwarding = col.institutionType.contains("University") || col.institutionType.contains("National Importance")
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${col.name} (${col.shortCode})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Surface(
                            color = if (isSelfAwarding) VerifiedEmerald.copy(alpha = 0.16f) else AmberGold400.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isSelfAwarding) "SELF-AWARDING UNIVERSITY" else "UNIVERSITY-CONFERRED DEGREE",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelfAwarding) VerifiedEmerald else AmberGold400,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text("Institution Type: ${col.institutionType} | Ownership: ${col.ownership}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Degree-Awarding Authority: ${col.degreeAwardingUniversity}",
                        style = MaterialTheme.typography.titleSmall,
                        color = SkyCyan400
                    )
                    Text("Administrative Affiliation: ${col.affiliatedTo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AlliedHealthAndDegreeAuditorView(
    colleges: List<College>,
    courses: List<Course>
) {
    var activeTab by remember { mutableStateOf(0) }
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                label = { Text("Healthcare & Clinical Desk") }
            )
            FilterChip(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                label = { Text("Degree-Awarding Auditor (${colleges.size})") }
            )
        }
        if (activeTab == 1) {
            AutonomousDegreeAuditorView(colleges)
        } else {
            AlliedHealthCouncilView(courses)
        }
    }
}

@Composable
private fun AlliedHealthCouncilView(courses: List<Course>) {
    val healthcareCourses = courses.filter {
        it.stream.contains("Health", ignoreCase = true) ||
            it.stream.contains("Medical", ignoreCase = true) ||
            it.stream.contains("Dental", ignoreCase = true) ||
            it.stream.contains("Nursing", ignoreCase = true)
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Healthcare, Allied Health & Clinical Exposure Desk", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Specialized tracking for MBBS (NMC), BDS (DCI), B.Sc Nursing (INC/KNC), BPT/MPT Neurology (IAP/RGUHS), and B.Optom programs including parent hospital bed strength, OPD inflow, compulsory internships & service bonds.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(healthcareCourses, key = { it.id }) { crs ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${crs.courseName} — ${crs.specialization}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Council: ${crs.regulatoryBody}", style = MaterialTheme.typography.labelMedium, color = VerifiedEmerald)
                    }
                    Text(crs.collegeName, style = MaterialTheme.typography.bodySmall, color = SkyCyan400)
                    Text(
                        "Duration: ${crs.durationYears} Yrs | Intake: ${crs.intake} seats | Lateral Entry: ${if (crs.isLateralEntry) "Available (2nd Yr Direct)" else "Not Applicable"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberGold400
                    )
                    Text(crs.quotaFeesSummary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SupabaseConnectionCard(
    supabaseUrl: String,
    supabaseAnonKey: String,
    geminiApiKey: String = "",
    isSupabaseConnected: Boolean,
    supabaseStatusMessage: String,
    onSaveSupabaseKeys: (String, String, String) -> Unit,
    onSaveGeminiApiKey: (String) -> Unit = {},
    onDisconnectSupabaseKeys: () -> Unit
) {
    var urlInput by remember(supabaseUrl) { mutableStateOf(supabaseUrl) }
    var anonKeyInput by remember(supabaseAnonKey) { mutableStateOf(supabaseAnonKey) }
    var geminiKeyInput by remember(geminiApiKey) { mutableStateOf(geminiApiKey) }

    val statusColor = if (isSupabaseConnected) VerifiedEmerald else AmberGold400
    val statusBadgeLabel = if (isSupabaseConnected) {
        "LIVE: SUPABASE POSTGRESQL CONNECTED"
    } else {
        "LIVE: HYBRID CLOUD FIRESTORE + FALLBACK SYNC"
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, statusColor.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
            .testTag("supabase_connection_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        Icons.Default.Storage,
                        contentDescription = "Supabase Connection",
                        tint = SkyCyan400,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "Supabase Connection & Gemini API Keys",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Configure VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY & Gemini API Key for live database & Fee OCR",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Live Connection Status Indicator Banner
            Surface(
                color = statusColor.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                    .testTag("supabase_live_status_indicator")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = statusBadgeLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = supabaseStatusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (isSupabaseConnected) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Connected",
                            tint = VerifiedEmerald,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // VITE_SUPABASE_URL Input
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text("VITE_SUPABASE_URL") },
                placeholder = { Text("https://your-project-ref.supabase.co") },
                leadingIcon = {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = SkyCyan400)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_vite_supabase_url")
            )

            // VITE_SUPABASE_ANON_KEY Input
            OutlinedTextField(
                value = anonKeyInput,
                onValueChange = { anonKeyInput = it },
                label = { Text("VITE_SUPABASE_ANON_KEY") },
                placeholder = { Text("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...") },
                leadingIcon = {
                    Icon(Icons.Default.Key, contentDescription = null, tint = AmberGold400)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_vite_supabase_anon_key")
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            // Gemini API Key Input Field (below Supabase keys)
            OutlinedTextField(
                value = geminiKeyInput,
                onValueChange = { geminiKeyInput = it },
                label = { Text("Gemini API Key") },
                placeholder = { Text("AIzaSy... (Paste your real Gemini API Key for Fee OCR)") },
                leadingIcon = {
                    Icon(Icons.Default.Key, contentDescription = null, tint = VerifiedEmerald)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_gemini_api_key")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (geminiKeyInput.isNotBlank()) {
                        "Gemini Key Active (${geminiKeyInput.trim().take(6)}... • 15s strict OCR timeout)"
                    } else {
                        "Gemini Key Empty — Fee OCR uses instant simulated extraction (Tuition: 100000, Hostel: 50000)"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (geminiKeyInput.isNotBlank()) VerifiedEmerald else AmberGold400,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { onSaveGeminiApiKey(geminiKeyInput) },
                    modifier = Modifier.testTag("save_gemini_api_key_btn")
                ) {
                    Text("Save Gemini Key", style = MaterialTheme.typography.labelSmall)
                }
            }

            // Action Buttons Row: Save Keys + Quick Demo Fill / Disconnect
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val demoUrl = "https://eduintel-consultancy-prod.supabase.co"
                            val demoKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eduintel_anon_key_2026_verified"
                            urlInput = demoUrl
                            anonKeyInput = demoKey
                            onSaveSupabaseKeys(demoUrl, demoKey, geminiKeyInput)
                        },
                        modifier = Modifier.testTag("fill_demo_supabase_keys_btn")
                    ) {
                        Text("Load Demo Keys", style = MaterialTheme.typography.labelSmall)
                    }
                    if (isSupabaseConnected || urlInput.isNotBlank() || anonKeyInput.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                urlInput = ""
                                anonKeyInput = ""
                                onDisconnectSupabaseKeys()
                            },
                            modifier = Modifier.testTag("clear_supabase_keys_btn")
                        ) {
                            Text("Disconnect", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Button(
                    onClick = { onSaveSupabaseKeys(urlInput, anonKeyInput, geminiKeyInput) },
                    modifier = Modifier.testTag("save_supabase_keys_btn")
                ) {
                    Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Keys", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RbacGovernanceMatrixView(
    activeRole: ConsultancyRole,
    onSelectRole: (ConsultancyRole) -> Unit,
    onOpenAcceptanceSuite: () -> Unit = {},
    supabaseUrl: String = "",
    supabaseAnonKey: String = "",
    geminiApiKey: String = "",
    isSupabaseConnected: Boolean = false,
    supabaseStatusMessage: String = "",
    onSaveSupabaseKeys: (String, String, String) -> Unit = { _, _, _ -> },
    onSaveGeminiApiKey: (String) -> Unit = {},
    onDisconnectSupabaseKeys: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Settings & Integrations",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Manage Supabase Real-Time Connection (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY), Gemini API Key for Fee OCR, 6-Role RBAC Guard, and the 18-Point Acceptance Suite.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onOpenAcceptanceSuite,
                    modifier = Modifier.testTag("run_acceptance_suite_btn")
                ) {
                    Text("Run 18-Point Acceptance Suite")
                }
            }
        }

        // Global Role Switcher Card (Admin, Senior Reviewer, Counselor)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SkyCyan400.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .testTag("settings_global_role_switcher_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GLOBAL ROLE SWITCHER (ACTIVE: ${activeRole.label.uppercase()})",
                            style = MaterialTheme.typography.labelLarge,
                            color = SkyCyan400,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (activeRole == ConsultancyRole.COUNSELLOR || activeRole == ConsultancyRole.READ_ONLY_VIEWER) {
                                "Read-Only Access"
                            } else {
                                "Read-Write Access"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (activeRole == ConsultancyRole.COUNSELLOR || activeRole == ConsultancyRole.READ_ONLY_VIEWER) {
                                AmberGold400
                            } else {
                                VerifiedEmerald
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            ConsultancyRole.ADMIN,
                            ConsultancyRole.SENIOR_REVIEWER,
                            ConsultancyRole.COUNSELLOR
                        ).forEach { targetRole ->
                            val isSelected = activeRole == targetRole
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectRole(targetRole) },
                                label = {
                                    Text(
                                        text = targetRole.label,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("settings_role_chip_${targetRole.badgeCode.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // Supabase Connection Card with VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, Gemini API Key, Save Keys & Live Connection Status Indicator
        item {
            SupabaseConnectionCard(
                supabaseUrl = supabaseUrl,
                supabaseAnonKey = supabaseAnonKey,
                geminiApiKey = geminiApiKey,
                isSupabaseConnected = isSupabaseConnected,
                supabaseStatusMessage = supabaseStatusMessage,
                onSaveSupabaseKeys = onSaveSupabaseKeys,
                onSaveGeminiApiKey = onSaveGeminiApiKey,
                onDisconnectSupabaseKeys = onDisconnectSupabaseKeys
            )
        }

        item {
            Text(
                text = "6-ROLE RBAC ACCESS GUARD & PERMISSION SWITCHER",
                style = MaterialTheme.typography.labelLarge,
                color = SkyCyan400,
                fontWeight = FontWeight.Bold
            )
        }

        items(ConsultancyRole.entries) { role ->
            val selected = role == activeRole
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (selected) SkyCyan400 else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                        RoundedCornerShape(12.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${role.label} (${role.badgeCode})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { onSelectRole(role) }) {
                            Text(if (selected) "Active Role" else "Switch to ${role.badgeCode}")
                        }
                    }
                    Text(role.description, style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Permissions: Colleges=${role.canManageColleges} | Verify=${role.canVerifyRegulatory} | FeeReview=${role.canReviewFees} | OCR=${role.canRunOcr} | CRM=${role.canManageEnquiries} | Delete=${role.canDeleteRecords}",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberGold400
                    )
                }
            }
        }
    }
}

@Composable
private fun SqlFirestoreSyncCenterView(
    collegesCount: Int,
    coursesCount: Int,
    feeDocsCount: Int,
    enquiriesCount: Int,
    sourceQueueCount: Int,
    briefingsCount: Int,
    placementsCount: Int,
    reviewsCount: Int,
    deadlinesCount: Int,
    tasksCount: Int,
    teamMembersCount: Int,
    auditLogs: List<AuditLogEntry>,
    appSettings: AppSettingsRecord,
    onOpenAcceptanceSuite: () -> Unit = {},
    supabaseUrl: String = "",
    supabaseAnonKey: String = "",
    geminiApiKey: String = "",
    isSupabaseConnected: Boolean = false,
    supabaseStatusMessage: String = "",
    onSaveSupabaseKeys: (String, String, String) -> Unit = { _, _, _ -> },
    onSaveGeminiApiKey: (String) -> Unit = {},
    onDisconnectSupabaseKeys: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Real-Time Sync, Immutable Audit Log & Locked App Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "Live bidirectional Cloud Firestore snapshot listeners across all 13 collections + Supabase Connection & locked Admission Enquiry footer.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = onOpenAcceptanceSuite) {
                    Text("18-Point Acceptance Suite")
                }
            }
        }

        // Also display Supabase Connection Card in Sync Center
        item {
            SupabaseConnectionCard(
                supabaseUrl = supabaseUrl,
                supabaseAnonKey = supabaseAnonKey,
                geminiApiKey = geminiApiKey,
                isSupabaseConnected = isSupabaseConnected,
                supabaseStatusMessage = supabaseStatusMessage,
                onSaveSupabaseKeys = onSaveSupabaseKeys,
                onSaveGeminiApiKey = onSaveGeminiApiKey,
                onDisconnectSupabaseKeys = onDisconnectSupabaseKeys
            )
        }

        // Locked App Settings Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberGold400.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = AmberGold400, modifier = Modifier.size(18.dp))
                            Text(
                                "LOCKED APP_SETTINGS RECORD (/app_settings)",
                                style = MaterialTheme.typography.labelMedium,
                                color = AmberGold400,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (appSettings.isLocked) "TAMPER-LOCKED" else "ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = VerifiedEmerald
                        )
                    }
                    Text(
                        "Enforced by Firestore Security Rules (`isValidAppSettings`) and PostgreSQL RLS (`is_locked = TRUE`). Dynamically injected at the end of every College Profile, AI Briefing, Comparison Report, and Printable/Exported PDF or CSV:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    MandatoryAdmissionEnquiryFooter(
                        enquiryHeader = appSettings.enquiryHeader,
                        enquiryPhone = appSettings.enquiryPhone
                    )
                }
            }
        }

        // Live Collection Sync Telemetry
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CloudDone, contentDescription = null, tint = VerifiedEmerald)
                        Text("LIVE CLOUD FIRESTORE REAL-TIME STREAM STATUS: CONNECTED (13 COLLECTIONS)", style = MaterialTheme.typography.labelMedium, color = VerifiedEmerald)
                    }
                    Text(
                        "• /colleges ($collegesCount) • /courses ($coursesCount) • /fee_documents ($feeDocsCount) • /placements ($placementsCount) • /college_reviews ($reviewsCount)\n• /admission_deadlines ($deadlinesCount) • /enquiries ($enquiriesCount) • /team_tasks ($tasksCount) • /team_members ($teamMembersCount) • /source_queue ($sourceQueueCount)\n• /college_briefing_versions ($briefingsCount) • /audit_logs (${auditLogs.size}) • /app_settings (1)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Immutable Audit Trail
        item {
            Text(
                "IMMUTABLE GOVERNANCE AUDIT LOG (/audit_logs • ${auditLogs.size} entries)",
                style = MaterialTheme.typography.labelMedium,
                color = SkyCyan400
            )
        }

        items(auditLogs, key = { it.id }) { log ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${log.actionType} • ${log.targetModule}",
                            style = MaterialTheme.typography.labelMedium,
                            color = AmberGold400,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Role: ${log.actorRole}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyCyan400
                        )
                    }
                    Text(log.targetRecordName, style = MaterialTheme.typography.titleSmall)
                    Text(log.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
