package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.College
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.OcrFeeExtractionResult
import com.example.data.model.StudentEnquiry
import com.example.ui.components.EnquiryEditorDialog
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrExact
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.viewmodel.AiTaskState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeeOcrVerificationLabScreen(
    colleges: List<College>,
    feeDocs: List<FeeDocument>,
    activeRole: ConsultancyRole,
    feeDocStatusFilter: String,
    onFeeDocStatusFilterChange: (String) -> Unit,
    aiTaskState: AiTaskState,
    ocrErrorAlert: String? = null,
    onDismissOcrErrorAlert: () -> Unit = {},
    feeSuccessMessage: String? = null,
    onDismissFeeSuccessMessage: () -> Unit = {},
    onRunOcr: (Bitmap?, String) -> Unit,
    onSaveOcrResult: (OcrFeeExtractionResult, String, String) -> Unit,
    onUpdateReviewStatus: (FeeDocument, String) -> Unit
) {
    val context = LocalContext.current
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedImageName by remember { mutableStateOf("Manual_Fee_Structure_2026_27.pdf") }

    var collegeNameInput by remember(colleges) {
        mutableStateOf(colleges.firstOrNull()?.name ?: "R.V. College of Engineering (RVCE)")
    }
    var courseNameInput by remember { mutableStateOf("B.Tech Computer Science & Engineering") }
    var academicYearInput by remember { mutableStateOf("2026-27") }
    var quotaCategoryInput by remember { mutableStateOf("Management / Institutional") }
    var tuitionFeeInput by remember { mutableStateOf("100000") }
    var hostelFeeInput by remember { mutableStateOf("50000") }
    var cautionDepositInput by remember { mutableStateOf("10000") }
    var otherChargesInput by remember { mutableStateOf("15000") }

    var circularContextText by remember {
        mutableStateOf(
            "R.V. College of Engineering (RVCE) Bengaluru - 2026-27 Management Quota B.E. CSE Circular: " +
                "Annual Tuition Fee: Rs. 1,00,000. Hostel & Mess Charges: Rs. 50,000. " +
                "Caution Deposit: Rs. 10,000. Other Lab & Exam Charges: Rs. 15,000."
        )
    }

    // Persistent modal alert (window.alert equivalent) when Supabase returns an error
    if (!ocrErrorAlert.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = onDismissOcrErrorAlert,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.WarningAmber, contentDescription = "Supabase Error", tint = DiscrepancyRose)
                    Text("Supabase Insert Error", color = DiscrepancyRose, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = ocrErrorAlert,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.testTag("supabase_fee_error_alert_text")
                )
            },
            confirmButton = {
                Button(
                    onClick = onDismissOcrErrorAlert,
                    colors = ButtonDefaults.buttonColors(containerColor = DiscrepancyRose)
                ) {
                    Text("OK")
                }
            }
        )
    }

    // Populate manual fields if an uploaded image OCR completes with structured data
    LaunchedEffect(aiTaskState) {
        if (aiTaskState is AiTaskState.OcrSuccess) {
            val ext = aiTaskState.extraction
            if (ext.collegeName.isNotBlank()) collegeNameInput = ext.collegeName
            if (ext.courseName.isNotBlank()) courseNameInput = ext.courseName
            if (ext.academicYear.isNotBlank()) academicYearInput = ext.academicYear
            if (ext.quotaCategory.isNotBlank()) quotaCategoryInput = ext.quotaCategory
            tuitionFeeInput = ext.tuitionFeeAnnualInr.toString()
            hostelFeeInput = ext.hostelAndMessAnnualInr.toString()
            cautionDepositInput = ext.cautionDepositInr.toString()
            otherChargesInput = ext.otherChargesInr.toString()
            if (ext.extractedRawSummary.isNotBlank()) {
                circularContextText = ext.extractedRawSummary
            }
        }
    }

    val buildManualExtraction: () -> OcrFeeExtractionResult = {
        val tuitionVal = tuitionFeeInput.replace(",", "").trim().toLongOrNull() ?: 100000L
        val hostelVal = hostelFeeInput.replace(",", "").trim().toLongOrNull() ?: 50000L
        val cautionVal = cautionDepositInput.replace(",", "").trim().toLongOrNull() ?: 10000L
        val otherVal = otherChargesInput.replace(",", "").trim().toLongOrNull() ?: 15000L
        OcrFeeExtractionResult(
            collegeName = collegeNameInput.ifBlank { colleges.firstOrNull()?.name ?: "Selected College" },
            courseName = courseNameInput.ifBlank { "B.Tech Computer Science & Engineering" },
            academicYear = academicYearInput.ifBlank { "2026-27" },
            quotaCategory = quotaCategoryInput.ifBlank { "Management / Institutional" },
            tuitionFeeAnnualInr = tuitionVal,
            hostelAndMessAnnualInr = hostelVal,
            cautionDepositInr = cautionVal,
            otherChargesInr = otherVal,
            extractedRawSummary = circularContextText.ifBlank {
                "Tuition: INR $tuitionVal, Hostel: INR $hostelVal, Caution: INR $cautionVal, Other: INR $otherVal"
            },
            webComparisonNotes = "Saved to Supabase fee_structures table.",
            hasDiscrepancy = false,
            discrepancyDetails = "None"
        )
    }

    val saveManualOrExtractedEntry: () -> Unit = {
        val extraction = buildManualExtraction()
        val matchedColId = colleges.firstOrNull {
            it.name.equals(extraction.collegeName, ignoreCase = true) ||
                it.name.contains(extraction.collegeName.take(8), ignoreCase = true)
        }?.id ?: (colleges.firstOrNull()?.id ?: "")
        onSaveOcrResult(extraction, matchedColId, selectedImageName)
    }

    // Zero-permission Android Photo Picker per Google Play Policy
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
                selectedBitmap = bmp
                selectedImageName = "Uploaded_Fee_Circular_${System.currentTimeMillis() % 10000}.jpg"
            }
        }
    }

    val presets = listOf(
        "RVCE ManagementCSE" to Triple("R.V. College of Engineering (RVCE)", "1600000", "148000"),
        "St. John's BPT" to Triple("St. John's Medical College", "210000", "92000"),
        "SRM Dental BDS" to Triple("SRM Institute of Science and Technology", "450000", "135000")
    )

    val filteredDocs = remember(feeDocs, feeDocStatusFilter) {
        if (feeDocStatusFilter == "All") feeDocs
        else feeDocs.filter { it.reviewStatus == feeDocStatusFilter }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Fee Structure Verification & Manual / OCR Entry Lab", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Enter fee values manually to save directly to Supabase fee_structures, or optionally attach a circular image for Gemini 3.8 Flash OCR.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Persistent Red Error Banner if Supabase returns an error
        if (!ocrErrorAlert.isNullOrBlank()) {
            item {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DiscrepancyRose, RoundedCornerShape(10.dp))
                        .testTag("ocr_error_red_alert")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.WarningAmber,
                                contentDescription = "Supabase Error",
                                tint = DiscrepancyRose,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = ocrErrorAlert,
                                style = MaterialTheme.typography.bodyMedium,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = onDismissOcrErrorAlert,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text("Dismiss", style = MaterialTheme.typography.labelSmall, color = DiscrepancyRose)
                        }
                    }
                }
            }
        }

        // Green Success Toast Banner (ONLY shown when Supabase call actually succeeded without error)
        if (!feeSuccessMessage.isNullOrBlank() && ocrErrorAlert.isNullOrBlank()) {
            item {
                Surface(
                    color = VerifiedEmerald.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, VerifiedEmerald, RoundedCornerShape(10.dp))
                        .testTag("fee_success_green_toast")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = feeSuccessMessage,
                                style = MaterialTheme.typography.bodyMedium,
                                color = VerifiedEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = onDismissFeeSuccessMessage,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Text("OK", style = MaterialTheme.typography.labelSmall, color = VerifiedEmerald)
                        }
                    }
                }
            }
        }

        // Manual & Multimodal OCR Input Card
        item {
            val canWriteFees = activeRole != ConsultancyRole.COUNSELLOR &&
                activeRole != ConsultancyRole.READ_ONLY_VIEWER &&
                (activeRole.canRunOcr || activeRole.canReviewFees)

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = SkyCyan400)
                            Text("1. Fee Structure Entry & Circular Upload", style = MaterialTheme.typography.titleMedium)
                        }
                        if (canWriteFees) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (selectedBitmap != null) {
                                    OutlinedButton(
                                        onClick = {
                                            selectedBitmap = null
                                            selectedImageName = "Manual_Fee_Structure_2026_27.pdf"
                                        }
                                    ) {
                                        Text("Clear Image", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                                OutlinedButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.testTag("pick_fee_image_btn")
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (selectedBitmap != null) "Image Attached" else "Upload Image (Optional)")
                                }
                            }
                        } else {
                            Surface(
                                color = AmberGold400.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.border(1.dp, AmberGold400.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = "${activeRole.label}: Read-Only",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberGold400,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    if (canWriteFees) {
                        Text("Quick-Fill Preset or Select College:", style = MaterialTheme.typography.labelSmall, color = AmberGold400)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            presets.forEach { (label, presetData) ->
                                FilterChip(
                                    selected = collegeNameInput == presetData.first && tuitionFeeInput == presetData.second,
                                    onClick = {
                                        collegeNameInput = presetData.first
                                        tuitionFeeInput = presetData.second
                                        hostelFeeInput = presetData.third
                                        selectedImageName = "${label.replace(" ", "_")}_2026.pdf"
                                    },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                            colleges.take(4).forEach { col ->
                                FilterChip(
                                    selected = collegeNameInput.equals(col.name, ignoreCase = true),
                                    onClick = { collegeNameInput = col.name },
                                    label = { Text(col.name.take(22), style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = collegeNameInput,
                            onValueChange = { if (canWriteFees) collegeNameInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("College Name") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_college_name")
                        )
                        OutlinedTextField(
                            value = courseNameInput,
                            onValueChange = { if (canWriteFees) courseNameInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Course / Programme") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_course_name")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = academicYearInput,
                            onValueChange = { if (canWriteFees) academicYearInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Academic Year") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_academic_year")
                        )
                        OutlinedTextField(
                            value = quotaCategoryInput,
                            onValueChange = { if (canWriteFees) quotaCategoryInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Admission Quota") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_quota_category")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = tuitionFeeInput,
                            onValueChange = { if (canWriteFees) tuitionFeeInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Annual Tuition Fee (INR)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_tuition")
                        )
                        OutlinedTextField(
                            value = hostelFeeInput,
                            onValueChange = { if (canWriteFees) hostelFeeInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Hostel & Mess Fee (INR)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_hostel")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = cautionDepositInput,
                            onValueChange = { if (canWriteFees) cautionDepositInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Caution Deposit (INR)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_caution")
                        )
                        OutlinedTextField(
                            value = otherChargesInput,
                            onValueChange = { if (canWriteFees) otherChargesInput = it },
                            readOnly = !canWriteFees,
                            enabled = canWriteFees,
                            label = { Text("Other / Lab Charges (INR)") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_fee_other")
                        )
                    }

                    OutlinedTextField(
                        value = circularContextText,
                        onValueChange = { if (canWriteFees) circularContextText = it },
                        readOnly = !canWriteFees,
                        enabled = canWriteFees,
                        label = { Text("Circular Context / Fee Breakdown Notes") },
                        minLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_fee_notes")
                    )

                    if (canWriteFees) {
                        // Optional Gemini OCR button ONLY calls Gemini when an image is attached
                        if (selectedBitmap != null) {
                            OutlinedButton(
                                onClick = { onRunOcr(selectedBitmap, circularContextText) },
                                enabled = aiTaskState !is AiTaskState.Loading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("run_gemini_ocr_btn")
                            ) {
                                if (aiTaskState is AiTaskState.Loading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(aiTaskState.statusMessage)
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Auto-Fill Fields from Uploaded Image (Gemini 3.8 Flash)")
                                }
                            }
                        }

                        // Primary Save / Submit button: directly writes manual/edited values to Supabase fee_structures
                        Button(
                            onClick = saveManualOrExtractedEntry,
                            colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_submit_fee_btn")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Save / Submit to Supabase fee_structures",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("fee_ocr_readonly_banner")
                        ) {
                            Text(
                                text = "Read-Only Access (${activeRole.label}): Save / Submit and Edit actions are disabled for Counselors.",
                                style = MaterialTheme.typography.bodySmall,
                                color = AmberGold400,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (aiTaskState is AiTaskState.OcrSuccess) {
                        val ext = aiTaskState.extraction
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SkyCyan400, RoundedCornerShape(10.dp))
                                .testTag("ocr_extraction_result_card")
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("EXTRACTED FEE PREVIEW (EDITABLE ABOVE)", style = MaterialTheme.typography.labelMedium, color = SkyCyan400)
                                    VerificationStatusBadge(
                                        status = if (ext.hasDiscrepancy) "Flagged Discrepancy" else "Verified"
                                    )
                                }
                                Text("${collegeNameInput} • ${courseNameInput} (${academicYearInput})", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Quota: ${quotaCategoryInput} | Tuition: INR ${tuitionFeeInput} | Hostel: INR ${hostelFeeInput} | Caution: INR ${cautionDepositInput} | Other/Lab: INR ${otherChargesInput}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AmberGold400
                                )
                                if (canWriteFees) {
                                    Button(
                                        onClick = saveManualOrExtractedEntry,
                                        colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("commit_ocr_record_btn")
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Confirm & Save Fee Structure to Supabase")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Filter & Stored Fee Documents Queue
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("2. Stored Fee Circulars & Audit Queue (${filteredDocs.size})", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "Pending Review", "Flagged Discrepancy", "Verified", "Rejected").forEach { st ->
                    item {
                        FilterChip(
                            selected = feeDocStatusFilter == st,
                            onClick = { onFeeDocStatusFilterChange(st) },
                            label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        items(filteredDocs, key = { it.id }) { doc ->
            FeeDocumentAuditCard(
                doc = doc,
                activeRole = activeRole,
                onUpdateReviewStatus = onUpdateReviewStatus
            )
        }
    }
}

@Composable
fun FeeDocumentAuditCard(
    doc: FeeDocument,
    activeRole: ConsultancyRole,
    onUpdateReviewStatus: (FeeDocument, String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (doc.hasDiscrepancy) DiscrepancyRose.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${doc.collegeName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${doc.courseName} • ${doc.quotaCategory} (${doc.academicYear})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Source: ${doc.sourceTitle}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                VerificationStatusBadge(status = doc.reviewStatus)
            }

            // 4-Column Fee Breakdown Strip
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FeeItemColumn("Tuition/Yr", formatInrLakhs(doc.tuitionFeeAnnualInr))
                    FeeItemColumn("Hostel+Mess", formatInrLakhs(doc.hostelAndMessAnnualInr))
                    FeeItemColumn("Caution Dep.", formatInrLakhs(doc.cautionDepositInr))
                    FeeItemColumn("Other/Kit", formatInrLakhs(doc.otherChargesInr))
                    FeeItemColumn("1st Yr Total", formatInrLakhs(doc.totalFirstYearInr), highlight = true)
                }
            }

            Text(doc.extractedRawSummary, style = MaterialTheme.typography.bodySmall)

            if (doc.webComparisonNotes.isNotBlank()) {
                Text(
                    "Web Grounding Audit: ${doc.webComparisonNotes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (doc.hasDiscrepancy || doc.discrepancyDetails.isNotBlank()) {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = DiscrepancyRose, modifier = Modifier.size(18.dp))
                        Text(
                            text = doc.discrepancyDetails.ifBlank { "Discrepancy flagged against published regulatory fee cap." },
                            style = MaterialTheme.typography.bodySmall,
                            color = DiscrepancyRose
                        )
                    }
                }
            }

            if (activeRole.canReviewFees) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onUpdateReviewStatus(doc, "Verified") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve & Verify", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = { onUpdateReviewStatus(doc, "Flagged Discrepancy") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Flag, contentDescription = null, tint = DiscrepancyRose, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Flag Variance", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeeItemColumn(label: String, value: String, highlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.labelMedium,
            color = if (highlight) AmberGold400 else MaterialTheme.colorScheme.onSurface,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun RegulatoryApprovalTrackerScreen(
    colleges: List<College>,
    courses: List<Course>,
    activeRole: ConsultancyRole,
    onVerifyCollege: (College, String) -> Unit
) {
    var selectedCouncil by remember { mutableStateOf("All") }
    val councils = listOf("All", "UGC", "AICTE", "NMC", "DCI", "INC", "PCI", "IAP", "NBA", "NAAC")

    val filtered = remember(colleges, selectedCouncil) {
        if (selectedCouncil == "All") colleges
        else colleges.filter { it.regulators.contains(selectedCouncil) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Statutory Regulatory & Accreditation Tracker", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Audit UGC, AICTE, NMC (Medical), DCI (Dental), INC (Nursing), PCI (Pharmacy), IAP (Physiotherapy), NAAC & NIRF validity.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(councils) { c ->
                    FilterChip(
                        selected = selectedCouncil == c,
                        onClick = { selectedCouncil = c },
                        label = { Text(c, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        items(filtered, key = { it.id }) { col ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${col.name} (${col.shortCode})", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "NAAC ${col.naacGrade} (CGPA ${col.naacCgpa}) • NIRF #${if (col.nirfRank > 0) col.nirfRank else "Unranked"} • Portal: ${col.websiteUrl}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyCyan400
                            )
                        }
                        VerificationStatusBadge(status = col.verificationStatus)
                    }
                    Text(
                        "Statutory Approvals: ${col.regulators.joinToString(", ")}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        col.regulatorDetailsSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (activeRole.canVerifyRegulatory) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Verified", "Institution-Claimed", "Outdated", "Unverified").forEach { status ->
                                FilterChip(
                                    selected = col.verificationStatus == status,
                                    onClick = { onVerifyCollege(col, status) },
                                    label = { Text(status, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentEnquiryCrmScreen(
    enquiries: List<StudentEnquiry>,
    courses: List<Course>,
    activeRole: ConsultancyRole,
    onlyDueToday: Boolean,
    onToggleOnlyDueToday: (Boolean) -> Unit,
    onAddEnquiry: (StudentEnquiry) -> Unit,
    onAdvanceStage: (StudentEnquiry) -> Unit
) {
    var showCreateEnquiry by remember { mutableStateOf(false) }

    val filtered = remember(enquiries, onlyDueToday) {
        if (!onlyDueToday) enquiries else enquiries.filter { it.followUpDueToday }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Student Admissions CRM & Counselling Pipeline", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Manage NEET/KCET/COMEDK candidates, budget matching, and daily counsellor follow-ups (${filtered.size} active).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (activeRole.canManageEnquiries) {
                    Button(
                        onClick = { showCreateEnquiry = true },
                        modifier = Modifier.testTag("add_enquiry_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Enquiry")
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            FilterChip(
                selected = onlyDueToday,
                onClick = { onToggleOnlyDueToday(!onlyDueToday) },
                label = { Text("Follow-ups Due Today Only (${enquiries.count { it.followUpDueToday }})") }
            )
        }

        items(filtered, key = { it.id }) { enq ->
            val matchingCourses = courses.filter {
                (it.annualTuitionMinInr / 100000.0) * it.durationYears <= enq.budgetMaxLakhs
            }.take(3)

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(enq.studentName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "${enq.phone} • Target: ${enq.preferredCourse} (${enq.targetStream})",
                                style = MaterialTheme.typography.bodySmall,
                                color = SkyCyan400
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = enq.stage,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        "Entrance Score: ${enq.entranceExamScore} | Max Budget: ₹${enq.budgetMaxLakhs}L | Quota: ${enq.quotaPreference} | Deadline: ${enq.deadlineDate}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberGold400
                    )
                    Text(
                        "Shortlisted: ${enq.preferredColleges}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (enq.counsellorNotes.isNotBlank()) {
                        Text(
                            "Notes: ${enq.counsellorNotes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (matchingCourses.isNotEmpty()) {
                        Text(
                            "Budget-Eligible Tracked Programs: " + matchingCourses.joinToString(", ") { "${it.courseName} (${it.collegeName.take(22)})" },
                            style = MaterialTheme.typography.labelSmall,
                            color = VerifiedEmerald
                        )
                    }

                    if (activeRole.canManageEnquiries && enq.stage != "Enrolled") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = { onAdvanceStage(enq) }) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Advance Counselling Stage", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateEnquiry) {
        EnquiryEditorDialog(
            onSave = onAddEnquiry,
            onDismiss = { showCreateEnquiry = false }
        )
    }
}
