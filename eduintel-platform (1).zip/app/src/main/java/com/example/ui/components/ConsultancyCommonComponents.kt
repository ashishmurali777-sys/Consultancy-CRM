package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.College
import com.example.data.model.ConsultancyModule
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.StudentEnquiry
import com.example.data.model.TeamTaskRecord
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.ClaimedBlue
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.OutdatedAmber
import com.example.ui.theme.VerifiedEmerald
import java.text.NumberFormat
import java.util.Locale

fun formatInrLakhs(amountInr: Long): String {
    if (amountInr <= 0L) return "₹0"
    val lakhs = amountInr / 100000.0
    return if (lakhs >= 1.0) {
        String.format(Locale.US, "₹%.2fL", lakhs)
    } else {
        val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
        "₹${formatter.format(amountInr)}"
    }
}

fun formatInrExact(amountInr: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
    return "₹${formatter.format(amountInr)}"
}

@Composable
fun VerificationStatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, icon) = when (status) {
        "Verified" -> Triple(VerifiedEmerald.copy(alpha = 0.16f), VerifiedEmerald, Icons.Default.CheckCircle)
        "Institution-Claimed" -> Triple(ClaimedBlue.copy(alpha = 0.16f), ClaimedBlue, Icons.Default.Info)
        "Outdated" -> Triple(OutdatedAmber.copy(alpha = 0.16f), OutdatedAmber, Icons.Default.History)
        "Flagged Discrepancy", "Rejected" -> Triple(DiscrepancyRose.copy(alpha = 0.16f), DiscrepancyRose, Icons.Default.WarningAmber)
        "Pending Review" -> Triple(OutdatedAmber.copy(alpha = 0.16f), OutdatedAmber, Icons.Default.ErrorOutline)
        else -> Triple(Color(0xFF64748B).copy(alpha = 0.2f), Color(0xFF94A3B8), Icons.Default.ErrorOutline)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier.border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = status,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = status,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ClaimReliabilityBadge(badge: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, icon) = when (badge) {
        "Verified Official" -> Triple(VerifiedEmerald.copy(alpha = 0.16f), VerifiedEmerald, Icons.Default.CheckCircle)
        "College-Provided Unverified" -> Triple(ClaimedBlue.copy(alpha = 0.16f), ClaimedBlue, Icons.Default.Info)
        "Third-Party" -> Triple(OutdatedAmber.copy(alpha = 0.16f), OutdatedAmber, Icons.Default.History)
        else -> Triple(DiscrepancyRose.copy(alpha = 0.14f), DiscrepancyRose, Icons.Default.WarningAmber)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier.border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = badge,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Mandatory Admission Enquiry Contact Footer pulled dynamically from locked `app_settings`.
 * Strictly displays ONLY:
 * ADMISSION ENQUIRIES
 * +91 70122 74141
 * No WhatsApp icon, no secondary phone numbers.
 */
@Composable
fun MandatoryAdmissionEnquiryFooter(
    enquiryHeader: String = "ADMISSION ENQUIRIES",
    enquiryPhone: String = "+91 70122 74141",
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
            .testTag("mandatory_admission_enquiry_footer")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = "$enquiryHeader / $enquiryPhone",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = enquiryHeader,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = enquiryPhone,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Persistent Global Footer displayed across all dashboard screens:
 * ADMISSION ENQUIRIES / +91 70122 74141
 */
@Composable
fun PersistentAdmissionEnquiriesFooter(
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            .testTag("persistent_admission_enquiries_footer")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ADMISSION ENQUIRIES / +91 70122 74141",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


@Composable
fun RoleSwitcherDialog(
    activeRole: ConsultancyRole,
    onSelectRole: (ConsultancyRole) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Security, contentDescription = "RBAC Role Switcher", tint = MaterialTheme.colorScheme.primary)
                Text("Switch Active RBAC Role", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Enforces role permissions across both UI affordances and ViewModel/Repository operations:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ConsultancyRole.entries.forEach { role ->
                    val isSelected = role == activeRole
                    Surface(
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectRole(role)
                                onDismiss()
                            }
                            .testTag("role_option_${role.badgeCode.lowercase()}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${role.label} (${role.badgeCode})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isSelected) {
                                    Text(
                                        text = "ACTIVE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = role.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun GlobalOmnisearchModal(
    query: String,
    onQueryChange: (String) -> Unit,
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    enquiries: List<StudentEnquiry>,
    activeRole: ConsultancyRole = ConsultancyRole.ADMIN,
    onNavigateModule: (ConsultancyModule) -> Unit,
    onSelectCollegeSearch: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val q = query.trim().lowercase()
    val permittedEnquiries = remember(enquiries, activeRole) {
        enquiries.filter { it.isVisibleForRole(activeRole) }
    }
    val matchedStudents = remember(q, permittedEnquiries) {
        if (q.isBlank()) permittedEnquiries.take(4)
        else permittedEnquiries.filter { enq ->
            val meta = enq.parseProfileMetadata()
            val resolvedEmail = enq.email.ifBlank { meta.email }
            val resolvedCollege = enq.targetCollegeName.ifBlank { enq.preferredColleges }
            enq.studentName.lowercase().contains(q) ||
                enq.phone.lowercase().contains(q) ||
                resolvedEmail.lowercase().contains(q) ||
                resolvedCollege.lowercase().contains(q) ||
                enq.preferredCourse.lowercase().contains(q) ||
                enq.displayLeadStatus().lowercase().contains(q)
        }
    }
    val matchedModules = remember(q) {
        if (q.isBlank()) ConsultancyModule.entries.take(6)
        else ConsultancyModule.entries.filter {
            it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q)
        }
    }
    val matchedColleges = remember(q, colleges) {
        if (q.isBlank()) colleges.take(3)
        else colleges.filter {
            it.name.lowercase().contains(q) ||
                it.shortCode.lowercase().contains(q) ||
                it.city.lowercase().contains(q) ||
                it.degreeAwardingUniversity.lowercase().contains(q)
        }
    }
    val matchedCourses = remember(q, courses) {
        if (q.isBlank()) courses.take(3)
        else courses.filter {
            it.courseName.lowercase().contains(q) ||
                it.specialization.lowercase().contains(q) ||
                it.collegeName.lowercase().contains(q)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Search students (name/email/phone), colleges, courses, or modules...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close search")
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("global_search_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (matchedStudents.isNotEmpty()) {
                        item {
                            Text(
                                "STUDENTS / LEADS (${matchedStudents.size} • RBAC: ${activeRole.label})",
                                style = MaterialTheme.typography.labelSmall,
                                color = VerifiedEmerald
                            )
                        }
                        items(matchedStudents) { std ->
                            val resolvedEmail = std.email.ifBlank { std.parseProfileMetadata().email }
                            val resolvedCollege = std.targetCollegeName.ifBlank { std.preferredColleges }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onNavigateModule(ConsultancyModule.STUDENT_ENQUIRY_CRM)
                                        onDismiss()
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        "${std.studentName} • ${std.displayLeadStatus()}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "${std.phone} | $resolvedEmail • ${resolvedCollege.ifBlank { "Target College" }} (${std.preferredCourse})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    if (matchedColleges.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "COLLEGES (${matchedColleges.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(matchedColleges) { col ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSelectCollegeSearch(col.name)
                                        onNavigateModule(ConsultancyModule.COLLEGE_INTELLIGENCE_DB)
                                        onDismiss()
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("${col.name} (${col.shortCode})", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${col.city}, ${col.state} • ${col.institutionType} • Degree by: ${col.degreeAwardingUniversity}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    if (matchedCourses.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "COURSES (${matchedCourses.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(matchedCourses) { crs ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onNavigateModule(ConsultancyModule.COURSE_CATALOG_MATRIX)
                                        onDismiss()
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("${crs.courseName} — ${crs.specialization}", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${crs.collegeName} • ${formatInrLakhs(crs.annualTuitionMinInr)} - ${formatInrLakhs(crs.annualTuitionMaxInr)}/yr",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "MODULES (${matchedModules.size})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(matchedModules) { mod ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onNavigateModule(mod)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${mod.number}. ${mod.title}", style = MaterialTheme.typography.titleSmall)
                                    Text(mod.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(mod.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CollegeEditorDialog(
    initialCollege: College?,
    onSave: (College, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val isEdit = initialCollege != null
    var officialName by remember { mutableStateOf(initialCollege?.name ?: "") }
    var institutionType by remember {
        mutableStateOf(initialCollege?.institutionType?.ifBlank { "Private University" } ?: "Private University")
    }
    var ownership by remember {
        mutableStateOf(initialCollege?.ownership?.ifBlank { "Private Unaided" } ?: "Private Unaided")
    }
    var degreeAwardingUni by remember { mutableStateOf(initialCollege?.degreeAwardingUniversity ?: "") }
    var state by remember { mutableStateOf(initialCollege?.state ?: "Karnataka") }
    var city by remember { mutableStateOf(initialCollege?.city ?: "Bengaluru") }

    var shortCode by remember { mutableStateOf(initialCollege?.shortCode ?: "") }
    var affiliatedTo by remember { mutableStateOf(initialCollege?.affiliatedTo ?: "") }
    var establishedYear by remember { mutableStateOf((initialCollege?.establishedYear ?: 1995L).toString()) }
    var websiteUrl by remember { mutableStateOf(initialCollege?.websiteUrl ?: "https://") }
    var verificationStatus by remember {
        mutableStateOf(initialCollege?.verificationStatus ?: "Unverified")
    }
    var naacGrade by remember { mutableStateOf(initialCollege?.naacGrade ?: "A+") }
    var naacCgpa by remember { mutableStateOf((initialCollege?.naacCgpa ?: 3.45).toString()) }
    var nirfRank by remember { mutableStateOf((initialCollege?.nirfRank ?: 45L).toString()) }
    var selectedRegulators by remember {
        mutableStateOf(initialCollege?.regulators?.toSet() ?: setOf("UGC", "AICTE", "NAAC"))
    }
    var regulatorSummary by remember {
        mutableStateOf(initialCollege?.regulatorDetailsSummary ?: "EoA verified for current academic session.")
    }
    var needsRefresh by remember { mutableStateOf(initialCollege?.needsRefresh ?: false) }

    var instTypeDropdownExpanded by remember { mutableStateOf(false) }
    var ownershipDropdownExpanded by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val instTypeOptions = listOf(
        "Central University",
        "State University",
        "Private University",
        "Deemed-to-be University",
        "Autonomous College",
        "Affiliated College"
    )
    val ownershipOptions = listOf("Public", "Private Unaided")
    val allRegulators = listOf("UGC", "AICTE", "NAAC", "NBA", "NMC", "DCI", "INC", "PCI", "IAP")
    val statusOptions = listOf("Unverified", "Verified", "Institution-Claimed", "Outdated")

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("add_college_modal_dialog"),
        title = {
            Text(
                text = if (isEdit) "Edit Institution Intelligence" else "+ Add College",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (validationError != null) {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose, RoundedCornerShape(8.dp))
                            .testTag("modal_supabase_error_banner")
                    ) {
                        Text(
                            text = validationError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = DiscrepancyRose,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // 1. Official Name (text input)
                OutlinedTextField(
                    value = officialName,
                    onValueChange = {
                        officialName = it
                        validationError = null
                    },
                    label = { Text("Official Name *") },
                    placeholder = { Text("e.g., RV College of Engineering") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_official_name")
                )

                // 2. Institution Type (dropdown: Central University, State University, Private University, Deemed-to-be University, Autonomous College, Affiliated College)
                ExposedDropdownMenuBox(
                    expanded = instTypeDropdownExpanded,
                    onExpandedChange = { instTypeDropdownExpanded = !instTypeDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = institutionType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Institution Type") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = instTypeDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_institution_type")
                    )
                    ExposedDropdownMenu(
                        expanded = instTypeDropdownExpanded,
                        onDismissRequest = { instTypeDropdownExpanded = false }
                    ) {
                        instTypeOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    institutionType = option
                                    instTypeDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("inst_type_option_${option.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    instTypeOptions.forEach { opt ->
                        FilterChip(
                            selected = institutionType == opt,
                            onClick = { institutionType = opt },
                            label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // 3. Ownership (dropdown: Public, Private Unaided)
                ExposedDropdownMenuBox(
                    expanded = ownershipDropdownExpanded,
                    onExpandedChange = { ownershipDropdownExpanded = !ownershipDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = ownership,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Ownership") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = ownershipDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_ownership")
                    )
                    ExposedDropdownMenu(
                        expanded = ownershipDropdownExpanded,
                        onDismissRequest = { ownershipDropdownExpanded = false }
                    ) {
                        ownershipOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    ownership = option
                                    ownershipDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("ownership_option_${option.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ownershipOptions.forEach { opt ->
                        FilterChip(
                            selected = ownership == opt,
                            onClick = { ownership = opt },
                            label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // 4. Degree-Awarding University (text input)
                OutlinedTextField(
                    value = degreeAwardingUni,
                    onValueChange = { degreeAwardingUni = it },
                    label = { Text("Degree-Awarding University") },
                    placeholder = { Text("Defaults to Official Name if left blank") },
                    singleLine = true,
                    supportingText = {
                        Text("Separate from Autonomous status (e.g., VTU Belagavi, RGUHS Bengaluru)")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_degree_awarding_university")
                )

                // 5. State (text input) & 6. City (text input)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = state,
                        onValueChange = { state = it },
                        label = { Text("State") },
                        placeholder = { Text("Karnataka") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_state")
                    )
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("City") },
                        placeholder = { Text("Bengaluru") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_city")
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    "Additional Regulatory & Accreditation Metadata (Optional):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = shortCode,
                        onValueChange = { shortCode = it },
                        label = { Text("Short Code (Auto if blank)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = establishedYear,
                        onValueChange = { establishedYear = it },
                        label = { Text("Est. Year") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = naacGrade,
                        onValueChange = { naacGrade = it },
                        label = { Text("NAAC Grade") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = naacCgpa,
                        onValueChange = { naacCgpa = it },
                        label = { Text("NAAC CGPA") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = nirfRank,
                        onValueChange = { nirfRank = it },
                        label = { Text("NIRF Rank") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Statutory Regulators & Councils:", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    allRegulators.forEach { reg ->
                        val active = reg in selectedRegulators
                        FilterChip(
                            selected = active,
                            onClick = {
                                selectedRegulators = if (active) selectedRegulators - reg else selectedRegulators + reg
                            },
                            label = { Text(reg, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Verification Status (Default: Unverified):", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    statusOptions.forEach { st ->
                        FilterChip(
                            selected = verificationStatus == st,
                            onClick = { verificationStatus = st },
                            label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = regulatorSummary,
                    onValueChange = { regulatorSummary = it },
                    label = { Text("Regulatory Validity & Approval Notes") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = needsRefresh, onCheckedChange = { needsRefresh = it })
                    Text("Flag record as needing annual regulatory/fee refresh", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanOfficialName = officialName.trim()
                    if (cleanOfficialName.isBlank()) {
                        validationError = "Please enter the Official Name of the college."
                        return@Button
                    }
                    val generatedShortCode = shortCode.trim().ifBlank {
                        val words = cleanOfficialName.split(Regex("\\s+")).filter { it.isNotBlank() }
                        if (words.size >= 2) {
                            words.joinToString("") { it.take(1).uppercase() }.take(8)
                        } else {
                            cleanOfficialName.take(6).uppercase()
                        }
                    }
                    val resolvedInstType = institutionType.trim().ifBlank { "Private Unaided" }
                    val resolvedOwnership = ownership.trim().ifBlank { "Private" }
                    val resolvedDegreeUni = degreeAwardingUni.trim().ifBlank { cleanOfficialName }
                    val resolvedState = state.trim().ifBlank { "Karnataka" }
                    val resolvedCity = city.trim().ifBlank { "Bengaluru" }
                    val resolvedStatus = if (isEdit) verificationStatus.ifBlank { "Unverified" } else "Unverified"

                    val base = initialCollege ?: College()
                    onSave(
                        base.copy(
                            name = cleanOfficialName.take(200),
                            shortCode = generatedShortCode.take(40),
                            state = resolvedState.take(80),
                            city = resolvedCity.take(80),
                            ownership = resolvedOwnership,
                            institutionType = resolvedInstType,
                            degreeAwardingUniversity = resolvedDegreeUni.take(200),
                            affiliatedTo = affiliatedTo.trim().ifBlank { resolvedDegreeUni }.take(200),
                            establishedYear = (establishedYear.toLongOrNull() ?: 2000L).coerceIn(1800L, 2030L),
                            websiteUrl = websiteUrl.trim().take(300),
                            verificationStatus = resolvedStatus,
                            naacGrade = naacGrade.trim().take(20),
                            naacCgpa = (naacCgpa.toDoubleOrNull() ?: 3.2).coerceIn(0.0, 4.0),
                            nirfRank = (nirfRank.toLongOrNull() ?: 0L).coerceIn(0L, 1000L),
                            regulators = selectedRegulators.take(12),
                            regulatorDetailsSummary = regulatorSummary.trim().take(1000),
                            needsRefresh = needsRefresh,
                            isDemo = false
                        ),
                        isEdit
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("submit_add_college_btn")
            ) {
                Text(if (isEdit) "Update Record" else "Submit to Supabase")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_add_college_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CourseEditorDialog(
    colleges: List<College>,
    isSubmitting: Boolean = false,
    supabaseErrorAlert: String? = null,
    onSubmitCourse: (collegeId: String, collegeName: String, courseName: String, degree: String, durationYears: Int, seatQuotaType: String) -> Unit = { _, _, _, _, _, _ -> },
    onSave: ((Course) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    // Prefer colleges synced from the Supabase colleges table (!isDemo), falling back to full list if needed
    val supabaseColleges = remember(colleges) {
        val remoteOnly = colleges.filter { !it.isDemo }
        remoteOnly.ifEmpty { colleges }
    }
    var selectedCollege by remember(supabaseColleges) {
        mutableStateOf(supabaseColleges.firstOrNull())
    }
    var collegeDropdownExpanded by remember { mutableStateOf(false) }

    var courseName by remember { mutableStateOf("") }
    var degree by remember { mutableStateOf("UG") }
    var durationYears by remember { mutableStateOf("4") }
    var seatQuotaType by remember { mutableStateOf("Merit") }
    var quotaDropdownExpanded by remember { mutableStateOf(false) }

    var localValidationError by remember { mutableStateOf<String?>(null) }

    val degreeOptions = listOf("UG", "PG", "BBA", "BSc", "BTech", "BCom")
    val quotaOptions = listOf("Merit", "Management", "NRI")
    val activeError = supabaseErrorAlert ?: localValidationError

    AlertDialog(
        onDismissRequest = {
            if (!isSubmitting) onDismiss()
        },
        modifier = Modifier.testTag("add_course_modal_dialog"),
        title = {
            Text(
                text = "+ Add Course",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!activeError.isNullOrBlank()) {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose, RoundedCornerShape(8.dp))
                            .testTag("modal_course_supabase_error_banner")
                    ) {
                        Text(
                            text = activeError,
                            style = MaterialTheme.typography.bodySmall,
                            color = DiscrepancyRose,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // 1. College (Dropdown populated from the Supabase `colleges` table)
                ExposedDropdownMenuBox(
                    expanded = collegeDropdownExpanded,
                    onExpandedChange = { collegeDropdownExpanded = !collegeDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedCollege?.name ?: "Select College from Supabase",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("College (Supabase colleges table) *") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = collegeDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_course_college")
                    )
                    ExposedDropdownMenu(
                        expanded = collegeDropdownExpanded,
                        onDismissRequest = { collegeDropdownExpanded = false }
                    ) {
                        supabaseColleges.forEach { col ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(col.name, fontWeight = FontWeight.SemiBold)
                                        if (col.city.isNotBlank() || col.state.isNotBlank()) {
                                            Text(
                                                "${col.city}, ${col.state}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    selectedCollege = col
                                    localValidationError = null
                                    collegeDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("course_college_option_${col.id.take(12)}")
                            )
                        }
                    }
                }

                if (supabaseColleges.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        supabaseColleges.take(6).forEach { col ->
                            FilterChip(
                                selected = selectedCollege?.id == col.id,
                                onClick = {
                                    selectedCollege = col
                                    localValidationError = null
                                },
                                label = {
                                    Text(
                                        text = col.name.take(24),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            )
                        }
                    }
                }

                // 2. Course Name (e.g., BSc Optometry, BCom)
                OutlinedTextField(
                    value = courseName,
                    onValueChange = {
                        courseName = it
                        localValidationError = null
                    },
                    label = { Text("Course Name *") },
                    placeholder = { Text("e.g., BSc Optometry, BCom") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_course_name")
                )

                // Quick-fill course presets for convenience
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("BSc Optometry", "BCom", "BPT", "BSc Nursing", "BBA", "BCA").forEach { preset ->
                        FilterChip(
                            selected = courseName.equals(preset, ignoreCase = true),
                            onClick = {
                                courseName = preset
                                localValidationError = null
                            },
                            label = { Text(preset, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // 3. Degree (e.g., BBA, BSc, BTech, UG, PG)
                OutlinedTextField(
                    value = degree,
                    onValueChange = {
                        degree = it
                        localValidationError = null
                    },
                    label = { Text("Degree *") },
                    placeholder = { Text("e.g., BBA, BSc, BTech, UG, PG") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_course_degree")
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    degreeOptions.forEach { degOpt ->
                        FilterChip(
                            selected = degree.equals(degOpt, ignoreCase = true),
                            onClick = {
                                degree = degOpt
                                localValidationError = null
                            },
                            label = { Text(degOpt, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("course_degree_chip_${degOpt.lowercase()}")
                        )
                    }
                }

                // 4. Duration in Years (Number)
                OutlinedTextField(
                    value = durationYears,
                    onValueChange = { input ->
                        durationYears = input.filter { it.isDigit() }
                        localValidationError = null
                    },
                    label = { Text("Duration in Years (Number) *") },
                    placeholder = { Text("e.g., 3 or 4") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_course_duration_years")
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("2", "3", "4", "5").forEach { yr ->
                        FilterChip(
                            selected = durationYears == yr,
                            onClick = {
                                durationYears = yr
                                localValidationError = null
                            },
                            label = { Text("$yr Years", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // 5. Seat Quota Type (Dropdown: Merit, Management, NRI)
                ExposedDropdownMenuBox(
                    expanded = quotaDropdownExpanded,
                    onExpandedChange = { quotaDropdownExpanded = !quotaDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = seatQuotaType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Seat Quota Type *") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = quotaDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_seat_quota_type")
                    )
                    ExposedDropdownMenu(
                        expanded = quotaDropdownExpanded,
                        onDismissRequest = { quotaDropdownExpanded = false }
                    ) {
                        quotaOptions.forEach { quotaOpt ->
                            DropdownMenuItem(
                                text = { Text(quotaOpt) },
                                onClick = {
                                    seatQuotaType = quotaOpt
                                    localValidationError = null
                                    quotaDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("seat_quota_option_${quotaOpt.lowercase()}")
                            )
                        }
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    quotaOptions.forEach { quotaOpt ->
                        FilterChip(
                            selected = seatQuotaType == quotaOpt,
                            onClick = {
                                seatQuotaType = quotaOpt
                                localValidationError = null
                            },
                            label = { Text(quotaOpt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !isSubmitting,
                onClick = {
                    val col = selectedCollege
                    if (col == null) {
                        localValidationError = "Please select a College from the Supabase colleges dropdown."
                        return@Button
                    }
                    val cleanCourse = courseName.trim()
                    if (cleanCourse.isBlank()) {
                        localValidationError = "Please enter a Course Name (e.g., BSc Optometry, BCom)."
                        return@Button
                    }
                    // Fallback in insertion code to ensure degree is never null or empty: degree: form.degree || 'UG'
                    val cleanDegree = degree.trim().ifBlank { "UG" }
                    val parsedDuration = durationYears.trim().toIntOrNull()
                    if (parsedDuration == null || parsedDuration <= 0) {
                        localValidationError = "Please enter a valid Duration in Years (e.g., 3 or 4)."
                        return@Button
                    }
                    val cleanQuota = seatQuotaType.trim().ifBlank { "Merit" }

                    onSubmitCourse(
                        col.id,
                        col.name,
                        cleanCourse,
                        cleanDegree,
                        parsedDuration,
                        cleanQuota
                    )
                    onSave?.invoke(
                        Course(
                            collegeId = col.id,
                            collegeName = col.name,
                            courseName = cleanCourse,
                            degree = cleanDegree,
                            durationYears = parsedDuration.toDouble(),
                            seatQuotaType = cleanQuota,
                            quotaFeesSummary = "Degree: $cleanDegree • Seat Quota Type: $cleanQuota • Duration: $parsedDuration Years"
                        )
                    )
                },
                modifier = Modifier.testTag("submit_add_course_btn")
            ) {
                Text(if (isSubmitting) "Saving to Supabase..." else "Submit to Supabase")
            }
        },
        dismissButton = {
            TextButton(
                enabled = !isSubmitting,
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_add_course_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EnquiryEditorDialog(
    onSave: (StudentEnquiry) -> Unit,
    onDismiss: () -> Unit
) {
    var studentName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+91 ") }
    var targetStream by remember { mutableStateOf("Medical") }
    var preferredCourse by remember { mutableStateOf("MBBS") }
    var preferredColleges by remember { mutableStateOf("KMC Manipal, St. John's Bengaluru") }
    var entranceScore by remember { mutableStateOf("NEET 575 (AIR 34,200)") }
    var budgetMaxLakhs by remember { mutableStateOf("45.0") }
    var quotaPreference by remember { mutableStateOf("Merit / Govt") }
    var deadlineDate by remember { mutableStateOf("2026-11-12") }
    var notes by remember { mutableStateOf("") }

    val quotas = listOf("Merit / Govt", "COMEDK / Consortium", "Management", "NRI")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Student Admission Enquiry") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = studentName,
                    onValueChange = { studentName = it },
                    label = { Text("Student Full Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = targetStream,
                        onValueChange = { targetStream = it },
                        label = { Text("Stream") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = preferredCourse,
                        onValueChange = { preferredCourse = it },
                        label = { Text("Target Course") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = entranceScore,
                    onValueChange = { entranceScore = it },
                    label = { Text("Entrance Score & Rank") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = budgetMaxLakhs,
                        onValueChange = { budgetMaxLakhs = it },
                        label = { Text("Max Budget (₹ Lakhs)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = deadlineDate,
                        onValueChange = { deadlineDate = it },
                        label = { Text("Counselling Deadline") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text("Quota Preference:", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    quotas.forEach { q ->
                        FilterChip(
                            selected = quotaPreference == q,
                            onClick = { quotaPreference = q },
                            label = { Text(q, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(
                    value = preferredColleges,
                    onValueChange = { preferredColleges = it },
                    label = { Text("Shortlisted Colleges") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Counsellor Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (studentName.isNotBlank() && phone.isNotBlank()) {
                        onSave(
                            StudentEnquiry(
                                studentName = studentName.trim().take(120),
                                phone = phone.trim().take(30),
                                targetStream = targetStream.trim().ifBlank { "Medical" }.take(80),
                                preferredCourse = preferredCourse.trim().ifBlank { "MBBS" }.take(120),
                                preferredColleges = preferredColleges.trim().take(300),
                                entranceExamScore = entranceScore.trim().take(120),
                                budgetMaxLakhs = (budgetMaxLakhs.toDoubleOrNull() ?: 15.0).coerceIn(0.0, 500.0),
                                quotaPreference = quotaPreference,
                                stage = "New Enquiry",
                                followUpDueToday = true,
                                deadlineDate = deadlineDate.trim().take(40),
                                counsellorNotes = notes.trim().take(1000)
                            )
                        )
                        onDismiss()
                    }
                }
            ) {
                Text("Create Enquiry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun StudentEditorDialog(
    colleges: List<College>,
    courses: List<Course>,
    isSubmitting: Boolean = false,
    supabaseErrorAlert: String? = null,
    onSubmitStudent: (
        fullName: String,
        phone: String,
        email: String,
        targetCollegeId: String,
        targetCollegeName: String,
        interestedCourseId: String,
        interestedCourseName: String,
        leadStatus: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    // Prefer colleges synced from the Supabase colleges table (!isDemo), falling back to full list if needed
    val availableColleges = remember(colleges) {
        val remoteOnly = colleges.filter { !it.isDemo }
        remoteOnly.ifEmpty { colleges }
    }
    var selectedCollege by remember { mutableStateOf<College?>(null) }
    var collegeDropdownExpanded by remember { mutableStateOf(false) }

    val availableCourses = remember(courses, selectedCollege) {
        if (courses.isEmpty()) {
            listOf(
                Course(id = "crs_optom", courseName = "BSc Optometry", degree = "BSc"),
                Course(id = "crs_bcom", courseName = "BCom", degree = "BCom"),
                Course(id = "crs_bba", courseName = "BBA", degree = "BBA"),
                Course(id = "crs_btech", courseName = "BTech CSE", degree = "BTech"),
                Course(id = "crs_bpt", courseName = "BPT", degree = "UG")
            )
        } else {
            val selCol = selectedCollege
            if (selCol == null) {
                courses
            } else {
                val matching = courses.filter {
                    it.collegeId == selCol.id || it.collegeName.equals(selCol.name, ignoreCase = true)
                }
                val others = courses.filterNot { crs -> matching.any { it.id == crs.id } }
                matching + others
            }
        }
    }
    var selectedCourse by remember { mutableStateOf<Course?>(null) }
    var courseDropdownExpanded by remember { mutableStateOf(false) }

    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var leadStatus by remember { mutableStateOf("New") }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    var localValidationError by remember { mutableStateOf<String?>(null) }

    val leadStatusOptions = StudentEnquiry.LEAD_STATUS_OPTIONS
    val activeError = supabaseErrorAlert ?: localValidationError

    AlertDialog(
        onDismissRequest = {
            if (!isSubmitting) onDismiss()
        },
        modifier = Modifier.testTag("add_student_modal_dialog"),
        title = {
            Text(
                text = "+ Add Student",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!activeError.isNullOrBlank()) {
                    val isValidationWarning = supabaseErrorAlert.isNullOrBlank() && !localValidationError.isNullOrBlank()
                    val bannerColor = if (isValidationWarning) AmberGold400 else DiscrepancyRose
                    Surface(
                        color = bannerColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, bannerColor, RoundedCornerShape(8.dp))
                            .testTag("modal_student_supabase_error_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Warning",
                                tint = bannerColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = activeError,
                                style = MaterialTheme.typography.bodySmall,
                                color = bannerColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // 1. Full Name
                OutlinedTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        localValidationError = null
                    },
                    label = { Text("Full Name *") },
                    placeholder = { Text("e.g., Aarav Nair") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_full_name")
                )

                // 2. Phone
                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        localValidationError = null
                    },
                    label = { Text("Phone *") },
                    placeholder = { Text("e.g., +91 98765 43210") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_phone")
                )

                // 3. Email
                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        localValidationError = null
                    },
                    label = { Text("Email *") },
                    placeholder = { Text("e.g., aarav.nair@example.com") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_email")
                )

                // 4. Target College (dropdown populated from `colleges`)
                ExposedDropdownMenuBox(
                    expanded = collegeDropdownExpanded,
                    onExpandedChange = { collegeDropdownExpanded = !collegeDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedCollege?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Target College (Supabase colleges) *") },
                        placeholder = { Text("Select Target College") },
                        isError = localValidationError != null && selectedCollege == null,
                        supportingText = if (localValidationError != null && selectedCollege == null) {
                            { Text("Required: Select a Target College") }
                        } else null,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = collegeDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_student_target_college")
                    )
                    ExposedDropdownMenu(
                        expanded = collegeDropdownExpanded,
                        onDismissRequest = { collegeDropdownExpanded = false }
                    ) {
                        availableColleges.forEach { col ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(col.name, fontWeight = FontWeight.SemiBold)
                                        if (col.city.isNotBlank() || col.state.isNotBlank()) {
                                            Text(
                                                "${col.city}, ${col.state}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    selectedCollege = col
                                    localValidationError = null
                                    collegeDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("student_college_option_${col.id.take(12)}")
                            )
                        }
                    }
                }

                if (availableColleges.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        availableColleges.take(6).forEach { col ->
                            FilterChip(
                                selected = selectedCollege?.id == col.id && selectedCollege?.name == col.name,
                                onClick = {
                                    selectedCollege = col
                                    localValidationError = null
                                },
                                label = {
                                    Text(
                                        text = col.name.take(24),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            )
                        }
                    }
                }

                // 5. Interested Course (dropdown populated from `courses`)
                ExposedDropdownMenuBox(
                    expanded = courseDropdownExpanded,
                    onExpandedChange = { courseDropdownExpanded = !courseDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedCourse?.courseName ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Interested Course (Supabase courses) *") },
                        placeholder = { Text("Select Interested Course") },
                        isError = localValidationError != null && selectedCourse == null,
                        supportingText = if (localValidationError != null && selectedCourse == null) {
                            { Text("Required: Select an Interested Course") }
                        } else null,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = courseDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_student_interested_course")
                    )
                    ExposedDropdownMenu(
                        expanded = courseDropdownExpanded,
                        onDismissRequest = { courseDropdownExpanded = false }
                    ) {
                        availableCourses.forEach { crs ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(crs.courseName, fontWeight = FontWeight.SemiBold)
                                        if (crs.collegeName.isNotBlank()) {
                                            Text(
                                                "${crs.degree} • ${crs.collegeName}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    selectedCourse = crs
                                    localValidationError = null
                                    courseDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("student_course_option_${crs.id.take(12)}")
                            )
                        }
                    }
                }

                if (availableCourses.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        availableCourses.take(6).forEach { crs ->
                            FilterChip(
                                selected = selectedCourse?.id == crs.id && selectedCourse?.courseName == crs.courseName,
                                onClick = {
                                    selectedCourse = crs
                                    localValidationError = null
                                },
                                label = {
                                    Text(
                                        text = crs.courseName.take(24),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            )
                        }
                    }
                }

                // 6. Lead Status (dropdown: New, Contacted, Application Submitted, Enrolled)
                ExposedDropdownMenuBox(
                    expanded = statusDropdownExpanded,
                    onExpandedChange = { statusDropdownExpanded = !statusDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = leadStatus.ifBlank { "New" },
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Lead Status *") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_student_lead_status")
                    )
                    ExposedDropdownMenu(
                        expanded = statusDropdownExpanded,
                        onDismissRequest = { statusDropdownExpanded = false }
                    ) {
                        leadStatusOptions.forEach { statusOpt ->
                            DropdownMenuItem(
                                text = { Text(statusOpt) },
                                onClick = {
                                    leadStatus = statusOpt
                                    localValidationError = null
                                    statusDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("student_lead_status_option_${statusOpt.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    leadStatusOptions.forEach { statusOpt ->
                        FilterChip(
                            selected = leadStatus == statusOpt,
                            onClick = {
                                leadStatus = statusOpt
                                localValidationError = null
                            },
                            label = { Text(statusOpt, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("student_lead_status_chip_${statusOpt.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !isSubmitting,
                onClick = {
                    val col = selectedCollege
                    val crs = selectedCourse
                    if ((col == null || col.name.isBlank()) && (crs == null || crs.courseName.isBlank())) {
                        localValidationError = "Warning: Please select both a Target College and an Interested Course before saving."
                        return@Button
                    }
                    if (col == null || col.name.isBlank()) {
                        localValidationError = "Warning: Please select a Target College from the dropdown before saving."
                        return@Button
                    }
                    if (crs == null || crs.courseName.isBlank()) {
                        localValidationError = "Warning: Please select an Interested Course from the dropdown before saving."
                        return@Button
                    }
                    val cleanName = fullName.trim()
                    if (cleanName.isBlank()) {
                        localValidationError = "Warning: Please enter the student's Full Name."
                        return@Button
                    }
                    val cleanPhone = phone.trim()
                    if (cleanPhone.isBlank()) {
                        localValidationError = "Warning: Please enter a Phone number."
                        return@Button
                    }
                    val cleanEmail = email.trim()
                    if (cleanEmail.isBlank()) {
                        localValidationError = "Warning: Please enter an Email address."
                        return@Button
                    }
                    // Fallback for Lead Status defaults to 'New'
                    val cleanStatus = leadStatus.trim().ifBlank { "New" }

                    onSubmitStudent(
                        cleanName,
                        cleanPhone,
                        cleanEmail,
                        col.id,
                        col.name,
                        crs.id,
                        crs.courseName,
                        cleanStatus
                    )
                },
                modifier = Modifier.testTag("submit_add_student_btn")
            ) {
                Text(if (isSubmitting) "Saving to Supabase..." else "Submit to Supabase")
            }
        },
        dismissButton = {
            TextButton(
                enabled = !isSubmitting,
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_add_student_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TaskEditorDialog(
    students: List<StudentEnquiry>,
    isSubmitting: Boolean = false,
    supabaseErrorAlert: String? = null,
    onSubmitTask: (
        taskDescription: String,
        dueDate: String,
        status: String,
        associatedStudentId: String,
        associatedStudentName: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val studentOptions = remember(students) {
        if (students.isNotEmpty()) {
            students
        } else {
            listOf(
                StudentEnquiry(
                    id = "11111111-1111-1111-1111-111111111111",
                    studentName = "Aarav Menon",
                    phone = "+91 98450 11223",
                    email = "aarav.menon@example.in",
                    targetCollegeName = "RV College of Engineering",
                    preferredColleges = "RV College of Engineering",
                    preferredCourse = "BTech CSE",
                    stage = "New"
                ),
                StudentEnquiry(
                    id = "22222222-2222-2222-2222-222222222222",
                    studentName = "Diya Krishnan",
                    phone = "+91 98451 22334",
                    email = "diya.krishnan@example.in",
                    targetCollegeName = "Manipal Academy of Higher Education (MAHE)",
                    preferredColleges = "Manipal Academy of Higher Education (MAHE)",
                    preferredCourse = "BSc Optometry",
                    stage = "Contacted"
                ),
                StudentEnquiry(
                    id = "33333333-3333-3333-3333-333333333333",
                    studentName = "Rohan Deshmukh",
                    phone = "+91 98452 33445",
                    email = "rohan.deshmukh@example.in",
                    targetCollegeName = "Christ University",
                    preferredColleges = "Christ University",
                    preferredCourse = "BCom Honours",
                    stage = "Application Submitted"
                )
            )
        }
    }

    var taskDescription by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("2026-11-15") }
    var status by remember { mutableStateOf("Pending") }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    var selectedStudent by remember(studentOptions) {
        mutableStateOf(studentOptions.firstOrNull())
    }
    var studentDropdownExpanded by remember { mutableStateOf(false) }

    var localValidationError by remember { mutableStateOf<String?>(null) }
    val statusOptions = TeamTaskRecord.TASK_STATUS_OPTIONS

    AlertDialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        title = {
            Column {
                Text(
                    text = "+ Add Task",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Inserts directly into Supabase tasks table",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val activeError = supabaseErrorAlert?.takeIf { it.isNotBlank() } ?: localValidationError
                if (activeError != null) {
                    val isSupabaseErr = !supabaseErrorAlert.isNullOrBlank()
                    val bannerColor = if (isSupabaseErr) DiscrepancyRose else AmberGold400
                    Surface(
                        color = bannerColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, bannerColor, RoundedCornerShape(8.dp))
                            .testTag("modal_task_supabase_error_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Validation or Supabase Error",
                                tint = bannerColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = activeError,
                                style = MaterialTheme.typography.bodySmall,
                                color = bannerColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 1. Task Description
                OutlinedTextField(
                    value = taskDescription,
                    onValueChange = {
                        taskDescription = it
                        localValidationError = null
                    },
                    label = { Text("Task Description") },
                    placeholder = { Text("e.g., Follow up on original mark sheets & KCET counselling verification") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_description")
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "Verify admission documents & mark sheets",
                        "Follow up on fee payment & scholarship",
                        "Confirm seat allotment & reporting date"
                    ).forEach { sampleDesc ->
                        FilterChip(
                            selected = taskDescription.equals(sampleDesc, ignoreCase = true),
                            onClick = {
                                taskDescription = sampleDesc
                                localValidationError = null
                            },
                            label = { Text(sampleDesc, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // 2. Due Date
                OutlinedTextField(
                    value = dueDate,
                    onValueChange = {
                        dueDate = it
                        localValidationError = null
                    },
                    label = { Text("Due Date (YYYY-MM-DD)") },
                    placeholder = { Text("e.g., 2026-11-15") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_due_date")
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("2026-11-05", "2026-11-15", "2026-11-30", "2026-12-10").forEach { dt ->
                        FilterChip(
                            selected = dueDate == dt,
                            onClick = {
                                dueDate = dt
                                localValidationError = null
                            },
                            label = { Text(dt, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("task_due_date_chip_$dt")
                        )
                    }
                }

                // 3. Status Dropdown (Pending, In Progress, Completed)
                ExposedDropdownMenuBox(
                    expanded = statusDropdownExpanded,
                    onExpandedChange = { statusDropdownExpanded = !statusDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = status,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Status (Pending / In Progress / Completed)") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_task_status")
                    )
                    ExposedDropdownMenu(
                        expanded = statusDropdownExpanded,
                        onDismissRequest = { statusDropdownExpanded = false }
                    ) {
                        statusOptions.forEach { stOpt ->
                            DropdownMenuItem(
                                text = { Text(stOpt) },
                                onClick = {
                                    status = stOpt
                                    localValidationError = null
                                    statusDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("task_status_option_${stOpt.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    statusOptions.forEach { stOpt ->
                        FilterChip(
                            selected = status == stOpt,
                            onClick = {
                                status = stOpt
                                localValidationError = null
                            },
                            label = { Text(stOpt, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("task_status_chip_${stOpt.lowercase().replace(" ", "_")}")
                        )
                    }
                }

                // 4. Associated Student (Dropdown populated from the students table)
                ExposedDropdownMenuBox(
                    expanded = studentDropdownExpanded,
                    onExpandedChange = { studentDropdownExpanded = !studentDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedStudent?.let { st ->
                            if (st.preferredCourse.isNotBlank()) "${st.studentName} (${st.preferredCourse})" else st.studentName
                        } ?: "Select Associated Student",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Associated Student (from Supabase students)") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = studentDropdownExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dropdown_task_associated_student")
                    )
                    ExposedDropdownMenu(
                        expanded = studentDropdownExpanded,
                        onDismissRequest = { studentDropdownExpanded = false }
                    ) {
                        studentOptions.forEachIndexed { idx, student ->
                            DropdownMenuItem(
                                text = {
                                    val collegeLabel = student.targetCollegeName.ifBlank {
                                        student.preferredColleges.ifBlank { "No College" }
                                    }
                                    val courseLabel = student.preferredCourse.ifBlank { "No Course" }
                                    Column {
                                        Text(student.studentName, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "$collegeLabel • $courseLabel",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    selectedStudent = student
                                    localValidationError = null
                                    studentDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("task_student_option_$idx")
                            )
                        }
                    }
                }

                // Quick Student selection chips from students table
                if (studentOptions.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        studentOptions.take(6).forEachIndexed { idx, student ->
                            FilterChip(
                                selected = selectedStudent?.id == student.id && selectedStudent?.studentName == student.studentName,
                                onClick = {
                                    selectedStudent = student
                                    localValidationError = null
                                },
                                label = {
                                    Text(
                                        text = student.studentName.take(22),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag("task_student_chip_$idx")
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !isSubmitting,
                onClick = {
                    val cleanDesc = taskDescription.trim()
                    if (cleanDesc.isBlank()) {
                        localValidationError = "Warning: Please enter a Task Description."
                        return@Button
                    }
                    val cleanDueDate = dueDate.trim().ifBlank { "2026-11-15" }
                    val cleanStatus = status.trim().ifBlank { "Pending" }
                    val st = selectedStudent
                    if (st == null || st.studentName.isBlank()) {
                        localValidationError = "Warning: Please select an Associated Student from the dropdown."
                        return@Button
                    }

                    onSubmitTask(
                        cleanDesc,
                        cleanDueDate,
                        cleanStatus,
                        st.id,
                        st.studentName
                    )
                },
                modifier = Modifier.testTag("submit_add_task_btn")
            ) {
                Text(if (isSubmitting) "Saving to Supabase..." else "Submit to Supabase")
            }
        },
        dismissButton = {
            TextButton(
                enabled = !isSubmitting,
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_add_task_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}
