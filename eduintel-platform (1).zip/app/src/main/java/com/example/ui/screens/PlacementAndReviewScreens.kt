package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.College
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.PlacementRecord
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.OutdatedOrange
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.viewmodel.AiTaskState
import java.util.Locale

// ============================================================================
// MODULE 6: PLACEMENT & CAREER OUTCOME INTELLIGENCE
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlacementCareerOutcomesScreen(
    colleges: List<College>,
    courses: List<Course>,
    placements: List<PlacementRecord>,
    activeRole: ConsultancyRole,
    onAddPlacementRecord: (PlacementRecord) -> Unit
) {
    var selectedCollegeId by remember { mutableStateOf("All") }
    var selectedScopeType by remember { mutableStateOf("All") } // All, Course-Specific, Institution-Wide
    var selectedLevelType by remember { mutableStateOf("All") } // All, UG, PG
    var selectedOfferScope by remember { mutableStateOf("All") } // All, Domestic, International
    var selectedYear by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredPlacements = remember(
        placements, selectedCollegeId, selectedScopeType, selectedLevelType, selectedOfferScope, selectedYear
    ) {
        placements.filter { p ->
            (selectedCollegeId == "All" || p.collegeId == selectedCollegeId) &&
                (selectedScopeType == "All" || p.scopeType == selectedScopeType) &&
                (selectedLevelType == "All" || p.levelType == selectedLevelType) &&
                (selectedOfferScope == "All" || p.offerScope == selectedOfferScope) &&
                (selectedYear == "All" || p.academicYear == selectedYear)
        }
    }

    val chartRecords = remember(filteredPlacements) {
        filteredPlacements
            .filter { it.offerScope == "Domestic" && (it.averagePackageLpa > 0 || it.medianPackageLpa > 0) }
            .sortedBy { it.academicYear }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Placement & Career Outcome Intelligence",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Multi-year CTC analytics with strict Institution-Wide vs Course-Specific, UG vs PG & Domestic vs International safeguards.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_placement_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Log Placement")
                }
            }
        }

        // Strict Classification Safeguard Banner
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberGold400.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = AmberGold400)
                    Column {
                        Text(
                            text = "STRICT CLASSIFICATION & ZERO-EXTRAPOLATION SAFEGUARD",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold400,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "International outlier packages are isolated from Domestic averages. Missing metrics explicitly display 'Not Publicly Reported'—never estimated.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // Multi-Facet Classification Filters
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Filter by Institution:", style = MaterialTheme.typography.labelSmall, color = SkyCyan400)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedCollegeId == "All",
                            onClick = { selectedCollegeId = "All" },
                            label = { Text("All Colleges", style = MaterialTheme.typography.labelSmall) }
                        )
                        colleges.forEach { col ->
                            FilterChip(
                                selected = selectedCollegeId == col.id,
                                onClick = { selectedCollegeId = col.id },
                                label = { Text(col.shortCode, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("plc_filter_col_${col.shortCode}")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Scope Safeguard:", style = MaterialTheme.typography.labelSmall, color = AmberGold400)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("All", "Course-Specific", "Institution-Wide").forEach { sc ->
                                    FilterChip(
                                        selected = selectedScopeType == sc,
                                        onClick = { selectedScopeType = sc },
                                        label = { Text(sc, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cohort Level:", style = MaterialTheme.typography.labelSmall, color = SkyCyan400)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("All", "UG", "PG").forEach { lvl ->
                                    FilterChip(
                                        selected = selectedLevelType == lvl,
                                        onClick = { selectedLevelType = lvl },
                                        label = { Text(lvl, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Offer Geography:", style = MaterialTheme.typography.labelSmall, color = VerifiedEmerald)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("All", "Domestic", "International").forEach { off ->
                                    FilterChip(
                                        selected = selectedOfferScope == off,
                                        onClick = { selectedOfferScope = off },
                                        label = { Text(off, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    Text("Placement Academic Year:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("All", "2025-26", "2024-25", "2023-24").forEach { yr ->
                            FilterChip(
                                selected = selectedYear == yr,
                                onClick = { selectedYear = yr },
                                label = { Text(yr, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // Interactive Year-Over-Year Canvas Visualization
        if (chartRecords.isNotEmpty()) {
            item {
                MultiYearPlacementChartCard(records = chartRecords.take(6))
            }
        }

        // Placement Intelligence Cards
        items(filteredPlacements, key = { it.id }) { record ->
            PlacementOutcomeDetailCard(record = record)
        }
    }

    if (showAddDialog) {
        AddPlacementRecordDialog(
            colleges = colleges,
            courses = courses,
            onDismiss = { showAddDialog = false },
            onSave = {
                onAddPlacementRecord(it)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun MultiYearPlacementChartCard(records: List<PlacementRecord>) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.BarChart, contentDescription = null, tint = SkyCyan400)
                    Column {
                        Text(
                            text = "Year-over-Year Domestic Package (LPA) & Placement Rate %",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Comparing Highest, Average & Median CTC (bars) with Placement Rate % (line)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChartLegendDot(color = SkyCyan400, label = "Highest LPA")
                ChartLegendDot(color = VerifiedEmerald, label = "Average LPA")
                ChartLegendDot(color = AmberGold400, label = "Median LPA")
                ChartLegendDot(color = DiscrepancyRose, label = "Placement %")
            }

            val maxLpa = remember(records) {
                (records.maxOfOrNull { maxOf(it.highestPackageLpa, it.averagePackageLpa, it.medianPackageLpa) } ?: 30.0)
                    .coerceAtLeast(10.0)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(12.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val count = records.size.coerceAtLeast(1)
                    val groupWidth = width / count
                    val barWidth = (groupWidth * 0.2f).coerceIn(8f, 28f)

                    // Horizontal reference grid lines
                    for (step in 1..4) {
                        val y = height - (height * (step / 4f))
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.25f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )
                    }

                    var prevRatePoint: Offset? = null

                    records.forEachIndexed { index, rec ->
                        val groupStartX = index * groupWidth + (groupWidth * 0.14f)

                        // 1. Highest Package Bar (if reported)
                        if (rec.highestPackageLpa > 0) {
                            val hRatio = (rec.highestPackageLpa / maxLpa).toFloat().coerceIn(0.04f, 1f)
                            val barH = height * hRatio
                            drawRoundRect(
                                color = SkyCyan400,
                                topLeft = Offset(groupStartX, height - barH),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(4f, 4f)
                            )
                        }

                        // 2. Average Package Bar
                        if (rec.averagePackageLpa > 0) {
                            val aRatio = (rec.averagePackageLpa / maxLpa).toFloat().coerceIn(0.04f, 1f)
                            val barH = height * aRatio
                            drawRoundRect(
                                color = VerifiedEmerald,
                                topLeft = Offset(groupStartX + barWidth + 4f, height - barH),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(4f, 4f)
                            )
                        }

                        // 3. Median Package Bar
                        if (rec.medianPackageLpa > 0) {
                            val mRatio = (rec.medianPackageLpa / maxLpa).toFloat().coerceIn(0.04f, 1f)
                            val barH = height * mRatio
                            drawRoundRect(
                                color = AmberGold400,
                                topLeft = Offset(groupStartX + (barWidth + 4f) * 2, height - barH),
                                size = Size(barWidth, barH),
                                cornerRadius = CornerRadius(4f, 4f)
                            )
                        }

                        // 4. Placement Rate % Trend Point & Line
                        if (rec.placementRatePercent > 0) {
                            val rateRatio = (rec.placementRatePercent / 100.0).toFloat().coerceIn(0.05f, 1f)
                            val pt = Offset(
                                x = groupStartX + barWidth * 1.5f,
                                y = height - (height * rateRatio * 0.9f)
                            )
                            prevRatePoint?.let { prev ->
                                drawLine(
                                    color = DiscrepancyRose,
                                    start = prev,
                                    end = pt,
                                    strokeWidth = 3.5f
                                )
                            }
                            drawCircle(
                                color = DiscrepancyRose,
                                radius = 6f,
                                center = pt
                            )
                            prevRatePoint = pt
                        }
                    }
                }
            }

            // X-Axis Labels & Values Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                records.forEach { rec ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "${rec.courseName.take(8)} '${rec.academicYear.takeLast(2)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Avg ${if (rec.averagePackageLpa > 0) "${rec.averagePackageLpa}L" else "N/R"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = VerifiedEmerald
                        )
                        Text(
                            text = if (rec.placementRatePercent > 0) "${rec.placementRatePercent}%" else "N/R",
                            style = MaterialTheme.typography.labelSmall,
                            color = DiscrepancyRose
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(text = label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun PlacementOutcomeDetailCard(record: PlacementRecord) {
    val isInternationalOutlier = record.offerScope == "International"
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (isInternationalOutlier) DiscrepancyRose.copy(alpha = 0.7f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (isInternationalOutlier) {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = DiscrepancyRose, modifier = Modifier.size(16.dp))
                        Text(
                            text = "INTERNATIONAL OUTLIER PACKAGE — DO NOT REPRESENT AS TYPICAL DOMESTIC OUTCOME",
                            style = MaterialTheme.typography.labelSmall,
                            color = DiscrepancyRose,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${record.courseName} — ${record.specialization}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${record.collegeName} • Batch ${record.academicYear}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SkyCyan400
                    )
                }
                VerificationStatusBadge(record.verificationStatus)
            }

            // Strict Classification Badges Row
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ClassificationPill(
                    text = record.scopeType.uppercase(Locale.ROOT),
                    color = if (record.scopeType == "Course-Specific") VerifiedEmerald else AmberGold400
                )
                ClassificationPill(
                    text = "LEVEL: ${record.levelType}",
                    color = SkyCyan400
                )
                ClassificationPill(
                    text = "OFFER: ${record.offerScope.uppercase(Locale.ROOT)}",
                    color = if (record.offerScope == "Domestic") VerifiedEmerald else DiscrepancyRose
                )
            }

            // Package Metrics Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricCol(label = "HIGHEST CTC", value = record.formatHighestLpa(), highlightColor = SkyCyan400)
                MetricCol(label = "AVERAGE CTC", value = record.formatAverageLpa(), highlightColor = VerifiedEmerald)
                MetricCol(label = "MEDIAN CTC", value = record.formatMedianLpa(), highlightColor = AmberGold400)
            }

            // Cohort & Participation Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricCol(label = "PLACEMENT %", value = record.formatPlacementRate(), highlightColor = VerifiedEmerald)
                MetricCol(label = "ELIGIBLE / PLACED", value = "${record.formatCount(record.eligibleStudents)} / ${record.formatCount(record.placedStudents)}")
                MetricCol(label = "PARTICIPATING", value = record.formatCount(record.participatingStudents))
                MetricCol(label = "RECRUITERS", value = record.formatCount(record.totalRecruiters))
            }

            HorizontalDivider()

            Text(
                text = "Internship / Residency Stipend: ${record.formatStipend()}",
                style = MaterialTheme.typography.labelMedium,
                color = AmberGold400
            )
            Text(
                text = "Top Recruiters: ${record.topRecruiters}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Common Job / Clinical Roles: ${record.commonJobRoles}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Official Source Citation: ${record.sourceCitation}",
                style = MaterialTheme.typography.labelSmall,
                color = SkyCyan400
            )
        }
    }
}

@Composable
private fun ClassificationPill(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun MetricCol(
    label: String,
    value: String,
    highlightColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val isNotReported = value == "Not Publicly Reported"
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = if (isNotReported) OutdatedOrange else highlightColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddPlacementRecordDialog(
    colleges: List<College>,
    courses: List<Course>,
    onDismiss: () -> Unit,
    onSave: (PlacementRecord) -> Unit
) {
    var selectedCollege by remember { mutableStateOf(colleges.firstOrNull()) }
    var courseName by remember { mutableStateOf("B.Tech") }
    var specialization by remember { mutableStateOf("Computer Science & Engineering") }
    var academicYear by remember { mutableStateOf("2025-26") }
    var scopeType by remember { mutableStateOf("Course-Specific") }
    var levelType by remember { mutableStateOf("UG") }
    var offerScope by remember { mutableStateOf("Domestic") }
    var highestLpa by remember { mutableStateOf("42.0") }
    var averageLpa by remember { mutableStateOf("14.5") }
    var medianLpa by remember { mutableStateOf("12.8") }
    var placementRate by remember { mutableStateOf("92.5") }
    var eligibleCount by remember { mutableStateOf("180") }
    var participatingCount by remember { mutableStateOf("170") }
    var placedCount by remember { mutableStateOf("157") }
    var recruitersCount by remember { mutableStateOf("85") }
    var stipendInr by remember { mutableStateOf("45000") }
    var topRecruiters by remember { mutableStateOf("Microsoft, SAP Labs, Cisco, Apollo Hospitals") }
    var commonRoles by remember { mutableStateOf("Software Engineer, Clinical Analyst") }
    var sourceCitation by remember { mutableStateOf("NIRF 2026 Submitted Placement Data") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Verified Placement Record") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Leave any numeric field blank or -1 to explicitly record 'Not Publicly Reported' (zero extrapolation).",
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberGold400
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    colleges.forEach { col ->
                        FilterChip(
                            selected = selectedCollege?.id == col.id,
                            onClick = { selectedCollege = col },
                            label = { Text(col.shortCode, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(
                    value = courseName,
                    onValueChange = { courseName = it },
                    label = { Text("Course Name (e.g., MBBS, BPT, B.Tech)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = specialization,
                    onValueChange = { specialization = it },
                    label = { Text("Specialization") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Course-Specific", "Institution-Wide").forEach { sc ->
                        FilterChip(
                            selected = scopeType == sc,
                            onClick = { scopeType = sc },
                            label = { Text(sc, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("UG", "PG").forEach { lv ->
                        FilterChip(
                            selected = levelType == lv,
                            onClick = { levelType = lv },
                            label = { Text(lv, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    listOf("Domestic", "International").forEach { of ->
                        FilterChip(
                            selected = offerScope == of,
                            onClick = { offerScope = of },
                            label = { Text(of, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = highestLpa,
                        onValueChange = { highestLpa = it },
                        label = { Text("Highest LPA (-1=N/R)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = averageLpa,
                        onValueChange = { averageLpa = it },
                        label = { Text("Average LPA (-1=N/R)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = medianLpa,
                        onValueChange = { medianLpa = it },
                        label = { Text("Median LPA (-1=N/R)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = placementRate,
                        onValueChange = { placementRate = it },
                        label = { Text("Placement % (-1=N/R)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = eligibleCount,
                        onValueChange = { eligibleCount = it },
                        label = { Text("Eligible") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = placedCount,
                        onValueChange = { placedCount = it },
                        label = { Text("Placed") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = stipendInr,
                        onValueChange = { stipendInr = it },
                        label = { Text("Stipend ₹/mo") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = topRecruiters,
                    onValueChange = { topRecruiters = it },
                    label = { Text("Top Recruiters") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = commonRoles,
                    onValueChange = { commonRoles = it },
                    label = { Text("Common Job Roles") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sourceCitation,
                    onValueChange = { sourceCitation = it },
                    label = { Text("Source Citation") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val col = selectedCollege ?: return@Button
                    onSave(
                        PlacementRecord(
                            collegeId = col.id,
                            collegeName = col.name,
                            courseName = courseName,
                            specialization = specialization,
                            academicYear = academicYear,
                            scopeType = scopeType,
                            levelType = levelType,
                            offerScope = offerScope,
                            highestPackageLpa = highestLpa.toDoubleOrNull() ?: -1.0,
                            averagePackageLpa = averageLpa.toDoubleOrNull() ?: -1.0,
                            medianPackageLpa = medianLpa.toDoubleOrNull() ?: -1.0,
                            placementRatePercent = placementRate.toDoubleOrNull() ?: -1.0,
                            eligibleStudents = eligibleCount.toLongOrNull() ?: -1L,
                            participatingStudents = participatingCount.toLongOrNull() ?: -1L,
                            placedStudents = placedCount.toLongOrNull() ?: -1L,
                            totalRecruiters = recruitersCount.toLongOrNull() ?: -1L,
                            internshipStipendMonthlyInr = stipendInr.toLongOrNull() ?: -1L,
                            topRecruiters = topRecruiters.ifBlank { "Not Publicly Reported" },
                            commonJobRoles = commonRoles.ifBlank { "Not Publicly Reported" },
                            sourceCitation = sourceCitation,
                            verificationStatus = "Verified"
                        )
                    )
                }
            ) {
                Text("Save Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ============================================================================
// MODULE 7: COLLEGE REVIEWS & 7-DIMENSION QUALITY ANALYSIS
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CollegeReviewsQualityScreen(
    colleges: List<College>,
    reviews: List<CollegeReviewRecord>,
    activeRole: ConsultancyRole,
    aiTaskState: AiTaskState,
    onRunAiThemeSummarizer: (College, String, String) -> Unit,
    onSaveReviewRecord: (CollegeReviewRecord) -> Unit
) {
    var selectedCollegeId by remember { mutableStateOf("All") }
    var selectedCategory by remember { mutableStateOf("All") } // All, Public Third-Party Review, Internal Consultancy Observation
    var showAiSummarizerPanel by remember { mutableStateOf(true) }

    var targetCollege by remember(colleges) { mutableStateOf(colleges.firstOrNull()) }
    var targetCourseFocus by remember { mutableStateOf("MBBS / BPT / B.Tech CSE") }
    var pastedReviewNotes by remember {
        mutableStateOf(
            "Debrief notes from 12 graduating students and parents (Oct 2026): " +
                "Academic syllabus is rigorous and clinical postings at the teaching hospital give over 2,000 daily OPD patient exposure. " +
                "Labs and simulation facilities are well maintained. However, students noted strict 85% attendance requirements, " +
                "rising hostel AC room charges, and narrow 4-day fee payment windows after counselling allotment."
        )
    }

    val filteredReviews = remember(reviews, selectedCollegeId, selectedCategory) {
        reviews.filter { r ->
            (selectedCollegeId == "All" || r.collegeId == selectedCollegeId) &&
                (selectedCategory == "All" || r.reviewCategory == selectedCategory)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "College Reviews & 7-Dimension Quality Analysis",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Strictly separates Public Third-Party Reviews from Internal Consultancy Observations across 7 quality dimensions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = { showAiSummarizerPanel = !showAiSummarizerPanel },
                    modifier = Modifier.testTag("toggle_ai_review_summarizer_btn")
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (showAiSummarizerPanel) "Hide AI Lab" else "AI Theme Lab")
                }
            }
        }

        // Gemini 3.8 Flash AI Theme Summarizer Card
        if (showAiSummarizerPanel && colleges.isNotEmpty()) {
            item {
                val activeCollege = targetCollege ?: colleges.first()
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SkyCyan400.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AmberGold400)
                                Text(
                                    text = "AI Review Theme Summarizer (Contextual Evidence Engine)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            color = AmberGold400.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "SAFEGUARD: AI summaries are explicitly labeled as Contextual Evidence Synthesis — never represented as verbatim student quotes.",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberGold400,
                                modifier = Modifier.padding(8.dp)
                            )
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            colleges.forEach { col ->
                                FilterChip(
                                    selected = activeCollege.id == col.id,
                                    onClick = { targetCollege = col },
                                    label = { Text(col.shortCode, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = targetCourseFocus,
                            onValueChange = { targetCourseFocus = it },
                            label = { Text("Programme / Cohort Focus") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = pastedReviewNotes,
                            onValueChange = { pastedReviewNotes = it },
                            label = { Text("Paste Raw Review Notes / Parent & Student Debriefs") },
                            minLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("review_notes_input")
                        )

                        Button(
                            onClick = {
                                onRunAiThemeSummarizer(activeCollege, targetCourseFocus, pastedReviewNotes)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("run_ai_theme_summarizer_btn")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Extract Recurring Pros, Cons & 7-Dimension Scores")
                        }

                        when (aiTaskState) {
                            is AiTaskState.Loading -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.padding(top = 6.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Text(aiTaskState.statusMessage, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            is AiTaskState.ReviewThemeSummarySuccess -> {
                                val summary = aiTaskState.summary
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = "CONTEXTUAL EVIDENCE SYNTHESIS (NOT DIRECT QUOTES)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AmberGold400,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("Positive Themes: ${summary.positiveThemes}", style = MaterialTheme.typography.bodySmall, color = VerifiedEmerald)
                                        Text("Negative Themes: ${summary.negativeThemes}", style = MaterialTheme.typography.bodySmall, color = OutdatedOrange)
                                        Text("Recurring Complaints: ${summary.recurringComplaints}", style = MaterialTheme.typography.bodySmall, color = DiscrepancyRose)
                                        Text(summary.dimensionEvidenceSummary, style = MaterialTheme.typography.bodySmall)

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    onSaveReviewRecord(
                                                        CollegeReviewRecord(
                                                            collegeId = activeCollege.id,
                                                            collegeName = activeCollege.name,
                                                            courseFocus = summary.courseFocus,
                                                            reviewCategory = "Internal Consultancy Observation",
                                                            sourceName = "Gemini 3.8 Flash Contextual Theme Synthesis (${activeRole.label})",
                                                            reviewCount = 1L,
                                                            retrievedDate = "2026-10-29",
                                                            positiveThemes = summary.positiveThemes,
                                                            negativeThemes = summary.negativeThemes,
                                                            recurringComplaints = summary.recurringComplaints,
                                                            academicExperienceRating = summary.academicExperienceRating,
                                                            infrastructureLabsRating = summary.infrastructureLabsRating,
                                                            facultyQualityRating = summary.facultyQualityRating,
                                                            hostelMessRating = summary.hostelMessRating,
                                                            placementSupportRating = summary.placementSupportRating,
                                                            clinicalPracticalRating = summary.clinicalPracticalRating,
                                                            campusLifeSupportRating = summary.campusLifeSupportRating,
                                                            dimensionEvidenceSummary = summary.dimensionEvidenceSummary,
                                                            isContextualAiSummary = true
                                                        )
                                                    )
                                                },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Save as Internal Consultancy Observation")
                                            }
                                        }
                                    }
                                }
                            }
                            is AiTaskState.Error -> {
                                Text(aiTaskState.message, style = MaterialTheme.typography.bodySmall, color = DiscrepancyRose)
                            }
                            else -> Unit
                        }
                    }
                }
            }
        }

        // Category Separation Tabs (Public Third-Party vs Internal Consultancy Observations)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "All" to "All Review Intelligence (${reviews.size})",
                        "Public Third-Party Review" to "Public Third-Party Reviews",
                        "Internal Consultancy Observation" to "Internal Consultancy Observations"
                    ).forEach { (catKey, label) ->
                        FilterChip(
                            selected = selectedCategory == catKey,
                            onClick = { selectedCategory = catKey },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("rev_cat_${catKey.replace(" ", "_")}")
                        )
                    }
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedCollegeId == "All",
                        onClick = { selectedCollegeId = "All" },
                        label = { Text("All Colleges", style = MaterialTheme.typography.labelSmall) }
                    )
                    colleges.forEach { col ->
                        FilterChip(
                            selected = selectedCollegeId == col.id,
                            onClick = { selectedCollegeId = col.id },
                            label = { Text(col.shortCode, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        // Review Cards with 7-Dimension Breakdown
        items(filteredReviews, key = { it.id }) { rev ->
            CollegeReviewAnalysisCard(review = rev)
        }
    }
}

@Composable
private fun CollegeReviewAnalysisCard(review: CollegeReviewRecord) {
    val isPublic = review.reviewCategory == "Public Third-Party Review"
    val badgeColor = if (isPublic) SkyCyan400 else AmberGold400

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, badgeColor.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = badgeColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isPublic) Icons.Default.Public else Icons.Default.RateReview,
                            contentDescription = null,
                            tint = badgeColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = review.reviewCategory.uppercase(Locale.ROOT),
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = AmberGold400, modifier = Modifier.size(18.dp))
                    Text(
                        text = String.format(Locale.US, "%.1f / 5.0", review.overallRating),
                        style = MaterialTheme.typography.titleMedium,
                        color = AmberGold400,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (review.isContextualAiSummary) {
                Surface(
                    color = AmberGold400.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CONTEXTUAL EVIDENCE SYNTHESIS — NOT DIRECT VERBATIM STUDENT QUOTES",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberGold400,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "${review.collegeName} (${review.courseFocus})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Source: ${review.sourceName} • Count: ${review.reviewCount} reviews/debriefs • Retrieved: ${review.retrievedDate}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // 7 Thematic Dimensions Progress Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "7-DIMENSION THEMATIC QUALITY SCORECARD",
                    style = MaterialTheme.typography.labelSmall,
                    color = SkyCyan400,
                    fontWeight = FontWeight.Bold
                )
                review.sevenDimensionList().forEach { (dimTitle, score) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = dimTitle,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1.4f)
                        )
                        LinearProgressIndicator(
                            progress = { (score / 5.0).toFloat().coerceIn(0f, 1f) },
                            color = when {
                                score >= 4.5 -> VerifiedEmerald
                                score >= 4.0 -> SkyCyan400
                                score >= 3.5 -> AmberGold400
                                else -> DiscrepancyRose
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        Text(
                            text = String.format(Locale.US, "%.1f", score),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(28.dp)
                        )
                    }
                }
            }

            // Positive, Negative & Recurring Complaints
            Text(
                text = "Positive Themes: ${review.positiveThemes}",
                style = MaterialTheme.typography.bodySmall,
                color = VerifiedEmerald
            )
            Text(
                text = "Negative Themes: ${review.negativeThemes}",
                style = MaterialTheme.typography.bodySmall,
                color = OutdatedOrange
            )
            if (review.recurringComplaints.isNotBlank()) {
                Text(
                    text = "Recurring Complaints / Red Flags: ${review.recurringComplaints}",
                    style = MaterialTheme.typography.bodySmall,
                    color = DiscrepancyRose
                )
            }
            if (review.dimensionEvidenceSummary.isNotBlank()) {
                Text(
                    text = "Qualitative Evidence Notes: ${review.dimensionEvidenceSummary}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
