package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettingsRecord
import com.example.data.model.BriefingSectionItem
import com.example.data.model.College
import com.example.data.model.CollegeBriefingVersion
import com.example.data.model.ConsultancyModule
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.LiveResearchGroundingResult
import com.example.data.model.SourceVerificationItem
import com.example.data.seed.DemoSeedData
import com.example.ui.components.ClaimReliabilityBadge
import com.example.ui.components.MandatoryAdmissionEnquiryFooter
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrExact
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.ClaimedBlue
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.OutdatedAmber
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.viewmodel.AiTaskState

// ============================================================================
// MODULE 3: LIVE INTERNET RESEARCH ENGINE (GOOGLE SEARCH GROUNDING + DIFF)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveResearchEngineScreen(
    colleges: List<College>,
    courses: List<Course>,
    sourceQueue: List<SourceVerificationItem>,
    activeRole: ConsultancyRole,
    aiTaskState: AiTaskState,
    onRunLiveResearch: (College, Course?, String) -> Unit,
    onPushToSourceQueue: (LiveResearchGroundingResult) -> Unit,
    onNavigateToSourceQueue: () -> Unit
) {
    val uriHandler = LocalUriHandler.current
    var selectedCollegeId by remember(colleges) { mutableStateOf(colleges.firstOrNull()?.id.orEmpty()) }
    val selectedCollege = colleges.firstOrNull { it.id == selectedCollegeId } ?: colleges.firstOrNull()

    val collegeCourses = remember(selectedCollege?.id, courses) {
        courses.filter { it.collegeId == selectedCollege?.id || it.collegeName == selectedCollege?.name }
    }
    var selectedCourseId by remember(selectedCollege?.id, collegeCourses) {
        mutableStateOf(collegeCourses.firstOrNull()?.id.orEmpty())
    }
    val selectedCourse = collegeCourses.firstOrNull { it.id == selectedCourseId }

    val researchTargets = listOf(
        "Verify UGC/AICTE/NMC Status",
        "Fetch Latest 2026-27 Fee Circular",
        "Check NIRF/NAAC Accreditation",
        "Verify Placement Packages",
        "Check Admission Deadlines"
    )
    var selectedTarget by remember { mutableStateOf(researchTargets.first()) }

    val priorityDomains = listOf(
        "ugc.gov.in", "nirfindia.org", "aishe.gov.in",
        "nmc.org.in", "mcc.nic.in", "cetonline.karnataka.gov.in"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Live Internet Research Engine (Google Search Grounding)",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Query live official regulatory & counselling portals, inspect grounded citations, and run side-by-side diffs before queuing updates.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = onNavigateToSourceQueue,
                    modifier = Modifier.testTag("open_source_queue_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Queue (${sourceQueue.count { it.verificationStatus == "Pending Verification" }})")
                }
            }
        }

        // Selector Card: College + Course + Research Target
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "1. SELECT INSTITUTION FOR LIVE GROUNDING",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkyCyan400
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(colleges, key = { it.id }) { col ->
                            FilterChip(
                                selected = selectedCollege?.id == col.id,
                                onClick = { selectedCollegeId = col.id },
                                label = { Text("${col.shortCode} (${col.city})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    if (collegeCourses.isNotEmpty()) {
                        Text(
                            "2. SELECT TARGET PROGRAMME / COURSE",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyCyan400
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedCourse == null,
                                    onClick = { selectedCourseId = "" },
                                    label = { Text("Institution-Wide", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                            items(collegeCourses, key = { it.id }) { crs ->
                                FilterChip(
                                    selected = selectedCourse?.id == crs.id,
                                    onClick = { selectedCourseId = crs.id },
                                    label = { Text("${crs.courseName} (${crs.regulatoryBody})", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }

                    Text(
                        "3. SELECT RESEARCH TARGET",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkyCyan400
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        researchTargets.forEach { target ->
                            FilterChip(
                                selected = selectedTarget == target,
                                onClick = { selectedTarget = target },
                                label = { Text(target, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    Text(
                        "Prioritized Official Domains: " +
                            (priorityDomains + listOfNotNull(selectedCollege?.websiteUrl?.takeIf { it.isNotBlank() }))
                                .joinToString(" • "),
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberGold400
                    )

                    Button(
                        onClick = {
                            if (selectedCollege != null) {
                                onRunLiveResearch(selectedCollege, selectedCourse, selectedTarget)
                            }
                        },
                        enabled = selectedCollege != null && aiTaskState !is AiTaskState.Loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_live_research_btn")
                    ) {
                        Icon(Icons.Default.TravelExplore, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Run Live Google Search Grounding & Side-by-Side Diff")
                    }
                }
            }
        }

        // Grounding Status / Side-by-Side Diff Result Card
        item {
            when (aiTaskState) {
                is AiTaskState.Loading -> {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp)
                            Column {
                                Text(aiTaskState.statusMessage, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Executing Gemini 3.8 Flash with Tool.googleSearch() & parsing groundingMetadata chunks...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                is AiTaskState.LiveResearchSuccess -> {
                    val res = aiTaskState.result
                    LiveResearchDiffResultCard(
                        result = res,
                        activeRole = activeRole,
                        onOpenUrl = { url ->
                            if (url.startsWith("http")) {
                                runCatching { uriHandler.openUri(url) }
                            }
                        },
                        onPushToQueue = { onPushToSourceQueue(res) }
                    )
                }

                is AiTaskState.Error -> {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Live Grounding Error", style = MaterialTheme.typography.titleSmall, color = DiscrepancyRose)
                            Text(aiTaskState.message, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                else -> {}
            }
        }

        // Recent Grounding Findings in Queue Preview
        item {
            Text(
                "RECENT GROUNDING DIFFS IN SOURCE VERIFICATION QUEUE (${sourceQueue.size})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(sourceQueue.take(4), key = { it.id }) { sq ->
            SourceQueueCompactCard(
                item = sq,
                onOpenUrl = { url ->
                    if (url.startsWith("http")) {
                        runCatching { uriHandler.openUri(url) }
                    }
                },
                onOpenQueueModule = onNavigateToSourceQueue
            )
        }
    }
}

@Composable
private fun LiveResearchDiffResultCard(
    result: LiveResearchGroundingResult,
    activeRole: ConsultancyRole,
    onOpenUrl: (String) -> Unit,
    onPushToQueue: () -> Unit
) {
    val isManualRequired = result.sourceUrl.startsWith("Unable to verify online", ignoreCase = true) ||
        result.sourceType == "Manual Document Required"

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (result.hasContradiction || isManualRequired) AmberGold400 else VerifiedEmerald,
                RoundedCornerShape(14.dp)
            )
            .testTag("live_research_diff_card")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "GROUNDED FINDING • ${result.researchTarget.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkyCyan400
                    )
                    Text(
                        text = "${result.collegeName} (${result.courseName})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    color = if (isManualRequired) DiscrepancyRose.copy(alpha = 0.16f) else VerifiedEmerald.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = result.sourceType,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isManualRequired) DiscrepancyRose else VerifiedEmerald,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Metadata Strip: Academic Year, Timestamp, Confidence Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Academic Year: ${result.academicYear} • Retrieved: ${result.retrievedAtIso}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Confidence: ${result.confidenceScore}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberGold400,
                    fontWeight = FontWeight.Bold
                )
            }
            LinearProgressIndicator(
                progress = { (result.confidenceScore / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = if (result.confidenceScore >= 85L) VerifiedEmerald else AmberGold400
            )

            // Side-by-Side Diff Engine
            Text(
                text = "SIDE-BY-SIDE DIFF ENGINE (STORED RECORD VS LIVE WEB EVIDENCE)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "CURRENTLY STORED IN DB (${result.fieldKey})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = result.previousValue.ifBlank { "No prior value recorded." },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Surface(
                    color = if (result.hasContradiction) AmberGold400.copy(alpha = 0.1f) else VerifiedEmerald.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(
                            1.dp,
                            if (result.hasContradiction) AmberGold400 else VerifiedEmerald,
                            RoundedCornerShape(10.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "NEWLY EXTRACTED LIVE VALUE",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (result.hasContradiction) AmberGold400 else VerifiedEmerald,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = result.extractedValue,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Contradiction / Variance Banner
            Surface(
                color = if (result.hasContradiction) DiscrepancyRose.copy(alpha = 0.1f) else VerifiedEmerald.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (result.hasContradiction) Icons.Default.WarningAmber else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (result.hasContradiction) DiscrepancyRose else VerifiedEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (result.hasContradiction) {
                            "CONTRADICTION / CHANGE DETECTED: ${result.contradictionNote}"
                        } else {
                            "VERIFIED MATCH: ${result.contradictionNote}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (result.hasContradiction) DiscrepancyRose else VerifiedEmerald
                    )
                }
            }

            // Primary Source Citation & Clickable URL
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Primary Source: ${result.sourceTitle}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (isManualRequired) {
                        Text(
                            text = "Unable to verify online — manual document required",
                            style = MaterialTheme.typography.bodySmall,
                            color = DiscrepancyRose,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.clickable { onOpenUrl(result.sourceUrl) }
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = "Open Source URL",
                                tint = SkyCyan400,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = result.sourceUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = SkyCyan400,
                                textDecoration = TextDecoration.Underline
                            )
                        }
                    }

                    if (result.allCitations.size > 1) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Additional Grounding Chunks (${result.allCitations.size - 1}):",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        result.allCitations.drop(1).take(3).forEach { (title, url) ->
                            Text(
                                text = "• $title ($url)",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyCyan400,
                                modifier = Modifier.clickable { onOpenUrl(url) }
                            )
                        }
                    }
                }
            }

            if (activeRole.canManageColleges || activeRole.canVerifyRegulatory || activeRole.canRunOcr) {
                Button(
                    onClick = onPushToQueue,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("push_to_source_queue_btn")
                ) {
                    Icon(Icons.Default.Publish, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Push Finding to Source & Verification Queue (Module 15)")
                }
            }
        }
    }
}

@Composable
private fun SourceQueueCompactCard(
    item: SourceVerificationItem,
    onOpenUrl: (String) -> Unit,
    onOpenQueueModule: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .clickable { onOpenQueueModule() }
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${item.collegeName} • ${item.researchTarget}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                VerificationStatusBadge(status = item.verificationStatus)
            }
            Text(
                text = "Extracted: ${item.extractedValue}",
                style = MaterialTheme.typography.bodySmall
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${item.sourceType} • Confidence: ${item.confidenceScore}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberGold400
                )
                Text(
                    text = item.sourceUrl.take(45),
                    style = MaterialTheme.typography.labelSmall,
                    color = SkyCyan400,
                    modifier = Modifier.clickable { onOpenUrl(item.sourceUrl) }
                )
            }
        }
    }
}

// ============================================================================
// MODULE 15: SOURCE & VERIFICATION QUEUE (HUMAN-IN-THE-LOOP DIFF APPROVAL)
// ============================================================================

@Composable
fun SourceVerificationQueueScreen(
    sourceQueue: List<SourceVerificationItem>,
    colleges: List<College>,
    courses: List<Course>,
    activeRole: ConsultancyRole,
    onResolveQueueItem: (SourceVerificationItem, String, List<College>, List<Course>) -> Unit,
    onNavigateToLiveResearch: () -> Unit
) {
    val uriHandler = LocalUriHandler.current
    val statusFilters = listOf(
        "All",
        "Pending Verification",
        "Approved & Applied",
        "Manual Document Required",
        "Rejected"
    )
    var selectedStatus by remember { mutableStateOf("All") }

    val filteredQueue = remember(sourceQueue, selectedStatus) {
        if (selectedStatus == "All") sourceQueue
        else sourceQueue.filter { it.verificationStatus == selectedStatus }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Source & Verification Queue (Human-in-the-Loop)",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Inspect side-by-side diffs from live web grounding before approving & overwriting verified database records.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(onClick = onNavigateToLiveResearch) {
                    Icon(Icons.Default.TravelExplore, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Research")
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(statusFilters) { status ->
                    FilterChip(
                        selected = selectedStatus == status,
                        onClick = { selectedStatus = status },
                        label = { Text(status, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        items(filteredQueue, key = { it.id }) { item ->
            val isManualDoc = item.sourceUrl.startsWith("Unable to verify online", ignoreCase = true) ||
                item.sourceType == "Manual Document Required"

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        when (item.verificationStatus) {
                            "Approved & Applied" -> VerifiedEmerald.copy(alpha = 0.6f)
                            "Manual Document Required" -> DiscrepancyRose.copy(alpha = 0.6f)
                            else -> AmberGold400.copy(alpha = 0.6f)
                        },
                        RoundedCornerShape(14.dp)
                    )
                    .testTag("source_queue_item_${item.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${item.researchTarget} • ${item.academicYear}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyCyan400
                            )
                            Text(
                                text = item.collegeName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Programme: ${item.courseName} • Target Field: ${item.fieldKey}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        VerificationStatusBadge(status = item.verificationStatus)
                    }

                    // Side-by-Side Comparison
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("STORED DB VALUE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(item.previousValue.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Surface(
                            color = if (item.hasContradiction) AmberGold400.copy(alpha = 0.12f) else VerifiedEmerald.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    "EXTRACTED WEB VALUE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (item.hasContradiction) AmberGold400 else VerifiedEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(item.extractedValue, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (item.contradictionNote.isNotBlank()) {
                        Text(
                            text = "Diff Analysis: ${item.contradictionNote}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (item.hasContradiction) AmberGold400 else VerifiedEmerald
                        )
                    }

                    // Source Metadata Block
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Source: ${item.sourceTitle}", style = MaterialTheme.typography.labelMedium)
                                Text("Confidence: ${item.confidenceScore}%", style = MaterialTheme.typography.labelSmall, color = AmberGold400)
                            }
                            Text(
                                text = "Type: ${item.sourceType} • Retrieved: ${item.retrievedAtIso}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (isManualDoc) {
                                Text(
                                    text = "Unable to verify online — manual document required",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = DiscrepancyRose,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = item.sourceUrl,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SkyCyan400,
                                    textDecoration = TextDecoration.Underline,
                                    modifier = Modifier.clickable {
                                        if (item.sourceUrl.startsWith("http")) {
                                            runCatching { uriHandler.openUri(item.sourceUrl) }
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // RBAC Approval Actions
                    if (activeRole.canVerifyRegulatory || activeRole.canReviewFees) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onResolveQueueItem(item, "Approved & Applied", colleges, courses)
                                },
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approve & Apply", style = MaterialTheme.typography.labelSmall)
                            }
                            OutlinedButton(
                                onClick = {
                                    onResolveQueueItem(item, "Manual Document Required", colleges, courses)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Manual Doc Req", style = MaterialTheme.typography.labelSmall)
                            }
                            TextButton(
                                onClick = {
                                    onResolveQueueItem(item, "Rejected", colleges, courses)
                                }
                            ) {
                                Text("Reject", color = DiscrepancyRose, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// MODULE 10: 20-POINT AI COLLEGE BRIEFING ENGINE (WITH VERSIONING & DIFF)
// ============================================================================

@Composable
fun AiCollegeBriefingEngineScreen(
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    sourceQueue: List<SourceVerificationItem>,
    briefingVersions: List<CollegeBriefingVersion>,
    appSettings: AppSettingsRecord,
    activeRole: ConsultancyRole,
    onSaveBriefingVersion: (College, String, String, List<BriefingSectionItem>, List<CollegeBriefingVersion>) -> Unit,
    onNavigateToExports: () -> Unit
) {
    val context = LocalContext.current
    var selectedCollegeId by remember(colleges) { mutableStateOf(colleges.firstOrNull()?.id.orEmpty()) }
    val selectedCollege = colleges.firstOrNull { it.id == selectedCollegeId } ?: colleges.firstOrNull()

    val collegeVersions = remember(selectedCollege?.id, selectedCollege?.name, briefingVersions) {
        briefingVersions.filter {
            it.collegeId == selectedCollege?.id || it.collegeName == selectedCollege?.name
        }.sortedByDescending { it.versionNumber }
    }

    var selectedVersionId by remember(selectedCollege?.id, collegeVersions.size) {
        mutableStateOf(collegeVersions.firstOrNull()?.id.orEmpty())
    }
    val activeSavedVersion = collegeVersions.firstOrNull { it.id == selectedVersionId }

    val synthesizedSections = remember(selectedCollege, courses, feeDocs, sourceQueue, appSettings) {
        if (selectedCollege == null) emptyList()
        else DemoSeedData.generate20PointBriefingSections(
            college = selectedCollege,
            courses = courses.filter { it.collegeId == selectedCollege.id || it.collegeName == selectedCollege.name },
            feeDocs = feeDocs.filter { it.collegeId == selectedCollege.id || it.collegeName == selectedCollege.name },
            sourceQueue = sourceQueue.filter { it.collegeId == selectedCollege.id || it.collegeName == selectedCollege.name },
            enquiryFooter = appSettings.formattedFooterBlock()
        )
    }

    var workingSections by remember(selectedCollege?.id, activeSavedVersion?.id) {
        mutableStateOf(
            activeSavedVersion?.parseSections()?.takeIf { it.size == 20 } ?: synthesizedSections
        )
    }

    LaunchedEffect(selectedCollege?.id, activeSavedVersion?.id, synthesizedSections) {
        val parsed = activeSavedVersion?.parseSections()?.takeIf { it.size == 20 }
        workingSections = parsed ?: synthesizedSections
    }

    var editingSection by remember { mutableStateOf<BriefingSectionItem?>(null) }
    var showSaveVersionDialog by remember { mutableStateOf(false) }
    var compareWithPrevious by remember { mutableStateOf(false) }

    val previousVersionSections = remember(collegeVersions, activeSavedVersion) {
        val older = collegeVersions.firstOrNull { it.versionNumber < (activeSavedVersion?.versionNumber ?: Long.MAX_VALUE) }
            ?: collegeVersions.lastOrNull()
        older?.parseSections().orEmpty()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "20-Point AI College Intelligence Briefing Engine",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Synthesizes verified DB records, clinical hospital metrics, fee audits & grounded citations into a 20-section versioned dossier.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(onClick = onNavigateToExports) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Print / Export")
                }
            }
        }

        // College Selector & Version Control Bar
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SELECT INSTITUTION:", style = MaterialTheme.typography.labelSmall, color = SkyCyan400)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(colleges, key = { it.id }) { col ->
                            FilterChip(
                                selected = selectedCollege?.id == col.id,
                                onClick = { selectedCollegeId = col.id },
                                label = { Text("${col.shortCode} (${col.city})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "SAVED BRIEFING VERSIONS (${collegeVersions.size}):",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold400
                        )
                        if (collegeVersions.size > 1) {
                            FilterChip(
                                selected = compareWithPrevious,
                                onClick = { compareWithPrevious = !compareWithPrevious },
                                label = { Text("Compare Historical Versions", style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = {
                                    Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, modifier = Modifier.size(15.dp))
                                }
                            )
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(collegeVersions, key = { it.id }) { ver ->
                            FilterChip(
                                selected = activeSavedVersion?.id == ver.id,
                                onClick = { selectedVersionId = ver.id },
                                label = {
                                    Text(
                                        "${ver.versionLabel} (${ver.editedByRole})",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            )
                        }
                        item {
                            FilterChip(
                                selected = activeSavedVersion == null,
                                onClick = {
                                    selectedVersionId = ""
                                    workingSections = synthesizedSections
                                },
                                label = { Text("Live DB Synthesis Draft", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (activeRole.canManageColleges || activeRole.canVerifyRegulatory) {
                            Button(
                                onClick = { showSaveVersionDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("save_briefing_version_btn")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save New Briefing Version")
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                if (selectedCollege != null) {
                                    printHtmlReport(
                                        context = context,
                                        jobName = "${selectedCollege.shortCode}_20Point_Briefing",
                                        htmlContent = buildBriefingPrintHtml(
                                            college = selectedCollege,
                                            sections = workingSections,
                                            appSettings = appSettings
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print / PDF")
                        }
                    }
                }
            }
        }

        // All 20 Mandated Sections
        items(workingSections, key = { it.sectionNumber }) { section ->
            val olderSection = previousVersionSections.firstOrNull { it.sectionNumber == section.sectionNumber }
            val hasDiffVsOlder = compareWithPrevious && olderSection != null && olderSection.content != section.content

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (section.sectionNumber == 12 || section.sectionNumber == 20) AmberGold400.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f),
                        RoundedCornerShape(12.dp)
                    )
                    .testTag("briefing_section_${section.sectionNumber}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SECTION ${section.sectionNumber} OF 20",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyCyan400
                            )
                            Text(
                                text = "${section.sectionNumber}. ${section.title}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        ClaimReliabilityBadge(badge = section.claimBadge)
                    }

                    if (section.sectionNumber == 20) {
                        // Locked Mandatory Admission Enquiry Contact Footer
                        MandatoryAdmissionEnquiryFooter(
                            enquiryHeader = appSettings.enquiryHeader,
                            enquiryPhone = appSettings.enquiryPhone
                        )
                    } else {
                        Text(
                            text = section.content,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    if (hasDiffVsOlder && olderSection != null) {
                        Surface(
                            color = AmberGold400.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "PREVIOUS VERSION CONTENT:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberGold400
                                )
                                Text(
                                    olderSection.content,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Citation: ${section.sourceCitation}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        if ((activeRole.canManageColleges || activeRole.canVerifyRegulatory) && section.sectionNumber != 20) {
                            TextButton(onClick = { editingSection = section }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Section", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Edit Section", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Final Mandatory Footer Block at the very end of the Briefing view
        item {
            MandatoryAdmissionEnquiryFooter(
                enquiryHeader = appSettings.enquiryHeader,
                enquiryPhone = appSettings.enquiryPhone
            )
        }
    }

    if (editingSection != null) {
        val sec = editingSection!!
        var contentText by remember(sec) { mutableStateOf(sec.content) }
        var selectedBadge by remember(sec) { mutableStateOf(sec.claimBadge) }
        var citationText by remember(sec) { mutableStateOf(sec.sourceCitation) }
        val badgeOptions = listOf(
            "Verified Official",
            "College-Provided Unverified",
            "Third-Party",
            "Not Publicly Reported"
        )

        AlertDialog(
            onDismissRequest = { editingSection = null },
            title = { Text("Edit Section ${sec.sectionNumber}: ${sec.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Claim Reliability Badge:", style = MaterialTheme.typography.labelMedium)
                    badgeOptions.forEach { b ->
                        FilterChip(
                            selected = selectedBadge == b,
                            onClick = { selectedBadge = b },
                            label = { Text(b, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    OutlinedTextField(
                        value = contentText,
                        onValueChange = { contentText = it },
                        label = { Text("Section Content") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = citationText,
                        onValueChange = { citationText = it },
                        label = { Text("Source Citation") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        workingSections = workingSections.map {
                            if (it.sectionNumber == sec.sectionNumber) {
                                it.copy(
                                    content = contentText.trim(),
                                    claimBadge = selectedBadge,
                                    sourceCitation = citationText.trim()
                                )
                            } else it
                        }
                        editingSection = null
                    }
                ) {
                    Text("Apply Edit to Draft")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSection = null }) { Text("Cancel") }
            }
        )
    }

    if (showSaveVersionDialog && selectedCollege != null) {
        val nextNum = (collegeVersions.maxOfOrNull { it.versionNumber } ?: 0L) + 1L
        var versionLabel by remember { mutableStateOf("v$nextNum.0 — Verified Consultant Update") }
        var courseFocus by remember {
            mutableStateOf(
                courses.filter { it.collegeId == selectedCollege.id }
                    .joinToString { it.courseName }
                    .ifBlank { "All Approved Programmes" }
            )
        }

        AlertDialog(
            onDismissRequest = { showSaveVersionDialog = false },
            title = { Text("Save New 20-Point Briefing Version") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = versionLabel,
                        onValueChange = { versionLabel = it },
                        label = { Text("Version Label") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = courseFocus,
                        onValueChange = { courseFocus = it },
                        label = { Text("Course / Quota Focus") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveBriefingVersion(
                            selectedCollege,
                            courseFocus,
                            versionLabel,
                            workingSections,
                            collegeVersions
                        )
                        showSaveVersionDialog = false
                    }
                ) {
                    Text("Save Version v$nextNum.0")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveVersionDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ============================================================================
// MODULE 13: REPORTS & EXPORTS (PDF PRINT PREVIEW & EXCEL/CSV EXPORT)
// ============================================================================

@Composable
fun ReportsAndExportsScreen(
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    sourceQueue: List<SourceVerificationItem>,
    appSettings: AppSettingsRecord
) {
    val context = LocalContext.current
    val reportTypes = listOf(
        "20-Point College Intelligence Briefing",
        "Fee Verification & Discrepancy Audit Report",
        "Bank Education Loan Fee Quotation"
    )
    var selectedReportType by remember { mutableStateOf(reportTypes.first()) }
    var selectedCollegeId by remember(colleges) { mutableStateOf(colleges.firstOrNull()?.id.orEmpty()) }
    val selectedCollege = colleges.firstOrNull { it.id == selectedCollegeId } ?: colleges.firstOrNull()
    var lastExportPreview by remember { mutableStateOf<String?>(null) }

    val collegeCourses = remember(selectedCollege?.id, courses) {
        courses.filter { it.collegeId == selectedCollege?.id || it.collegeName == selectedCollege?.name }
    }
    val collegeFees = remember(selectedCollege?.id, feeDocs) {
        feeDocs.filter { it.collegeId == selectedCollege?.id || it.collegeName == selectedCollege?.name }
    }
    val collegeQueue = remember(selectedCollege?.id, sourceQueue) {
        sourceQueue.filter { it.collegeId == selectedCollege?.id || it.collegeName == selectedCollege?.name }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "Reports, Printable PDF Briefings & Excel/CSV Exports",
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                "Generate parent-ready PDF dossiers, Fee Verification Audit sheets, and Bank Loan Quotations with guaranteed unclipped Admission Enquiry footer.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. SELECT REPORT TEMPLATE", style = MaterialTheme.typography.labelSmall, color = SkyCyan400)
                    reportTypes.forEach { rt ->
                        FilterChip(
                            selected = selectedReportType == rt,
                            onClick = { selectedReportType = rt },
                            label = { Text(rt, style = MaterialTheme.typography.labelMedium) }
                        )
                    }

                    Text("2. SELECT TARGET INSTITUTION", style = MaterialTheme.typography.labelSmall, color = SkyCyan400)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(colleges, key = { it.id }) { col ->
                            FilterChip(
                                selected = selectedCollege?.id == col.id,
                                onClick = { selectedCollegeId = col.id },
                                label = { Text("${col.shortCode} (${col.city})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (selectedCollege != null) {
                                    val sections = DemoSeedData.generate20PointBriefingSections(
                                        college = selectedCollege,
                                        courses = collegeCourses,
                                        feeDocs = collegeFees,
                                        sourceQueue = collegeQueue,
                                        enquiryFooter = appSettings.formattedFooterBlock()
                                    )
                                    val html = buildBriefingPrintHtml(
                                        college = selectedCollege,
                                        sections = sections,
                                        appSettings = appSettings,
                                        reportTitle = selectedReportType
                                    )
                                    printHtmlReport(
                                        context = context,
                                        jobName = "${selectedCollege.shortCode}_${selectedReportType.take(16).replace(" ", "_")}",
                                        htmlContent = html
                                    )
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("print_pdf_report_btn")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print / Save PDF")
                        }

                        OutlinedButton(
                            onClick = {
                                if (selectedCollege != null) {
                                    val csv = buildStructuredCsvExport(
                                        reportType = selectedReportType,
                                        college = selectedCollege,
                                        courses = collegeCourses,
                                        feeDocs = collegeFees,
                                        appSettings = appSettings
                                    )
                                    lastExportPreview = csv
                                    shareTextPayload(
                                        context = context,
                                        title = "${selectedCollege.shortCode} — $selectedReportType (CSV)",
                                        content = csv
                                    )
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_csv_report_btn")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Excel/CSV")
                        }
                    }
                }
            }
        }

        if (lastExportPreview != null) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("STRUCTURED CSV / EXCEL PAYLOAD PREVIEW", style = MaterialTheme.typography.labelSmall, color = VerifiedEmerald)
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = lastExportPreview!!,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Live Report Document Preview with Mandatory Admission Enquiry Footer
        if (selectedCollege != null) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
                        .testTag("printable_report_preview_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REPORT PREVIEW • ${selectedReportType.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyCyan400
                            )
                            VerificationStatusBadge(status = selectedCollege.verificationStatus)
                        }

                        Text(
                            text = selectedCollege.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${selectedCollege.city}, ${selectedCollege.state} • Ownership: ${selectedCollege.ownership} • Type: ${selectedCollege.institutionType}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Degree-Awarding University: ${selectedCollege.degreeAwardingUniversity}",
                            style = MaterialTheme.typography.titleSmall,
                            color = AmberGold400
                        )

                        HorizontalDivider()

                        when (selectedReportType) {
                            "Bank Education Loan Fee Quotation" -> {
                                Text(
                                    "IBA / VIDYA LAKSHMI BANK EDUCATION LOAN FEE BREAKDOWN (2026-27)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = VerifiedEmerald
                                )
                                if (collegeFees.isEmpty()) {
                                    collegeCourses.forEach { c ->
                                        Text(
                                            "• ${c.courseName} (${c.specialization}): ${c.quotaFeesSummary} | Duration: ${c.durationYears} Yrs",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                } else {
                                    collegeFees.forEach { f ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    "${f.courseName} — ${f.quotaCategory} (${f.academicYear})",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text("1. Annual Tuition Fee (Loan Eligible): ${formatInrExact(f.tuitionFeeAnnualInr)}", style = MaterialTheme.typography.bodySmall)
                                                Text("2. Official Hostel & Mess Fee (Loan Eligible): ${formatInrExact(f.hostelAndMessAnnualInr)}", style = MaterialTheme.typography.bodySmall)
                                                Text("3. Refundable Caution Deposit: ${formatInrExact(f.cautionDepositInr)}", style = MaterialTheme.typography.bodySmall)
                                                Text("4. Exam / University / Other Charges: ${formatInrExact(f.otherChargesInr)}", style = MaterialTheme.typography.bodySmall)
                                                Text(
                                                    "Total 1st Year Official Disbursement Requirement: ${formatInrExact(f.totalFirstYearInr)}",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = SkyCyan400,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            "Fee Verification & Discrepancy Audit Report" -> {
                                Text(
                                    "GEMINI OCR FEE CIRCULAR VERIFICATION & DISCREPANCY LEDGER",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AmberGold400
                                )
                                collegeFees.forEach { f ->
                                    Text(
                                        "• ${f.courseName} [${f.quotaCategory}]: 1st Yr Total ${formatInrExact(f.totalFirstYearInr)} — Status: ${f.reviewStatus}. ${f.discrepancyDetails.ifBlank { f.webComparisonNotes }}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }

                            else -> {
                                Text(
                                    "EXECUTIVE SUMMARY & VERIFIED SOURCES",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = SkyCyan400
                                )
                                Text(
                                    text = selectedCollege.regulatorDetailsSummary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                collegeCourses.forEach { c ->
                                    Text(
                                        "• ${c.courseName} (${c.specialization}) — Intake: ${c.intake} | Lateral Entry: ${if (c.isLateralEntry) "Yes" else "No"} | ${c.quotaFeesSummary}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        HorizontalDivider()

                        // Mandatory Admission Enquiry Contact Footer at the very end of the report
                        MandatoryAdmissionEnquiryFooter(
                            enquiryHeader = appSettings.enquiryHeader,
                            enquiryPhone = appSettings.enquiryPhone
                        )
                    }
                }
            }
        }
    }
}

private fun buildStructuredCsvExport(
    reportType: String,
    college: College,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    appSettings: AppSettingsRecord
): String {
    val sb = StringBuilder()
    sb.appendLine("Report Type,\"$reportType\"")
    sb.appendLine("Institution Name,\"${college.name}\"")
    sb.appendLine("Short Code,\"${college.shortCode}\"")
    sb.appendLine("Location,\"${college.city}, ${college.state}\"")
    sb.appendLine("Ownership,\"${college.ownership}\"")
    sb.appendLine("Institution Type,\"${college.institutionType}\"")
    sb.appendLine("Degree-Awarding University,\"${college.degreeAwardingUniversity}\"")
    sb.appendLine("Verification Status,\"${college.verificationStatus}\"")
    sb.appendLine("NAAC Grade,\"${college.naacGrade} (${college.naacCgpa})\"")
    sb.appendLine("NIRF Rank,\"${college.nirfRank}\"")
    sb.appendLine()
    sb.appendLine("Course,Specialization,Stream,Duration(Yrs),Intake,LateralEntry,MinTuitionINR,MaxTuitionINR,QuotaFeeSummary")
    courses.forEach { c ->
        sb.appendLine("\"${c.courseName}\",\"${c.specialization}\",\"${c.stream}\",${c.durationYears},${c.intake},${c.isLateralEntry},${c.annualTuitionMinInr},${c.annualTuitionMaxInr},\"${c.quotaFeesSummary}\"")
    }
    sb.appendLine()
    sb.appendLine("FeeDocCourse,AcademicYear,QuotaCategory,TuitionINR,HostelMessINR,CautionINR,OtherINR,TotalFirstYearINR,ReviewStatus,DiscrepancyNotes")
    feeDocs.forEach { f ->
        sb.appendLine("\"${f.courseName}\",\"${f.academicYear}\",\"${f.quotaCategory}\",${f.tuitionFeeAnnualInr},${f.hostelAndMessAnnualInr},${f.cautionDepositInr},${f.otherChargesInr},${f.totalFirstYearInr},\"${f.reviewStatus}\",\"${f.discrepancyDetails}\"")
    }
    sb.appendLine()
    sb.appendLine(appSettings.enquiryHeader)
    sb.appendLine(appSettings.enquiryPhone)
    return sb.toString()
}

private fun buildBriefingPrintHtml(
    college: College,
    sections: List<BriefingSectionItem>,
    appSettings: AppSettingsRecord,
    reportTitle: String = "20-Point College Intelligence Briefing"
): String {
    val sectionsHtml = sections.filter { it.sectionNumber != 20 }.joinToString("\n") { sec ->
        """
        <div class="section">
            <div class="sec-head">
                <span class="sec-title">${sec.sectionNumber}. ${sec.title}</span>
                <span class="badge">${sec.claimBadge}</span>
            </div>
            <p class="sec-body">${sec.content.replace("\n", "<br/>")}</p>
            <div class="citation">Source Citation: ${sec.sourceCitation}</div>
        </div>
        """.trimIndent()
    }

    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8"/>
            <title>${college.name} — $reportTitle</title>
            <style>
                body { font-family: sans-serif; color: #0F172A; margin: 24px; line-height: 1.45; }
                h1 { font-size: 20px; margin-bottom: 4px; color: #0F172A; }
                .subtitle { font-size: 12px; color: #475569; margin-bottom: 16px; }
                .meta-box { background: #F1F5F9; border: 1px solid #CBD5E1; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 12px; }
                .section { border-bottom: 1px solid #E2E8F0; padding: 10px 0; page-break-inside: avoid; }
                .sec-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
                .sec-title { font-weight: bold; font-size: 13px; color: #1E3A8A; }
                .badge { font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 4px; background: #E0F2FE; color: #0369A1; }
                .sec-body { font-size: 12px; margin: 4px 0; }
                .citation { font-size: 10px; color: #64748B; }
                .enquiry-footer {
                    margin-top: 24px;
                    padding: 14px;
                    border: 2px solid #0F172A;
                    border-radius: 8px;
                    background: #F8FAFC;
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .enquiry-header { font-size: 12px; font-weight: bold; letter-spacing: 0.5px; color: #0F172A; }
                .enquiry-phone { font-size: 16px; font-weight: bold; color: #0F172A; margin-top: 2px; }
                @media print {
                    .enquiry-footer { page-break-inside: avoid; break-inside: avoid; }
                }
            </style>
        </head>
        <body>
            <h1>${college.name} (${college.shortCode})</h1>
            <div class="subtitle">$reportTitle • ${college.city}, ${college.state}</div>
            <div class="meta-box">
                <strong>Ownership:</strong> ${college.ownership} |
                <strong>Institution Type:</strong> ${college.institutionType} |
                <strong>Degree-Awarding University:</strong> ${college.degreeAwardingUniversity} |
                <strong>NAAC:</strong> ${college.naacGrade} (${college.naacCgpa}) |
                <strong>NIRF:</strong> #${college.nirfRank}
            </div>
            $sectionsHtml
            <div class="enquiry-footer">
                <div class="enquiry-header">${appSettings.enquiryHeader}</div>
                <div class="enquiry-phone">${appSettings.enquiryPhone}</div>
            </div>
        </body>
        </html>
    """.trimIndent()
}

internal fun printHtmlReport(context: Context, jobName: String, htmlContent: String) {
    runCatching {
        val safeName = jobName.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".html"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        val outFile = File(dir, safeName)
        outFile.writeText(htmlContent, Charsets.UTF_8)
        Toast.makeText(
            context,
            "Saved report $safeName to Downloads",
            Toast.LENGTH_LONG
        ).show()
    }
}

private fun shareTextPayload(context: Context, title: String, content: String) {
    runCatching {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, content)
        }
        context.startActivity(Intent.createChooser(sendIntent, title))
    }
}
