package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Enterprise Dark Palette (Default Slate/Indigo/Amber Intelligence Theme)
val Slate950 = Color(0xFF070B14)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate50 = Color(0xFFF8FAFC)

// Brand & Semantic Accents
val AmberGold500 = Color(0xFFF59E0B)
val AmberGold400 = Color(0xFFFBBF24)
val SkyCyan400 = Color(0xFF38BDF8)
val SkyCyan600 = Color(0xFF0284C7)
val Indigo500 = Color(0xFF6366F1)

// Status Colors
val VerifiedEmerald = Color(0xFF10B981)
val ClaimedBlue = Color(0xFF3B82F6)
val OutdatedAmber = Color(0xFFF59E0B)
val OutdatedOrange = Color(0xFFF97316)
val DiscrepancyRose = Color(0xFFF43F5E)
