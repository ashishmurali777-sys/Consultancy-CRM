package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettingsRecord
import com.example.data.model.College
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.ComparisonSlot
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.PlacementRecord
import com.example.data.model.SourceVerificationItem
import com.example.data.model.WeightedCollegeScoreBreakdown
import com.example.ui.components.MandatoryAdmissionEnquiryFooter
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrExact
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import java.util.Locale
import kotlin.math.roundToInt

private val QUOTA_OPTIONS = listOf(
    "Government / Merit",
    "COMEDK / Consortium",
    "Management / Institutional",
    "NRI / Foreign"
)

private val ACADEMIC_YEAR_OPTIONS = listOf("2026-27", "2025-26")

private data class EnrichedComparisonSlotData(
    val slot: ComparisonSlot,
    val college: College,
    val course: Course?,
    val matchedFeeDoc: FeeDocument?,
    val domesticPlacement: PlacementRecord?,
    val internationalPlacement: PlacementRecord?,
    val collegeReviews: List<CollegeReviewRecord>,
    val annualTuitionInr: Long,
    val totalTuitionProgrammeInr: Long,
    val annualHostelMessInr: Long,
    val hostelInclusiveTotalCostInr: Long,
    val bondAndPenaltySummary: String,
    val clinicalExposureSummary: String,
    val avgReviewScore: Double,
    val upcomingDeadline: String,
    val verificationCoveragePct: Int,
    val scoreBreakdown: WeightedCollegeScoreBreakdown
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CollegeComparisonEngineScreen(
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    placements: List<PlacementRecord>,
    reviews: List<CollegeReviewRecord>,
    sourceQueue: List<SourceVerificationItem>,
    appSettings: AppSettingsRecord
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Initialize 3 default comparison slots (supports 2 to 5 colleges)
    var slots by remember(colleges, courses) {
        val initialColleges = colleges.take(3)
        val built = initialColleges.mapIndexed { idx, col ->
            val defaultCourse = courses.firstOrNull { it.collegeId == col.id || it.collegeName == col.name }
            ComparisonSlot(
                slotIndex = idx,
                collegeId = col.id,
                courseId = defaultCourse?.id.orEmpty(),
                selectedQuota = "Government / Merit",
                selectedAcademicYear = "2026-27"
            )
        }
        mutableStateOf(built)
    }

    var activeEditingSlotIndex by remember { mutableStateOf(0) }

    // Priority Weight Sliders (Defaults: Budget/Low Fees 35%, Placements/ROI 25%, Clinical/Infra 25%, Regulatory/Ranking 15%)
    var rawBudgetWeight by remember { mutableFloatStateOf(35f) }
    var rawPlacementWeight by remember { mutableFloatStateOf(25f) }
    var rawClinicalInfraWeight by remember { mutableFloatStateOf(25f) }
    var rawRegulatoryRankWeight by remember { mutableFloatStateOf(15f) }

    val totalRawWeight = (rawBudgetWeight + rawPlacementWeight + rawClinicalInfraWeight + rawRegulatoryRankWeight).coerceAtLeast(1f)
    val normBudgetPct = ((rawBudgetWeight / totalRawWeight) * 100f).roundToInt()
    val normPlacementPct = ((rawPlacementWeight / totalRawWeight) * 100f).roundToInt()
    val normClinicalInfraPct = ((rawClinicalInfraWeight / totalRawWeight) * 100f).roundToInt()
    val normRegulatoryPct = (100 - normBudgetPct - normPlacementPct - normClinicalInfraPct).coerceAtLeast(0)

    var showFormulaBreakdown by remember { mutableStateOf(true) }
    var exportFeedback by remember { mutableStateOf<String?>(null) }

    // Check Normalization Mismatches (Quota or Academic Year differences across slots)
    val distinctQuotas = remember(slots) { slots.map { it.selectedQuota }.distinct() }
    val distinctYears = remember(slots) { slots.map { it.selectedAcademicYear }.distinct() }
    val hasQuotaMismatch = distinctQuotas.size > 1
    val hasYearMismatch = distinctYears.size > 1

    // Build enriched comparison models & transparent mathematical scores
    val enrichedSlots = remember(
        slots,
        colleges,
        courses,
        feeDocs,
        placements,
        reviews,
        sourceQueue,
        normBudgetPct,
        normPlacementPct,
        normClinicalInfraPct,
        normRegulatoryPct
    ) {
        slots.mapNotNull { slot ->
            val col = colleges.firstOrNull { it.id == slot.collegeId } ?: colleges.firstOrNull() ?: return@mapNotNull null
            val colCourses = courses.filter { it.collegeId == col.id || it.collegeName == col.name }
            val crs = colCourses.firstOrNull { it.id == slot.courseId } ?: colCourses.firstOrNull()

            val colFeeDocs = feeDocs.filter { it.collegeId == col.id || it.collegeName == col.name }
            val matchedFeeDoc = colFeeDocs.firstOrNull {
                it.quotaCategory.equals(slot.selectedQuota, ignoreCase = true) &&
                    it.academicYear == slot.selectedAcademicYear
            } ?: colFeeDocs.firstOrNull {
                it.quotaCategory.contains(slot.selectedQuota.substringBefore(" "), ignoreCase = true)
            } ?: colFeeDocs.firstOrNull()

            val durationYrs = crs?.durationYears ?: 4.0
            val durationMultiplier = durationYrs.coerceAtLeast(1.0)

            val annualTuition = when {
                matchedFeeDoc != null && matchedFeeDoc.quotaCategory.contains(slot.selectedQuota.substringBefore(" "), ignoreCase = true) ->
                    matchedFeeDoc.tuitionFeeAnnualInr
                slot.selectedQuota.contains("Government", ignoreCase = true) || slot.selectedQuota.contains("Merit", ignoreCase = true) ->
                    crs?.annualTuitionMinInr ?: matchedFeeDoc?.tuitionFeeAnnualInr ?: 150000L
                slot.selectedQuota.contains("COMEDK", ignoreCase = true) || slot.selectedQuota.contains("Consortium", ignoreCase = true) ->
                    ((crs?.annualTuitionMinInr ?: 150000L) + (crs?.annualTuitionMaxInr ?: 400000L)) / 2L
                slot.selectedQuota.contains("NRI", ignoreCase = true) ->
                    ((crs?.annualTuitionMaxInr ?: 800000L) * 14L) / 10L
                else -> crs?.annualTuitionMaxInr ?: matchedFeeDoc?.tuitionFeeAnnualInr ?: 450000L
            }

            val annualHostel = matchedFeeDoc?.hostelAndMessAnnualInr ?: 135000L
            val oneTimeCharges = (matchedFeeDoc?.cautionDepositInr ?: 25000L) + (matchedFeeDoc?.otherChargesInr ?: 20000L)
            val totalTuitionProgramme = (annualTuition * durationMultiplier).toLong()
            val hostelInclusiveTotal = ((annualTuition + annualHostel) * durationMultiplier).toLong() + oneTimeCharges

            val colPlacements = placements.filter { it.collegeId == col.id || it.collegeName == col.name }
            val domPlacement = colPlacements
                .filter { it.offerScope == "Domestic" }
                .maxByOrNull { it.academicYear }
            val intlPlacement = colPlacements
                .filter { it.offerScope == "International" }
                .maxByOrNull { it.academicYear }

            val colReviews = reviews.filter { it.collegeId == col.id || it.collegeName == col.name }
            val avgReview = if (colReviews.isNotEmpty()) {
                colReviews.map { it.overallRating }.average()
            } else 4.1

            val isMedicalOrHealth = col.institutionType.contains("Medical", ignoreCase = true) ||
                col.regulators.any { it in listOf("NMC", "DCI", "INC", "IAP") }

            val bondSummary = when {
                col.shortCode.contains("KMC", ignoreCase = true) ->
                    "1-Yr Compulsory Rotating Medical Internship; Deemed University seat-leaving penalty = full remaining course fee"
                col.shortCode.contains("SJMCH", ignoreCase = true) || col.name.contains("St. John", ignoreCase = true) ->
                    "Mandatory 2-Year Rural Medical Service Bond in designated rural health centers (Penalty ₹25L)"
                col.shortCode.contains("AIIMS", ignoreCase = true) ->
                    "1-Year Mandatory Internship; Seat surrender penalty ₹5L post-round 2 MCC counselling"
                isMedicalOrHealth ->
                    "1-Year Compulsory Clinical Internship + State Counselling Seat Forfeiture Rules apply"
                else ->
                    "No mandatory post-graduation service bond; AICTE/UGC fee refund norm applies on withdrawal"
            }

            val clinicalSummary = when {
                col.shortCode.contains("KMC", ignoreCase = true) ->
                    "2,032 Teaching Hospital Beds (Kasturba Hospital) • 3,800+ Daily OPD • Super-specialty ICUs"
                col.shortCode.contains("SJMCH", ignoreCase = true) || col.name.contains("St. John", ignoreCase = true) ->
                    "1,350 Tertiary Care Beds • 2,900+ Daily OPD • High-volume trauma & rural outreach clinics"
                col.shortCode.contains("AIIMS", ignoreCase = true) ->
                    "3,100+ Apex Tertiary Beds • 10,000+ Daily OPD • National Referral Clinical Research Labs"
                else ->
                    "Industry CoE Labs, High-Performance Computing Clusters & Mandatory Final-Year Industry Capstone"
            }

            val deadlineSummary = when {
                crs?.entranceExams?.any { it.contains("NEET") } == true ->
                    "MCC / KEA NEET-UG Round 1 Choice Filling: Aug 14, 2026"
                crs?.entranceExams?.any { it.contains("KCET") || it.contains("COMEDK") } == true ->
                    "KEA KCET / COMEDK Counselling Verification: Jul 28, 2026"
                else ->
                    "Institutional Merit & Entrance Window: Jun 30, 2026"
            }

            val verifiedDocsCount = colFeeDocs.count { it.reviewStatus == "Approved" }
            val verifiedSourcesCount = sourceQueue.count {
                (it.collegeId == col.id || it.collegeName == col.name) && it.verificationStatus == "Approved & Applied"
            }
            val coveragePct = when {
                col.verificationStatus == "Verified" && !col.needsRefresh ->
                    (88 + (verifiedDocsCount * 4) + (verifiedSourcesCount * 3)).coerceAtMost(99)
                col.verificationStatus == "Partially Verified" -> 74
                else -> 58
            }

            // Transparent Mathematical Sub-Scores (0..100 scale)
            // 1. Budget / Low Fees Score: ₹3L total = 98 pts, ₹100L+ total = 15 pts (linearly scaled)
            val totalLakhs = hostelInclusiveTotal / 100000.0
            val feeSubScore = (100.0 - (totalLakhs * 0.95)).coerceIn(12.0, 98.0)

            // 2. Placements / ROI Score: Combines Domestic Avg Package (LPA), Placement Rate %, and Fee-to-Package ROI ratio
            val domAvgLpa = (domPlacement?.averagePackageLpa?.takeIf { it > 0.0 } ?: 6.5)
            val placementRate = (domPlacement?.placementRatePercent?.takeIf { it > 0.0 } ?: 82.0).coerceIn(0.0, 100.0)
            val annualRoiRatio = (domAvgLpa / (totalLakhs / durationMultiplier).coerceAtLeast(0.5)).coerceIn(0.1, 4.0)
            val placementSubScore = (
                (placementRate * 0.45) +
                    ((domAvgLpa * 3.2).coerceAtMost(35.0)) +
                    ((annualRoiRatio * 7.5).coerceAtMost(20.0))
                ).coerceIn(20.0, 99.0)

            // 3. Clinical / Infrastructure Score: Based on review infrastructure + clinical exposure + hospital/lab strength
            val reviewInfraAvg = if (colReviews.isNotEmpty()) {
                colReviews.map {
                    (it.infrastructureLabsRating + it.clinicalPracticalRating + it.facultyQualityRating) / 3.0
                }.average()
            } else 4.2
            val clinicalBonus = if (col.shortCode in listOf("AIIMS", "KMC", "SJMCH", "RVCE")) 10.0 else 4.0
            val clinicalInfraSubScore = (((reviewInfraAvg / 5.0) * 88.0) + clinicalBonus).coerceIn(35.0, 99.0)

            // 4. Regulatory / Ranking Strength Score: NAAC CGPA + NIRF Rank + Verification Status
            val naacComponent = ((col.naacCgpa / 4.0) * 45.0).coerceIn(15.0, 45.0)
            val nirfComponent = (35.0 - (col.nirfRank.coerceIn(1, 100) * 0.32)).coerceIn(5.0, 35.0)
            val verifComponent = when (col.verificationStatus) {
                "Verified" -> 20.0
                "Partially Verified" -> 12.0
                else -> 6.0
            }
            val regulatorySubScore = (naacComponent + nirfComponent + verifComponent).coerceIn(25.0, 99.0)

            val wFee = (feeSubScore * normBudgetPct) / 100.0
            val wPlace = (placementSubScore * normPlacementPct) / 100.0
            val wClin = (clinicalInfraSubScore * normClinicalInfraPct) / 100.0
            val wReg = (regulatorySubScore * normRegulatoryPct) / 100.0
            val totalScore = (wFee + wPlace + wClin + wReg).coerceIn(0.0, 100.0)

            val formulaString = String.format(
                Locale.US,
                "(%.1f × %d%% Fee) + (%.1f × %d%% ROI) + (%.1f × %d%% Infra/Clinical) + (%.1f × %d%% Reg/Rank) = %.1f / 100",
                feeSubScore,
                normBudgetPct,
                placementSubScore,
                normPlacementPct,
                clinicalInfraSubScore,
                normClinicalInfraPct,
                regulatorySubScore,
                normRegulatoryPct,
                totalScore
            )

            EnrichedComparisonSlotData(
                slot = slot,
                college = col,
                course = crs,
                matchedFeeDoc = matchedFeeDoc,
                domesticPlacement = domPlacement,
                internationalPlacement = intlPlacement,
                collegeReviews = colReviews,
                annualTuitionInr = annualTuition,
                totalTuitionProgrammeInr = totalTuitionProgramme,
                annualHostelMessInr = annualHostel,
                hostelInclusiveTotalCostInr = hostelInclusiveTotal,
                bondAndPenaltySummary = bondSummary,
                clinicalExposureSummary = clinicalSummary,
                avgReviewScore = avgReview,
                upcomingDeadline = deadlineSummary,
                verificationCoveragePct = coveragePct,
                scoreBreakdown = WeightedCollegeScoreBreakdown(
                    collegeId = col.id,
                    collegeShortCode = col.shortCode,
                    collegeName = col.name,
                    courseName = crs?.courseName ?: "General Programme",
                    selectedQuota = slot.selectedQuota,
                    feeSubScore = feeSubScore,
                    placementRoiSubScore = placementSubScore,
                    clinicalInfraSubScore = clinicalInfraSubScore,
                    regulatoryRankingSubScore = regulatorySubScore,
                    feeWeightPercent = normBudgetPct.toDouble(),
                    placementWeightPercent = normPlacementPct.toDouble(),
                    clinicalWeightPercent = normClinicalInfraPct.toDouble(),
                    regulatoryWeightPercent = normRegulatoryPct.toDouble(),
                    weightedFeeContribution = wFee,
                    weightedPlacementContribution = wPlace,
                    weightedClinicalContribution = wClin,
                    weightedRegulatoryContribution = wReg,
                    finalSuitabilityScore = totalScore,
                    formulaExplanation = formulaString
                )
            )
        }
    }

    val bestRankedSlot = remember(enrichedSlots) {
        enrichedSlots.maxByOrNull { it.scoreBreakdown.finalSuitabilityScore }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header + Subtitle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Side-by-Side College Comparison Engine (2–5 Colleges)",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Quota-normalized matrix across 15 institutional, fee, clinical, placement & deadline metrics with transparent mathematical suitability scoring.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Slot Count Controls (2 to 5 Colleges) & Quick Presets
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, tint = SkyCyan400)
                            Text(
                                text = "COMPARING ${slots.size} COLLEGES (MIN 2 • MAX 5)",
                                style = MaterialTheme.typography.labelMedium,
                                color = SkyCyan400,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    if (slots.size > 2) {
                                        slots = slots.dropLast(1).mapIndexed { idx, s -> s.copy(slotIndex = idx) }
                                        if (activeEditingSlotIndex >= slots.size) {
                                            activeEditingSlotIndex = slots.lastIndex
                                        }
                                    }
                                },
                                enabled = slots.size > 2,
                                modifier = Modifier.testTag("remove_comparison_slot_btn")
                            ) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("- Slot")
                            }

                            Button(
                                onClick = {
                                    if (slots.size < 5 && colleges.isNotEmpty()) {
                                        val usedIds = slots.map { it.collegeId }.toSet()
                                        val nextCol = colleges.firstOrNull { it.id !in usedIds } ?: colleges[slots.size % colleges.size]
                                        val nextCrs = courses.firstOrNull { it.collegeId == nextCol.id || it.collegeName == nextCol.name }
                                        val refQuota = slots.firstOrNull()?.selectedQuota ?: "Government / Merit"
                                        val refYear = slots.firstOrNull()?.selectedAcademicYear ?: "2026-27"
                                        val newSlot = ComparisonSlot(
                                            slotIndex = slots.size,
                                            collegeId = nextCol.id,
                                            courseId = nextCrs?.id.orEmpty(),
                                            selectedQuota = refQuota,
                                            selectedAcademicYear = refYear
                                        )
                                        slots = slots + newSlot
                                        activeEditingSlotIndex = slots.lastIndex
                                    }
                                },
                                enabled = slots.size < 5,
                                modifier = Modifier.testTag("add_comparison_slot_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add College (${slots.size}/5)")
                            }
                        }
                    }

                    // Quick Comparison Presets
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                val engCols = colleges.filter {
                                    it.shortCode in listOf("RVCE", "SRMIST", "CU") ||
                                        it.regulators.contains("AICTE")
                                }.take(3).ifEmpty { colleges.take(3) }
                                slots = engCols.mapIndexed { idx, c ->
                                    val crs = courses.firstOrNull { it.collegeId == c.id || it.collegeName == c.name }
                                    ComparisonSlot(idx, c.id, crs?.id.orEmpty(), "Government / Merit", "2026-27")
                                }
                                activeEditingSlotIndex = 0
                            },
                            label = { Text("Preset: Top Engineering / Tech (3)", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val medCols = colleges.filter {
                                    it.shortCode in listOf("KMC", "SJMCH", "AIIMS") ||
                                        it.regulators.contains("NMC")
                                }.take(3).ifEmpty { colleges.take(3) }
                                slots = medCols.mapIndexed { idx, c ->
                                    val crs = courses.firstOrNull { it.collegeId == c.id || it.collegeName == c.name }
                                    ComparisonSlot(idx, c.id, crs?.id.orEmpty(), "Government / Merit", "2026-27")
                                }
                                activeEditingSlotIndex = 0
                            },
                            label = { Text("Preset: Medical & Allied Health (3)", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = slots.size == 5,
                            onClick = {
                                val fiveCols = colleges.take(5)
                                slots = fiveCols.mapIndexed { idx, c ->
                                    val crs = courses.firstOrNull { it.collegeId == c.id || it.collegeName == c.name }
                                    ComparisonSlot(idx, c.id, crs?.id.orEmpty(), "Government / Merit", "2026-27")
                                }
                                activeEditingSlotIndex = 0
                            },
                            label = { Text("Compare 5 Institutions Max", style = MaterialTheme.typography.labelSmall) }
                        )
                    }

                    HorizontalDivider()

                    // Slot Selector Tabs
                    Text(
                        "CONFIGURE SLOT #${activeEditingSlotIndex + 1} (TAP SLOT CHIP TO CHANGE COLLEGE, COURSE, QUOTA OR YEAR):",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberGold400
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        enrichedSlots.forEachIndexed { idx, item ->
                            FilterChip(
                                selected = activeEditingSlotIndex == idx,
                                onClick = { activeEditingSlotIndex = idx },
                                label = {
                                    Text(
                                        "Slot ${idx + 1}: ${item.college.shortCode} • ${item.slot.selectedQuota.substringBefore(" ")} (${item.slot.selectedAcademicYear})",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (activeEditingSlotIndex == idx) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("comparison_slot_chip_$idx")
                            )
                        }
                    }

                    // Active Slot Configuration Panel
                    val activeSlot = slots.getOrNull(activeEditingSlotIndex)
                    if (activeSlot != null) {
                        val activeCollege = colleges.firstOrNull { it.id == activeSlot.collegeId } ?: colleges.firstOrNull()
                        val availableCourses = remember(activeCollege, courses) {
                            courses.filter { it.collegeId == activeCollege?.id || it.collegeName == activeCollege?.name }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    "Slot #${activeEditingSlotIndex + 1} Institution:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SkyCyan400
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    colleges.forEach { col ->
                                        FilterChip(
                                            selected = activeSlot.collegeId == col.id,
                                            onClick = {
                                                val defaultCrs = courses.firstOrNull { it.collegeId == col.id || it.collegeName == col.name }
                                                slots = slots.mapIndexed { i, s ->
                                                    if (i == activeEditingSlotIndex) {
                                                        s.copy(collegeId = col.id, courseId = defaultCrs?.id.orEmpty())
                                                    } else s
                                                }
                                            },
                                            label = { Text("${col.shortCode} (${col.city})", style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }

                                if (availableCourses.isNotEmpty()) {
                                    Text(
                                        "Slot #${activeEditingSlotIndex + 1} Programme / Specialization:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SkyCyan400
                                    )
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        availableCourses.forEach { crs ->
                                            FilterChip(
                                                selected = activeSlot.courseId == crs.id,
                                                onClick = {
                                                    slots = slots.mapIndexed { i, s ->
                                                        if (i == activeEditingSlotIndex) s.copy(courseId = crs.id) else s
                                                    }
                                                },
                                                label = { Text("${crs.courseName} (${crs.specialization})", style = MaterialTheme.typography.labelSmall) }
                                            )
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1.4f)) {
                                        Text("Admission Quota:", style = MaterialTheme.typography.labelSmall, color = AmberGold400)
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            QUOTA_OPTIONS.forEach { q ->
                                                FilterChip(
                                                    selected = activeSlot.selectedQuota == q,
                                                    onClick = {
                                                        slots = slots.mapIndexed { i, s ->
                                                            if (i == activeEditingSlotIndex) s.copy(selectedQuota = q) else s
                                                        }
                                                    },
                                                    label = { Text(q, style = MaterialTheme.typography.labelSmall) }
                                                )
                                            }
                                        }
                                    }

                                    Column(modifier = Modifier.weight(0.8f)) {
                                        Text("Academic Year:", style = MaterialTheme.typography.labelSmall, color = AmberGold400)
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            ACADEMIC_YEAR_OPTIONS.forEach { yr ->
                                                FilterChip(
                                                    selected = activeSlot.selectedAcademicYear == yr,
                                                    onClick = {
                                                        slots = slots.mapIndexed { i, s ->
                                                            if (i == activeEditingSlotIndex) s.copy(selectedAcademicYear = yr) else s
                                                        }
                                                    },
                                                    label = { Text(yr, style = MaterialTheme.typography.labelSmall) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Normalization & Mismatch Safeguard Warning Banner
        if (hasQuotaMismatch || hasYearMismatch) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DiscrepancyRose.copy(alpha = 0.14f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DiscrepancyRose, RoundedCornerShape(12.dp))
                        .testTag("normalization_warning_banner")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = DiscrepancyRose)
                            Text(
                                text = "NORMALIZATION SAFEGUARD WARNING: MISMATCHED COMPARISON PARAMETERS",
                                style = MaterialTheme.typography.labelMedium,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (hasQuotaMismatch) {
                            Text(
                                text = "• Admission Quota Mismatch Detected: You are comparing across different quotas (${distinctQuotas.joinToString(" vs ")}). Comparing Government Merit fees against Management/NRI fees skews Budget & ROI suitability scores.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (hasYearMismatch) {
                            Text(
                                text = "• Academic Year Mismatch Detected: Selected slots span multiple fee cycles (${distinctYears.joinToString(" vs ")}).",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        val targetQuota = slots.firstOrNull()?.selectedQuota ?: "Government / Merit"
                        val targetYear = slots.firstOrNull()?.selectedAcademicYear ?: "2026-27"
                        Button(
                            onClick = {
                                slots = slots.map { it.copy(selectedQuota = targetQuota, selectedAcademicYear = targetYear) }
                            },
                            modifier = Modifier.testTag("normalize_all_slots_btn")
                        ) {
                            Text("Normalize All Slots to $targetQuota ($targetYear)")
                        }
                    }
                }
            }
        }

        // Transparent Weighted Scoring Calculator
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SkyCyan400.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = AmberGold400)
                            Column {
                                Text(
                                    text = "TRANSPARENT WEIGHTED SUITABILITY CALCULATOR",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AmberGold400,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Deterministic formula — zero opaque AI scoring. Adjust priority sliders to recalculate.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                rawBudgetWeight = 35f
                                rawPlacementWeight = 25f
                                rawClinicalInfraWeight = 25f
                                rawRegulatoryRankWeight = 15f
                            },
                            modifier = Modifier.testTag("reset_weights_btn")
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset Weights to 35/25/25/15")
                        }
                    }

                    // 4 Weight Sliders
                    WeightSliderRow(
                        label = "1. Budget / Low Total Programme Cost",
                        normalizedPct = normBudgetPct,
                        rawValue = rawBudgetWeight,
                        onValueChange = { rawBudgetWeight = it }
                    )
                    WeightSliderRow(
                        label = "2. Placements & Domestic Salary ROI",
                        normalizedPct = normPlacementPct,
                        rawValue = rawPlacementWeight,
                        onValueChange = { rawPlacementWeight = it }
                    )
                    WeightSliderRow(
                        label = "3. Clinical Hospital / Lab Infrastructure Quality",
                        normalizedPct = normClinicalInfraPct,
                        rawValue = rawClinicalInfraWeight,
                        onValueChange = { rawClinicalInfraWeight = it }
                    )
                    WeightSliderRow(
                        label = "4. Regulatory Approvals, NAAC & NIRF Strength",
                        normalizedPct = normRegulatoryPct,
                        rawValue = rawRegulatoryRankWeight,
                        onValueChange = { rawRegulatoryRankWeight = it }
                    )

                    // Suitability Score Cards + Mathematical Breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MATHEMATICAL SCORE BREAKDOWN BY INSTITUTION:",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyCyan400,
                            fontWeight = FontWeight.Bold
                        )
                        FilterChip(
                            selected = showFormulaBreakdown,
                            onClick = { showFormulaBreakdown = !showFormulaBreakdown },
                            label = { Text(if (showFormulaBreakdown) "Hide Formula Steps" else "Show Formula Steps", style = MaterialTheme.typography.labelSmall) },
                            leadingIcon = { Icon(Icons.Default.Functions, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                    }

                    enrichedSlots.sortedByDescending { it.scoreBreakdown.finalSuitabilityScore }.forEachIndexed { rankIdx, item ->
                        val b = item.scoreBreakdown
                        val isWinner = item.college.id == bestRankedSlot?.college?.id && item.slot.slotIndex == bestRankedSlot.slot.slotIndex
                        Surface(
                            color = if (isWinner) VerifiedEmerald.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isWinner) VerifiedEmerald else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                    RoundedCornerShape(10.dp)
                                )
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (isWinner) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = VerifiedEmerald, modifier = Modifier.size(18.dp))
                                        }
                                        Text(
                                            text = "#${rankIdx + 1} ${b.collegeName} (${b.collegeShortCode}) — ${b.selectedQuota.substringBefore(" ")}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Surface(
                                        color = if (isWinner) VerifiedEmerald else AmberGold400.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = String.format(Locale.US, "%.1f / 100", b.finalSuitabilityScore),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (isWinner) MaterialTheme.colorScheme.surface else AmberGold400,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                LinearProgressIndicator(
                                    progress = { (b.finalSuitabilityScore / 100.0).toFloat().coerceIn(0f, 1f) },
                                    color = if (isWinner) VerifiedEmerald else SkyCyan400,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                )

                                if (showFormulaBreakdown) {
                                    Text(
                                        text = "Formula: ${b.formulaExplanation}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        color = SkyCyan400
                                    )
                                    Text(
                                        text = String.format(
                                            Locale.US,
                                            "Contributions: Budget +%.1f pts (Sub-score %.0f/100) • Placement ROI +%.1f pts (%.0f/100) • Clinical/Infra +%.1f pts (%.0f/100) • Regulatory/Rank +%.1f pts (%.0f/100)",
                                            b.weightedFeeContribution,
                                            b.feeSubScore,
                                            b.weightedPlacementContribution,
                                            b.placementRoiSubScore,
                                            b.weightedClinicalContribution,
                                            b.clinicalInfraSubScore,
                                            b.weightedRegulatoryContribution,
                                            b.regulatoryRankingSubScore
                                        ),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Side-by-Side Horizontal Scrollable Comparison Matrix Across All 15 Core Rows
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SIDE-BY-SIDE COMPARISON MATRIX (${enrichedSlots.size} COLLEGES × 15 CORE DIMENSIONS)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Scroll horizontally to inspect all ${enrichedSlots.size} selected institutions side-by-side.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    val horizontalScrollState = rememberScrollState()
                    val rowDefinitions: List<Pair<String, (EnrichedComparisonSlotData) -> String>> = remember {
                        listOf(
                            "1. Institutional Status & Ownership" to { d ->
                                "${d.college.ownership} • ${d.college.institutionType} (Est. ${d.college.establishedYear})"
                            },
                            "2. Degree-Awarding University" to { d ->
                                "Degree By: ${d.college.degreeAwardingUniversity}\nAffiliation: ${d.college.affiliatedTo}"
                            },
                            "3. Regulatory Approvals & Ranking" to { d ->
                                "${d.college.regulators.joinToString(", ")}\nNAAC ${d.college.naacGrade} (${d.college.naacCgpa}) • NIRF #${d.college.nirfRank}"
                            },
                            "4. Course, Specialization & Duration" to { d ->
                                val c = d.course
                                if (c != null) "${c.courseName} (${c.specialization})\nDuration: ${c.durationYears} Yrs • Intake: ${c.intake} seats"
                                else "General Institutional Track"
                            },
                            "5. Eligibility, Exams & Lateral Entry" to { d ->
                                val c = d.course
                                if (c != null) {
                                    "Exams: ${c.entranceExams.joinToString(", ")}\nEligibility: ${c.eligibility}\nLateral Entry: ${if (c.isLateralEntry) "Available (Direct 2nd-Year Entry)" else "Not Applicable"}"
                                } else "Standard 10+2 Qualifying Exam"
                            },
                            "6. Selected Admission Quota & Cycle" to { d ->
                                "${d.slot.selectedQuota}\nAcademic Year: ${d.slot.selectedAcademicYear}"
                            },
                            "7. Annual & Total Programme Tuition" to { d ->
                                "Annual Tuition: ${formatInrExact(d.annualTuitionInr)}/yr\nTotal Course Tuition: ${formatInrLakhs(d.totalTuitionProgrammeInr)}"
                            },
                            "8. Hostel-Inclusive Total Cost" to { d ->
                                "Total Outlay: ${formatInrLakhs(d.hostelInclusiveTotalCostInr)}\n(Includes ${formatInrExact(d.annualHostelMessInr)}/yr Hostel+Mess & 1st Yr Caution/Exam)"
                            },
                            "9. Mandatory Bonds & Penalties" to { d ->
                                d.bondAndPenaltySummary
                            },
                            "10. Highest / Avg / Median Package" to { d ->
                                val dom = d.domesticPlacement
                                val intl = d.internationalPlacement
                                val domText = if (dom != null) {
                                    "DOMESTIC (${dom.academicYear} • ${dom.scopeType}):\nHigh: ${dom.formatHighestLpa()} | Avg: ${dom.formatAverageLpa()} | Med: ${dom.formatMedianLpa()}"
                                } else {
                                    "Domestic: Not Publicly Reported"
                                }
                                val intlText = if (intl != null && intl.highestPackageLpa > 0.0) {
                                    "\nINTL OUTLIER: ${intl.formatHighestLpa()} (Separated)"
                                } else ""
                                domText + intlText
                            },
                            "11. Placement Rate % & Cohort" to { d ->
                                val dom = d.domesticPlacement
                                if (dom != null) {
                                    val rateStr = dom.formatPlacementRate()
                                    val cohortStr = if (dom.placedStudents > 0 && dom.eligibleStudents > 0) {
                                        "${dom.placedStudents}/${dom.eligibleStudents} placed (${dom.formatCount(dom.totalRecruiters)} recruiters)"
                                    } else "Cohort count Not Publicly Reported"
                                    "Placement Rate: $rateStr\n$cohortStr"
                                } else {
                                    "Not Publicly Reported"
                                }
                            },
                            "12. Clinical Exposure / Hospital Beds" to { d ->
                                d.clinicalExposureSummary
                            },
                            "13. Student & Consultancy Review Score" to { d ->
                                val topTheme = d.collegeReviews.firstOrNull()?.positiveThemes?.take(85) ?: "Verified Academic & Lab Track"
                                String.format(
                                    Locale.US,
                                    "%.1f / 5.0 (%d sources)\n%s",
                                    d.avgReviewScore,
                                    d.collegeReviews.size,
                                    topTheme
                                )
                            },
                            "14. Upcoming Admission Deadline" to { d ->
                                d.upcomingDeadline
                            },
                            "15. Data Freshness & Verification %" to { d ->
                                val freshnessLabel = if (d.college.needsRefresh) "Refresh Flagged" else "2026-27 Verified Cycle"
                                "${d.college.verificationStatus} • ${d.verificationCoveragePct}% Verified Coverage\nAudit Cycle: $freshnessLabel"
                            },
                            "16. Weighted Suitability Score" to { d ->
                                String.format(
                                    Locale.US,
                                    "%.1f / 100\n%s",
                                    d.scoreBreakdown.finalSuitabilityScore,
                                    d.scoreBreakdown.formulaExplanation
                                )
                            }
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        // Header Row
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.width(190.dp).padding(end = 8.dp)) {
                                Text(
                                    text = "COMPARISON DIMENSION",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AmberGold400,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            enrichedSlots.forEachIndexed { idx, slotData ->
                                Box(
                                    modifier = Modifier
                                        .width(235.dp)
                                        .padding(horizontal = 8.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = "Slot ${idx + 1}: ${slotData.college.shortCode}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SkyCyan400,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = slotData.college.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1
                                        )
                                        VerificationStatusBadge(status = slotData.college.verificationStatus)
                                    }
                                }
                            }
                        }

                        HorizontalDivider()

                        // Data Rows
                        rowDefinitions.forEachIndexed { rowIdx, (rowLabel, extractor) ->
                            val rowBg = if (rowIdx % 2 == 0) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                            }
                            Row(
                                modifier = Modifier
                                    .background(rowBg)
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(modifier = Modifier.width(190.dp).padding(end = 8.dp)) {
                                    Text(
                                        text = rowLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (rowIdx == rowDefinitions.lastIndex) AmberGold400 else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                enrichedSlots.forEach { slotData ->
                                    Box(
                                        modifier = Modifier
                                            .width(235.dp)
                                            .padding(horizontal = 8.dp)
                                    ) {
                                        Text(
                                            text = extractor(slotData),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = if (rowIdx == rowDefinitions.lastIndex) FontWeight.Bold else FontWeight.Normal,
                                            color = if (rowIdx == rowDefinitions.lastIndex) VerifiedEmerald else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        }
                    }
                }
            }
        }

        // Export & Print Toolbar (PDF PrintManager + Excel/CSV with Mandatory Footer Enforcement)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberGold400.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "EXPORT SIDE-BY-SIDE COMPARISON REPORT (WITH LOCKED ENQUIRY FOOTER)",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberGold400,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Every exported Printable PDF and Excel/CSV comparison sheet automatically appends the tamper-locked ADMISSION ENQUIRIES block.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (exportFeedback != null) {
                        Text(
                            text = exportFeedback!!,
                            style = MaterialTheme.typography.labelMedium,
                            color = VerifiedEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val html = buildComparisonPrintHtml(
                                    slots = enrichedSlots,
                                    normBudgetPct = normBudgetPct,
                                    normPlacementPct = normPlacementPct,
                                    normClinicalInfraPct = normClinicalInfraPct,
                                    normRegulatoryPct = normRegulatoryPct,
                                    appSettings = appSettings
                                )
                                printComparisonHtmlReport(
                                    context = context,
                                    jobName = "EduIntel_College_Comparison_${enrichedSlots.size}_Colleges",
                                    htmlContent = html
                                )
                                exportFeedback = "Launched Android PrintManager PDF Preview with ADMISSION ENQUIRIES (+91 70122 74141) footer."
                            },
                            modifier = Modifier.testTag("export_comparison_pdf_btn")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print / Save PDF Comparison")
                        }

                        OutlinedButton(
                            onClick = {
                                val csv = buildComparisonCsvExport(
                                    slots = enrichedSlots,
                                    normBudgetPct = normBudgetPct,
                                    normPlacementPct = normPlacementPct,
                                    normClinicalInfraPct = normClinicalInfraPct,
                                    normRegulatoryPct = normRegulatoryPct,
                                    appSettings = appSettings
                                )
                                clipboardManager.setText(AnnotatedString(csv))
                                exportFeedback = "Copied ${enrichedSlots.size}-College CSV Comparison Matrix (with ADMISSION ENQUIRIES +91 70122 74141) to clipboard."
                            },
                            modifier = Modifier.testTag("copy_comparison_csv_btn")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy Excel/CSV")
                        }

                        OutlinedButton(
                            onClick = {
                                val csv = buildComparisonCsvExport(
                                    slots = enrichedSlots,
                                    normBudgetPct = normBudgetPct,
                                    normPlacementPct = normPlacementPct,
                                    normClinicalInfraPct = normClinicalInfraPct,
                                    normRegulatoryPct = normRegulatoryPct,
                                    appSettings = appSettings
                                )
                                runCatching {
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/csv"
                                        putExtra(Intent.EXTRA_SUBJECT, "EduIntel College Comparison Report (${enrichedSlots.size} Colleges)")
                                        putExtra(Intent.EXTRA_TEXT, csv)
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Export College Comparison CSV"))
                                }
                            },
                            modifier = Modifier.testTag("share_comparison_csv_btn")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share CSV")
                        }
                    }
                }
            }
        }

        // Mandatory Admission Enquiry Footer at the bottom of the Comparison Report
        item {
            MandatoryAdmissionEnquiryFooter(
                enquiryHeader = appSettings.enquiryHeader,
                enquiryPhone = appSettings.enquiryPhone
            )
        }
    }
}

@Composable
private fun WeightSliderRow(
    label: String,
    normalizedPct: Int,
    rawValue: Float,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodySmall)
            Text(
                text = "$normalizedPct%",
                style = MaterialTheme.typography.labelMedium,
                color = SkyCyan400,
                fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = rawValue,
            onValueChange = onValueChange,
            valueRange = 0f..100f,
            modifier = Modifier.height(26.dp)
        )
    }
}

private fun buildComparisonCsvExport(
    slots: List<EnrichedComparisonSlotData>,
    normBudgetPct: Int,
    normPlacementPct: Int,
    normClinicalInfraPct: Int,
    normRegulatoryPct: Int,
    appSettings: AppSettingsRecord
): String {
    val sb = StringBuilder()
    sb.appendLine("EduIntel Side-by-Side College Comparison Matrix (${slots.size} Institutions)")
    sb.appendLine("Weights,\"Budget=${normBudgetPct}%, Placements/ROI=${normPlacementPct}%, Clinical/Infra=${normClinicalInfraPct}%, Regulatory/Ranking=${normRegulatoryPct}%\"")
    sb.appendLine()

    fun row(label: String, values: (EnrichedComparisonSlotData) -> String) {
        val cells = slots.joinToString(",") { "\"${values(it).replace("\"", "'").replace("\n", " | ")}\"" }
        sb.appendLine("\"$label\",$cells")
    }

    row("Institution Name") { "${it.college.name} (${it.college.shortCode})" }
    row("City & State") { "${it.college.city}, ${it.college.state}" }
    row("Institutional Status") { "${it.college.ownership} - ${it.college.institutionType}" }
    row("Degree-Awarding University") { it.college.degreeAwardingUniversity }
    row("Regulatory Approvals") { "${it.college.regulators.joinToString("/")} | NAAC ${it.college.naacGrade} | NIRF #${it.college.nirfRank}" }
    row("Course & Duration") { "${it.course?.courseName ?: "General"} (${it.course?.specialization ?: ""}) - ${it.course?.durationYears ?: 4.0} Yrs" }
    row("Eligibility & Entrance Exam") { "${it.course?.eligibility ?: ""} | Exams: ${it.course?.entranceExams?.joinToString("/") ?: ""}" }
    row("Admission Quota & Year") { "${it.slot.selectedQuota} (${it.slot.selectedAcademicYear})" }
    row("Annual Tuition Fee (INR)") { it.annualTuitionInr.toString() }
    row("Total Programme Tuition (INR)") { it.totalTuitionProgrammeInr.toString() }
    row("Hostel-Inclusive Total Cost (INR)") { it.hostelInclusiveTotalCostInr.toString() }
    row("Mandatory Bonds / Penalties") { it.bondAndPenaltySummary }
    row("Domestic Highest / Avg / Median Package") {
        val d = it.domesticPlacement
        if (d != null) {
            "High: ${d.formatHighestLpa()} | Avg: ${d.formatAverageLpa()} | Med: ${d.formatMedianLpa()}"
        } else "Not Publicly Reported"
    }
    row("Placement Rate %") {
        it.domesticPlacement?.formatPlacementRate() ?: "Not Publicly Reported"
    }
    row("Clinical Exposure / Hospital Bed Strength") { it.clinicalExposureSummary }
    row("Student & Internal Review Score") { String.format(Locale.US, "%.1f / 5.0", it.avgReviewScore) }
    row("Upcoming Admission Deadline") { it.upcomingDeadline }
    row("Verification Coverage %") { "${it.college.verificationStatus} (${it.verificationCoveragePct}%)" }
    row("Weighted Suitability Score (/100)") { String.format(Locale.US, "%.1f / 100 (%s)", it.scoreBreakdown.finalSuitabilityScore, it.scoreBreakdown.formulaExplanation) }

    sb.appendLine()
    sb.appendLine(appSettings.enquiryHeader)
    sb.appendLine(appSettings.enquiryPhone)
    return sb.toString()
}

private fun buildComparisonPrintHtml(
    slots: List<EnrichedComparisonSlotData>,
    normBudgetPct: Int,
    normPlacementPct: Int,
    normClinicalInfraPct: Int,
    normRegulatoryPct: Int,
    appSettings: AppSettingsRecord
): String {
    val headersHtml = slots.joinToString("") {
        "<th>${it.college.name}<br/><small>${it.college.shortCode} • ${it.slot.selectedQuota}</small></th>"
    }

    fun tr(label: String, cellBuilder: (EnrichedComparisonSlotData) -> String): String {
        val tds = slots.joinToString("") { "<td>${cellBuilder(it).replace("\n", "<br/>")}</td>" }
        return "<tr><td class='dim'>$label</td>$tds</tr>"
    }

    val rowsHtml = listOf(
        tr("1. Institutional Status") { "${it.college.ownership} • ${it.college.institutionType}" },
        tr("2. Degree-Awarding University") { "${it.college.degreeAwardingUniversity}<br/><small>Affiliated: ${it.college.affiliatedTo}</small>" },
        tr("3. Regulatory & Ranking") { "${it.college.regulators.joinToString(", ")}<br/>NAAC ${it.college.naacGrade} (${it.college.naacCgpa}) • NIRF #${it.college.nirfRank}" },
        tr("4. Course & Duration") { "${it.course?.courseName ?: "General"} (${it.course?.specialization ?: ""})<br/>${it.course?.durationYears ?: 4.0} Years" },
        tr("5. Eligibility & Entrance Exam") { "${it.course?.eligibility ?: ""}<br/>Exams: ${it.course?.entranceExams?.joinToString(", ") ?: ""}" },
        tr("6. Quota & Academic Year") { "${it.slot.selectedQuota} (${it.slot.selectedAcademicYear})" },
        tr("7. Annual & Total Tuition") { "Annual: ${formatInrExact(it.annualTuitionInr)}<br/>Total Tuition: ${formatInrLakhs(it.totalTuitionProgrammeInr)}" },
        tr("8. Hostel-Inclusive Total Cost") { "<strong>${formatInrLakhs(it.hostelInclusiveTotalCostInr)}</strong>" },
        tr("9. Mandatory Bonds / Penalties") { it.bondAndPenaltySummary },
        tr("10. Domestic Package (High/Avg/Med)") {
            val d = it.domesticPlacement
            if (d != null) {
                "High: ${d.formatHighestLpa()}<br/>Avg: ${d.formatAverageLpa()}<br/>Med: ${d.formatMedianLpa()}"
            } else "Not Publicly Reported"
        },
        tr("11. Placement Rate %") {
            it.domesticPlacement?.formatPlacementRate() ?: "Not Publicly Reported"
        },
        tr("12. Clinical / Lab Exposure") { it.clinicalExposureSummary },
        tr("13. Student Review Score") { String.format(Locale.US, "%.1f / 5.0 (%d sources)", it.avgReviewScore, it.collegeReviews.size) },
        tr("14. Upcoming Deadline") { it.upcomingDeadline },
        tr("15. Verification Coverage") { "${it.college.verificationStatus} (${it.verificationCoveragePct}%)" },
        tr("16. Suitability Score & Formula") {
            String.format(
                Locale.US,
                "<strong>%.1f / 100</strong><br/><small>%s</small>",
                it.scoreBreakdown.finalSuitabilityScore,
                it.scoreBreakdown.formulaExplanation
            )
        }
    ).joinToString("\n")

    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8"/>
            <title>Side-by-Side College Comparison Report</title>
            <style>
                body { font-family: sans-serif; color: #0F172A; margin: 18px; font-size: 11px; }
                h1 { font-size: 18px; margin-bottom: 4px; }
                .sub { font-size: 11px; color: #475569; margin-bottom: 12px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
                th, td { border: 1px solid #CBD5E1; padding: 6px 8px; text-align: left; vertical-align: top; }
                th { background: #0F172A; color: #F8FAFC; font-size: 11px; }
                td.dim { font-weight: bold; background: #F1F5F9; width: 150px; }
                .enquiry-footer {
                    margin-top: 20px;
                    padding: 14px;
                    border: 2px solid #0F172A;
                    border-radius: 8px;
                    background: #F8FAFC;
                    page-break-inside: avoid;
                    break-inside: avoid;
                }
                .enquiry-header { font-size: 12px; font-weight: bold; color: #0F172A; }
                .enquiry-phone { font-size: 16px; font-weight: bold; color: #0F172A; margin-top: 2px; }
                @media print {
                    .enquiry-footer { page-break-inside: avoid; break-inside: avoid; }
                }
            </style>
        </head>
        <body>
            <h1>Side-by-Side College Comparison Matrix (${slots.size} Institutions)</h1>
            <div class="sub">
                Priority Weights: Budget/Low Fees $normBudgetPct% • Placements/ROI $normPlacementPct% • Clinical/Infrastructure $normClinicalInfraPct% • Regulatory/Ranking $normRegulatoryPct%
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Comparison Dimension</th>
                        $headersHtml
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>
            <div class="enquiry-footer">
                <div class="enquiry-header">${appSettings.enquiryHeader}</div>
                <div class="enquiry-phone">${appSettings.enquiryPhone}</div>
            </div>
        </body>
        </html>
    """.trimIndent()
}

private fun printComparisonHtmlReport(context: Context, jobName: String, htmlContent: String) {
    runCatching {
        val safeName = jobName.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".html"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        val outFile = File(dir, safeName)
        outFile.writeText(htmlContent, Charsets.UTF_8)
        Toast.makeText(
            context,
            "Saved report $safeName to Downloads",
            Toast.LENGTH_LONG
        ).show()
    }
}
