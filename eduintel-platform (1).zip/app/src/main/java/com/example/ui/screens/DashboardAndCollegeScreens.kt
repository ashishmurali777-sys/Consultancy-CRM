package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.College
import com.example.data.model.ConsultancyModule
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.StudentEnquiry
import com.example.data.model.TeamTaskRecord
import com.example.ui.components.CollegeEditorDialog
import com.example.ui.components.CourseEditorDialog
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.ClaimedBlue
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.OutdatedAmber
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald

private data class KpiMetric(
    val key: String,
    val title: String,
    val value: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OperationalDashboardScreen(
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    enquiries: List<StudentEnquiry>,
    tasks: List<TeamTaskRecord> = emptyList(),
    activeRole: ConsultancyRole,
    globalSearchQuery: String = "",
    onKpiClicked: (String) -> Unit,
    onNavigateModule: (ConsultancyModule) -> Unit,
    onReseedDemo: () -> Unit,
    onOpenAddCollegeModal: () -> Unit = {},
    onOpenAddCourseModal: () -> Unit = {},
    onOpenAddStudentModal: () -> Unit = {},
    onOpenAddTaskModal: () -> Unit = {},
    onRefreshDashboard: () -> Unit = {}
) {
    LaunchedEffect(Unit) {
        onRefreshDashboard()
    }

    val q = globalSearchQuery.trim()

    // RBAC-filtered student leads: Admins see all; Counselors see permitted leads
    val rbacVisibleEnquiries = remember(enquiries, activeRole, q) {
        enquiries.filter { enq ->
            val roleAllowed = enq.isVisibleForRole(activeRole)
            val meta = enq.parseProfileMetadata()
            val resolvedEmail = enq.email.ifBlank { meta.email }
            val resolvedCollege = enq.targetCollegeName.ifBlank { enq.preferredColleges }
            val searchAllowed = q.isBlank() ||
                enq.studentName.contains(q, ignoreCase = true) ||
                enq.phone.contains(q, ignoreCase = true) ||
                resolvedEmail.contains(q, ignoreCase = true) ||
                resolvedCollege.contains(q, ignoreCase = true) ||
                enq.preferredCourse.contains(q, ignoreCase = true)
            roleAllowed && searchAllowed
        }
    }

    val filteredDashboardColleges = remember(colleges, q) {
        if (q.isBlank()) colleges
        else colleges.filter { col ->
            col.name.contains(q, ignoreCase = true) ||
                col.shortCode.contains(q, ignoreCase = true) ||
                col.city.contains(q, ignoreCase = true) ||
                col.state.contains(q, ignoreCase = true)
        }
    }

    val filteredDashboardCourses = remember(courses, q) {
        if (q.isBlank()) courses
        else courses.filter { crs ->
            crs.courseName.contains(q, ignoreCase = true) ||
                crs.degree.contains(q, ignoreCase = true) ||
                crs.collegeName.contains(q, ignoreCase = true)
        }
    }

    // RBAC-filtered tasks: Admins see everything; Counselors only see tasks assigned to them
    val rbacVisibleTasks = remember(tasks, activeRole, q) {
        tasks.filter { t ->
            val roleAllowed = t.isVisibleForRole(activeRole)
            val searchAllowed = q.isBlank() ||
                t.displayTaskDescription().contains(q, ignoreCase = true) ||
                t.displayAssociatedStudent().contains(q, ignoreCase = true) ||
                t.dueDate.contains(q, ignoreCase = true)
            roleAllowed && searchAllowed
        }
    }

    val pendingRbacTasks = remember(rbacVisibleTasks) {
        rbacVisibleTasks.filter {
            it.displayTaskStatus().equals("Pending", ignoreCase = true)
        }
    }

    // 5 Newest Student Leads (enquiries from Supabase are ordered newest-first, filtered by RBAC & global search)
    val newestStudentLeads = remember(rbacVisibleEnquiries) {
        rbacVisibleEnquiries.take(5)
    }

    // 5 Most Urgent Pending Tasks (filtered by RBAC & global search, sorted by priority rank & earliest due date)
    val urgentPendingTasks = remember(pendingRbacTasks) {
        pendingRbacTasks
            .sortedWith(
                compareBy<TeamTaskRecord> { it.priorityRank() }
                    .thenBy { it.dueDate.ifBlank { "9999-12-31" } }
            )
            .take(5)
    }

    // Top-Level Real-Time Metric Cards from Supabase
    val topMetricCards = remember(
        filteredDashboardColleges.size,
        filteredDashboardCourses.size,
        rbacVisibleEnquiries.size,
        pendingRbacTasks.size,
        activeRole
    ) {
        val pendingSubtitle = if (activeRole == ConsultancyRole.COUNSELLOR) {
            "Assigned to Counselor (Supabase)"
        } else {
            "All Pending Tasks (Supabase)"
        }
        listOf(
            KpiMetric(
                key = "TOTAL_COLLEGES",
                title = "Total Colleges",
                value = "${filteredDashboardColleges.size}",
                subtitle = "Live Supabase colleges table",
                icon = Icons.Default.AccountBalance,
                accent = SkyCyan400
            ),
            KpiMetric(
                key = "TOTAL_COURSES",
                title = "Total Courses",
                value = "${filteredDashboardCourses.size}",
                subtitle = "Live Supabase courses table",
                icon = Icons.Default.MenuBook,
                accent = ClaimedBlue
            ),
            KpiMetric(
                key = "TOTAL_STUDENT_LEADS",
                title = "Total Student Leads",
                value = "${rbacVisibleEnquiries.size}",
                subtitle = "Live Supabase students table",
                icon = Icons.Default.People,
                accent = VerifiedEmerald
            ),
            KpiMetric(
                key = "PENDING_TASKS",
                title = "Pending Tasks",
                value = "${pendingRbacTasks.size}",
                subtitle = pendingSubtitle,
                icon = Icons.Default.NotificationsActive,
                accent = OutdatedAmber
            )
        )
    }

    val isCounselorReadOnly = activeRole == ConsultancyRole.COUNSELLOR ||
        activeRole == ConsultancyRole.READ_ONLY_VIEWER

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_analytics_dashboard_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Executive Command & RBAC Status Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF0F172A), Color(0xFF1E3A8A))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "MAIN ANALYTICS DASHBOARD • SUPABASE REAL-TIME",
                                style = MaterialTheme.typography.labelMedium,
                                color = SkyCyan400
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = Color(0xFF1E293B),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.testTag("dashboard_active_role_badge")
                                ) {
                                    Text(
                                        text = "ROLE: ${activeRole.label.uppercase()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberGold400,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                IconButton(
                                    onClick = onRefreshDashboard,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("dashboard_refresh_supabase_btn")
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Refresh Supabase Metrics",
                                        tint = SkyCyan400,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Higher Education Admissions, CRM & Regulatory Analytics",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        // RBAC Scope Indicator Banner
                        Surface(
                            color = if (activeRole == ConsultancyRole.COUNSELLOR) {
                                OutdatedAmber.copy(alpha = 0.18f)
                            } else {
                                VerifiedEmerald.copy(alpha = 0.18f)
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (activeRole == ConsultancyRole.COUNSELLOR) OutdatedAmber.copy(alpha = 0.5f)
                                    else VerifiedEmerald.copy(alpha = 0.5f),
                                    RoundedCornerShape(8.dp)
                                )
                                .testTag("dashboard_rbac_scope_banner")
                        ) {
                            Text(
                                text = when (activeRole) {
                                    ConsultancyRole.COUNSELLOR ->
                                        "RBAC Active: Counselor (Read-Only on Colleges/Courses/Fees) • Showing tasks assigned to Counselor only (${pendingRbacTasks.size} pending)"
                                    ConsultancyRole.ADMIN ->
                                        "RBAC Active: Admin (Full Read-Write Access) • Viewing all organization records & tasks (${pendingRbacTasks.size} pending)"
                                    ConsultancyRole.SENIOR_REVIEWER ->
                                        "RBAC Active: Senior Reviewer (Read-Write Access) • Viewing all organization records & tasks (${pendingRbacTasks.size} pending)"
                                    else ->
                                        "RBAC Active: ${activeRole.label} • Scoped task & record view (${pendingRbacTasks.size} pending)"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            if (!isCounselorReadOnly && activeRole.canManageColleges) {
                                Button(
                                    onClick = onOpenAddCollegeModal,
                                    modifier = Modifier.testTag("dashboard_add_college_btn")
                                ) {
                                    Text("+ Add College", fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = onOpenAddCourseModal,
                                    modifier = Modifier.testTag("dashboard_add_course_btn")
                                ) {
                                    Text("+ Add Course", fontWeight = FontWeight.Bold)
                                }
                            }
                            if (activeRole.canManageEnquiries) {
                                OutlinedButton(
                                    onClick = onOpenAddStudentModal,
                                    modifier = Modifier.testTag("dashboard_add_student_btn")
                                ) {
                                    Text("+ Add Student", color = Color.White)
                                }
                            }
                            if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                                OutlinedButton(
                                    onClick = onOpenAddTaskModal,
                                    modifier = Modifier.testTag("dashboard_add_task_btn")
                                ) {
                                    Text("+ Add Task", color = Color.White)
                                }
                            }
                            OutlinedButton(
                                onClick = onRefreshDashboard,
                                modifier = Modifier.testTag("dashboard_sync_now_btn")
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = SkyCyan400,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync Live Counts", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // 4 Top-Level Real-Time Aggregate Metric Cards (Total Colleges, Total Courses, Total Student Leads, Pending Tasks)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REAL-TIME SUPABASE METRICS (TAP TO OPEN MODULE)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Live Aggregate Counts",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                topMetricCards.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { metric ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(14.dp),
                                tonalElevation = 3.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        1.dp,
                                        metric.accent.copy(alpha = 0.55f),
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable { onKpiClicked(metric.key) }
                                    .testTag("metric_card_${metric.key.lowercase()}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            color = metric.accent.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = metric.icon,
                                                contentDescription = metric.title,
                                                tint = metric.accent,
                                                modifier = Modifier
                                                    .padding(8.dp)
                                                    .size(20.dp)
                                            )
                                        }
                                        Text(
                                            text = metric.value,
                                            style = MaterialTheme.typography.headlineMedium,
                                            color = metric.accent,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.testTag("metric_value_${metric.key.lowercase()}")
                                        )
                                    }
                                    Text(
                                        text = metric.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = metric.subtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // RECENT ACTIVITY SECTION: 5 Newest Student Leads & 5 Most Urgent Pending Tasks
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_recent_activity_section"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Activity",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "5 Newest Student Leads • 5 Most Urgent Pending Tasks",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Sub-panel 1: 5 Newest Student Leads
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .testTag("recent_activity_newest_students")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.People,
                                    contentDescription = null,
                                    tint = VerifiedEmerald,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "5 Newest Student Leads",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Showing ${newestStudentLeads.size} of ${enquiries.size} total leads from Supabase students table",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            TextButton(
                                onClick = { onNavigateModule(ConsultancyModule.STUDENT_ENQUIRY_CRM) },
                                modifier = Modifier.testTag("recent_leads_view_all_btn")
                            ) {
                                Text("View All Leads")
                            }
                        }

                        if (newestStudentLeads.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No student leads found in Supabase students table yet. Click '+ Add Student' to record a new lead.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            newestStudentLeads.forEachIndexed { index, lead ->
                                val statusText = lead.displayLeadStatus()
                                val statusColor = when (statusText) {
                                    "Enrolled" -> VerifiedEmerald
                                    "Application Submitted" -> SkyCyan400
                                    "Contacted" -> AmberGold400
                                    else -> ClaimedBlue
                                }
                                val collegeDisplay = lead.targetCollegeName.ifBlank { lead.preferredColleges }.ifBlank { "Target College Unspecified" }
                                val courseDisplay = lead.preferredCourse.ifBlank { "Course Unspecified" }

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(
                                            1.dp,
                                            MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { onNavigateModule(ConsultancyModule.STUDENT_ENQUIRY_CRM) }
                                        .testTag("recent_student_lead_item_$index")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = lead.studentName.ifBlank { "Student Lead #${index + 1}" },
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Surface(
                                                color = statusColor.copy(alpha = 0.16f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = statusText,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = statusColor,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "$collegeDisplay • $courseDisplay",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        val contactParts = listOfNotNull(
                                            lead.phone.takeIf { it.isNotBlank() },
                                            lead.email.takeIf { it.isNotBlank() }
                                        ).joinToString(" | ")
                                        if (contactParts.isNotBlank()) {
                                            Text(
                                                text = contactParts,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sub-panel 2: 5 Most Urgent Pending Tasks (RBAC Filtered)
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .testTag("recent_activity_urgent_tasks")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = OutdatedAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "5 Most Urgent Pending Tasks",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (activeRole == ConsultancyRole.COUNSELLOR) {
                                            "RBAC Filter: Counselor-assigned pending tasks (${urgentPendingTasks.size} of ${pendingRbacTasks.size})"
                                        } else {
                                            "RBAC Filter: All organization pending tasks (${urgentPendingTasks.size} of ${pendingRbacTasks.size})"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            TextButton(
                                onClick = { onNavigateModule(ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK) },
                                modifier = Modifier.testTag("recent_tasks_view_all_btn")
                            ) {
                                Text("View All Tasks")
                            }
                        }

                        if (urgentPendingTasks.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (activeRole == ConsultancyRole.COUNSELLOR) {
                                        "No pending tasks currently assigned to Counselor in the Supabase tasks table."
                                    } else {
                                        "No pending tasks found in the Supabase tasks table. Click '+ Add Task' to schedule a follow-up."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            urgentPendingTasks.forEachIndexed { index, task ->
                                val statusText = task.displayTaskStatus()
                                Surface(
                                    color = OutdatedAmber.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(
                                            1.dp,
                                            OutdatedAmber.copy(alpha = 0.4f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { onNavigateModule(ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK) }
                                        .testTag("recent_urgent_task_item_$index")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = task.displayTaskDescription(),
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                color = OutdatedAmber.copy(alpha = 0.2f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = statusText,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = OutdatedAmber,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Associated Student: ${task.displayAssociatedStudent()}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Due Date: ${task.dueDate.ifBlank { "Upcoming" }} • Priority: ${task.priority.ifBlank { "High" }}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "Assigned: ${task.assignedToName.ifBlank { task.assignedToRole }}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = SkyCyan400
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Mandatory Global Footer Card inside Dashboard
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AmberGold400.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .testTag("dashboard_admission_enquiries_footer")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ADMISSION ENQUIRIES",
                        style = MaterialTheme.typography.labelLarge,
                        color = AmberGold400,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "+91 70122 74141",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CollegeIntelligenceDatabaseScreen(
    colleges: List<College>,
    courses: List<Course>,
    activeRole: ConsultancyRole,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedState: String,
    onStateChange: (String) -> Unit,
    selectedOwnership: String,
    onOwnershipChange: (String) -> Unit,
    selectedInstType: String,
    onInstTypeChange: (String) -> Unit,
    selectedRegulator: String,
    onRegulatorChange: (String) -> Unit,
    selectedVerification: String,
    onVerificationChange: (String) -> Unit,
    onlyNeedsRefresh: Boolean,
    onNeedsRefreshChange: (Boolean) -> Unit,
    onResetFilters: () -> Unit,
    onSaveCollege: (College, Boolean) -> Unit,
    onVerifyStatus: (College, String) -> Unit,
    onDeleteCollege: (String, String) -> Unit,
    enquiryHeader: String = "ADMISSION ENQUIRIES",
    enquiryPhone: String = "+91 70122 74141"
) {
    var editingCollege by remember { mutableStateOf<College?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val states = remember(colleges) { listOf("All") + colleges.map { it.state }.distinct().sorted() }
    val ownerships = listOf("All", "Public/Government", "Private Unaided", "PPP")
    val instTypes = listOf(
        "All", "Deemed-to-be University", "Autonomous College",
        "Affiliated College", "Institution of National Importance",
        "Private University", "State University", "Central University"
    )
    val regulators = listOf("All", "UGC", "AICTE", "NMC", "DCI", "INC", "PCI", "IAP", "NBA", "NAAC")
    val verifications = listOf("All", "Verified", "Institution-Claimed", "Outdated", "Unverified")

    val filteredColleges = remember(
        colleges, searchQuery, selectedState, selectedOwnership,
        selectedInstType, selectedRegulator, selectedVerification, onlyNeedsRefresh
    ) {
        val q = searchQuery.trim().lowercase()
        colleges.filter { col ->
            val matchesSearch = q.isBlank() ||
                col.name.lowercase().contains(q) ||
                col.shortCode.lowercase().contains(q) ||
                col.city.lowercase().contains(q) ||
                col.state.lowercase().contains(q) ||
                col.degreeAwardingUniversity.lowercase().contains(q)
            val matchesState = selectedState == "All" || col.state.equals(selectedState, ignoreCase = true)
            val matchesOwn = selectedOwnership == "All" || col.ownership == selectedOwnership
            val matchesType = selectedInstType == "All" || col.institutionType == selectedInstType
            val matchesReg = selectedRegulator == "All" || col.regulators.contains(selectedRegulator)
            val matchesVer = selectedVerification == "All" || col.verificationStatus == selectedVerification
            val matchesRefresh = !onlyNeedsRefresh || col.needsRefresh

            matchesSearch && matchesState && matchesOwn && matchesType && matchesReg && matchesVer && matchesRefresh
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header + Search + Add College Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Indian College Intelligence Database", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Tracking Ownership, Institution Type & separate Degree-Awarding University (${filteredColleges.size} of ${colleges.size})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
                    Button(
                        onClick = { showCreateDialog = true },
                        modifier = Modifier.testTag("add_college_btn")
                    ) {
                        Text("+ Add College", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Surface(
                        color = AmberGold400.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.border(1.dp, AmberGold400.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = "${activeRole.label}: Read-Only",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold400,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Multi-Facet Filter Bar
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChange,
                            placeholder = { Text("Search name, code, city, or degree-awarding university...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("college_search_field")
                        )
                        IconButton(onClick = onResetFilters, modifier = Modifier.testTag("reset_college_filters_btn")) {
                            Icon(Icons.Default.FilterAltOff, contentDescription = "Reset Filters")
                        }
                    }

                    Text("State & Ownership:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(states) { st ->
                            FilterChip(
                                selected = selectedState == st,
                                onClick = { onStateChange(st) },
                                label = { Text("State: $st", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                        items(ownerships) { own ->
                            FilterChip(
                                selected = selectedOwnership == own,
                                onClick = { onOwnershipChange(own) },
                                label = { Text("Own: $own", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Text("Institution Type & Statutory Regulator:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(instTypes) { tp ->
                            FilterChip(
                                selected = selectedInstType == tp,
                                onClick = { onInstTypeChange(tp) },
                                label = { Text(tp, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                        items(regulators) { reg ->
                            FilterChip(
                                selected = selectedRegulator == reg,
                                onClick = { onRegulatorChange(reg) },
                                label = { Text("Council: $reg", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(verifications) { ver ->
                            FilterChip(
                                selected = selectedVerification == ver,
                                onClick = { onVerificationChange(ver) },
                                label = { Text("Status: $ver", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                        item {
                            FilterChip(
                                selected = onlyNeedsRefresh,
                                onClick = { onNeedsRefreshChange(!onlyNeedsRefresh) },
                                label = { Text("Needs Refresh Only", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // College Cards
        items(filteredColleges, key = { it.id }) { college ->
            val linkedCourses = courses.filter { it.collegeId == college.id || it.collegeName == college.name }
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.65f), RoundedCornerShape(14.dp))
                    .testTag("college_card_${college.shortCode.lowercase()}")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = college.shortCode,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Text(
                                    text = "${college.city}, ${college.state} • Est. ${college.establishedYear}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = college.name,
                                style = MaterialTheme.typography.titleLarge
                            )
                        }
                        VerificationStatusBadge(status = college.verificationStatus)
                    }

                    // Distinct 3-Pillar Architecture Box: Ownership | Institution Type | Degree-Awarding University
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("OWNERSHIP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(college.ownership, style = MaterialTheme.typography.titleSmall)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("INSTITUTION TYPE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(college.institutionType, style = MaterialTheme.typography.titleSmall, color = SkyCyan400)
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.School, contentDescription = null, tint = AmberGold400, modifier = Modifier.size(16.dp))
                                Column {
                                    Text(
                                        "DEGREE-AWARDING UNIVERSITY (SEPARATE FROM AFFILIATION)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AmberGold400
                                    )
                                    Text(
                                        text = college.degreeAwardingUniversity,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (college.affiliatedTo.isNotBlank()) {
                                        Text(
                                            text = "Administrative Affiliation: ${college.affiliatedTo}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Accreditations & Statutory Councils
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = VerifiedEmerald.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "NAAC ${college.naacGrade} (${college.naacCgpa})",
                                style = MaterialTheme.typography.labelMedium,
                                color = VerifiedEmerald,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        if (college.nirfRank > 0) {
                            Surface(
                                color = AmberGold400.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "NIRF #${college.nirfRank}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AmberGold400,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        college.regulators.forEach { reg ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = reg,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    if (college.regulatorDetailsSummary.isNotBlank()) {
                        Text(
                            text = college.regulatorDetailsSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Linked Courses preview
                    if (linkedCourses.isNotEmpty()) {
                        Text(
                            text = "Tracked Courses (${linkedCourses.size}): " +
                                linkedCourses.joinToString(" • ") {
                                    "${it.courseName}${if (it.isLateralEntry) " [Lateral Entry]" else ""} (${formatInrLakhs(it.annualTuitionMinInr)}-${formatInrLakhs(it.annualTuitionMaxInr)})"
                                },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Role-based Action Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (activeRole != ConsultancyRole.COUNSELLOR && activeRole.canVerifyRegulatory) {
                                OutlinedButton(
                                    onClick = {
                                        val next = if (college.verificationStatus == "Verified") "Institution-Claimed" else "Verified"
                                        onVerifyStatus(college, next)
                                    }
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        if (college.verificationStatus == "Verified") "Mark Claimed" else "Verify Now",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            if (activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
                                OutlinedButton(
                                    onClick = { editingCollege = college },
                                    modifier = Modifier.testTag("edit_college_btn_${college.shortCode.lowercase()}")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (activeRole == ConsultancyRole.COUNSELLOR || (!activeRole.canManageColleges && !activeRole.canVerifyRegulatory)) {
                                Text(
                                    text = "Read-Only Access (${activeRole.label})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (activeRole != ConsultancyRole.COUNSELLOR && activeRole.canDeleteRecords) {
                            IconButton(onClick = { onDeleteCollege(college.id, college.shortCode) }) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "Delete College",
                                    tint = DiscrepancyRose
                                )
                            }
                        }
                    }

                    // Mandatory Admission Enquiry Contact Footer at the end of every College Profile
                    com.example.ui.components.MandatoryAdmissionEnquiryFooter(
                        enquiryHeader = enquiryHeader,
                        enquiryPhone = enquiryPhone
                    )
                }
            }
        }
    }

    if (showCreateDialog && activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
        CollegeEditorDialog(
            initialCollege = null,
            onSave = onSaveCollege,
            onDismiss = { showCreateDialog = false }
        )
    }

    if (editingCollege != null && activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
        CollegeEditorDialog(
            initialCollege = editingCollege,
            onSave = onSaveCollege,
            onDismiss = { editingCollege = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CourseCatalogMatrixScreen(
    courses: List<Course>,
    colleges: List<College>,
    activeRole: ConsultancyRole,
    globalSearchQuery: String = "",
    onGlobalSearchQueryChange: (String) -> Unit = {},
    selectedStream: String,
    onStreamChange: (String) -> Unit,
    onlyLateralEntry: Boolean,
    onLateralEntryChange: (Boolean) -> Unit,
    maxFeeLakhs: Float,
    onMaxFeeLakhsChange: (Float) -> Unit,
    onAddCourse: (Course) -> Unit,
    onToggleLateralEntry: (Course) -> Unit,
    showAddCourseModal: Boolean = false,
    onSetShowAddCourseModal: (Boolean) -> Unit = {},
    isSubmittingCourse: Boolean = false,
    courseErrorAlert: String? = null,
    onDismissCourseErrorAlert: () -> Unit = {},
    courseSuccessMessage: String? = null,
    onDismissCourseSuccessMessage: () -> Unit = {},
    onCreateCourseInSupabase: (collegeId: String, collegeName: String, courseName: String, degree: String, durationYears: Int, seatQuotaType: String) -> Unit = { _, _, _, _, _, _ -> },
    onRefreshFromSupabase: () -> Unit = {}
) {
    // Automatically fetch latest courses and colleges from Supabase when entering the Courses screen
    LaunchedEffect(Unit) {
        onRefreshFromSupabase()
    }

    var searchQuery by remember { mutableStateOf(globalSearchQuery) }
    LaunchedEffect(globalSearchQuery) {
        if (searchQuery != globalSearchQuery) {
            searchQuery = globalSearchQuery
        }
    }
    var selectedQuotaFilter by remember { mutableStateOf("All") }
    val quotaFilters = listOf("All", "Merit", "Management", "NRI")

    // RBAC Admin / Senior Reviewer Guard (matches Colleges module guard)
    val canManageCourses = activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges

    val filteredCourses = remember(courses, searchQuery, selectedQuotaFilter) {
        val q = searchQuery.trim().lowercase()
        courses.filter { crs ->
            val matchesQuota = selectedQuotaFilter == "All" ||
                crs.seatQuotaType.equals(selectedQuotaFilter, ignoreCase = true)
            val matchesSearch = q.isBlank() ||
                crs.courseName.lowercase().contains(q) ||
                crs.degree.lowercase().contains(q) ||
                crs.collegeName.lowercase().contains(q) ||
                crs.seatQuotaType.lowercase().contains(q)
            matchesQuota && matchesSearch
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("courses_supabase_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Row with "+ Add Course" button protected by RBAC Admin/Reviewer Guard
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Courses & Intake Management",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Live Supabase `courses` table (${filteredCourses.size} of ${courses.size} courses displayed)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onRefreshFromSupabase,
                        modifier = Modifier.testTag("refresh_courses_supabase_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Courses", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Refresh", style = MaterialTheme.typography.labelMedium)
                    }

                    if (canManageCourses) {
                        Button(
                            onClick = { onSetShowAddCourseModal(true) },
                            modifier = Modifier.testTag("add_course_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("+ Add Course", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(
                            color = AmberGold400.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .border(1.dp, AmberGold400.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .testTag("course_read_only_badge")
                        ) {
                            Text(
                                text = "${activeRole.label}: Read-Only",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberGold400,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Red Alert Banner if a Supabase Error occurs
        if (!courseErrorAlert.isNullOrBlank()) {
            item {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DiscrepancyRose, RoundedCornerShape(10.dp))
                        .testTag("course_supabase_error_alert")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.WarningAmber,
                                contentDescription = "Supabase Error",
                                tint = DiscrepancyRose,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = courseErrorAlert,
                                style = MaterialTheme.typography.bodySmall,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismissCourseErrorAlert,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss error",
                                tint = DiscrepancyRose,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Green Success Toast / Banner when Course is added to Supabase
        if (!courseSuccessMessage.isNullOrBlank()) {
            item {
                Surface(
                    color = VerifiedEmerald.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, VerifiedEmerald, RoundedCornerShape(10.dp))
                        .testTag("course_supabase_success_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = courseSuccessMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = VerifiedEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismissCourseSuccessMessage,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss success banner",
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Search & Seat Quota Filter Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            onGlobalSearchQueryChange(it)
                        },
                        placeholder = { Text("Search by Course Name (e.g., BSc Optometry, BCom), Degree, or College...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        searchQuery = ""
                                        onGlobalSearchQueryChange("")
                                    }
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("course_search_input")
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Seat Quota Type:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(quotaFilters) { qFilter ->
                                FilterChip(
                                    selected = selectedQuotaFilter == qFilter,
                                    onClick = { selectedQuotaFilter = qFilter },
                                    label = { Text(qFilter, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("course_quota_filter_${qFilter.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // Empty State if no courses in Supabase yet
        if (filteredCourses.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .testTag("courses_empty_state_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (courses.isEmpty()) "No courses found in Supabase `courses` table yet." else "No courses match the active filter.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (canManageCourses) {
                                "Click '+ Add Course' above to insert a course linked to a college from your Supabase `colleges` table."
                            } else {
                                "Switch to Admin or Senior Reviewer to add new courses to Supabase."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Course Cards fetched directly from Supabase `courses` table
        items(filteredCourses, key = { it.id }) { crs ->
            val durationFormatted = if (crs.durationYears % 1.0 == 0.0) {
                "${crs.durationYears.toInt()} Years"
            } else {
                "${crs.durationYears} Years"
            }
            val displayDegree = crs.degree.ifBlank { "UG" }
            val quotaBadgeColor = when {
                crs.seatQuotaType.equals("Merit", ignoreCase = true) -> VerifiedEmerald
                crs.seatQuotaType.equals("Management", ignoreCase = true) -> SkyCyan400
                crs.seatQuotaType.equals("NRI", ignoreCase = true) -> AmberGold400
                else -> MaterialTheme.colorScheme.primary
            }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                    .testTag("course_card_${crs.id.take(12)}")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = crs.courseName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = crs.collegeName.ifBlank { "Linked Supabase College" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Seat Quota Type Badge (Merit, Management, NRI)
                        Surface(
                            color = quotaBadgeColor.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.border(1.dp, quotaBadgeColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = "Quota: ${crs.seatQuotaType}",
                                style = MaterialTheme.typography.labelMedium,
                                color = quotaBadgeColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    // Key Course Details Bar
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "DEGREE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = displayDegree,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "DURATION IN YEARS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = durationFormatted,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "SEAT QUOTA TYPE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = crs.seatQuotaType,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = quotaBadgeColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddCourseModal && canManageCourses) {
        CourseEditorDialog(
            colleges = colleges,
            isSubmitting = isSubmittingCourse,
            supabaseErrorAlert = courseErrorAlert,
            onSubmitCourse = onCreateCourseInSupabase,
            onDismiss = { onSetShowAddCourseModal(false) }
        )
    }
}
