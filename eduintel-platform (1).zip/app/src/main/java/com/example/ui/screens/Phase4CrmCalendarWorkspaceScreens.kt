package com.example.ui.screens

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.ViewKanban
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AcceptanceTestResultItem
import com.example.data.model.AdmissionDeadlineRecord
import com.example.data.model.AppSettingsRecord
import com.example.data.model.College
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.MatchedCollegeEligibilityResult
import com.example.data.model.ShortlistedCollegeItem
import com.example.data.model.StudentEnquiry
import com.example.data.model.StudentProfileMetadata
import com.example.data.model.StudentVaultDocument
import com.example.data.model.TeamMemberRecord
import com.example.data.model.TeamTaskRecord
import com.example.ui.components.MandatoryAdmissionEnquiryFooter
import com.example.ui.components.StudentEditorDialog
import com.example.ui.components.TaskEditorDialog
import com.example.ui.components.VerificationStatusBadge
import com.example.ui.components.formatInrLakhs
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.SkyCyan400
import com.example.ui.theme.VerifiedEmerald
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

// ============================================================================
// MODULE 8: ADMISSION CALENDAR, DEADLINES & ALERTS
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdmissionCalendarDeadlinesScreen(
    deadlines: List<AdmissionDeadlineRecord>,
    colleges: List<College>,
    courses: List<Course>,
    activeRole: ConsultancyRole,
    onAddDeadline: (AdmissionDeadlineRecord) -> Unit,
    onCreateReminderTask: (AdmissionDeadlineRecord) -> Unit,
    onVerifyCollege: (College, String) -> Unit
) {
    var subTab by remember { mutableStateOf(0) }
    var filterMode by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val conflictCount = deadlines.count { it.hasConflict }
    val overdueCount = deadlines.count { it.isOverdueRefresh }

    val filteredDeadlines = remember(deadlines, filterMode) {
        when (filterMode) {
            "Conflicts" -> deadlines.filter { it.hasConflict }
            "Overdue Refresh" -> deadlines.filter { it.isOverdueRefresh }
            "Verified" -> deadlines.filter { it.verificationStatus == "Verified" }
            else -> deadlines
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                label = { Text("Admission Deadlines & Alerts (${deadlines.size})") },
                modifier = Modifier.testTag("m8_tab_deadlines")
            )
            FilterChip(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                label = { Text("Regulatory & Cutoff Audit (${colleges.size})") },
                modifier = Modifier.testTag("m8_tab_regulatory")
            )
        }

        if (subTab == 1) {
            RegulatoryApprovalTrackerScreen(
                colleges = colleges,
                courses = courses,
                activeRole = activeRole,
                onVerifyCollege = onVerifyCollege
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Admission Calendar, Deadlines & Counselling Alerts",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Track Application Windows, Entrance Exams, Round 1/2/Mop-Up Counselling, Document Verification, Scholarship & Fee Deadlines with Source Citations.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { showAddDialog = true },
                                modifier = Modifier.testTag("add_deadline_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add Window")
                            }
                        }
                    }
                }

                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "All" to "All Windows (${deadlines.size})",
                            "Conflicts" to "Conflicting Notifications ($conflictCount)",
                            "Overdue Refresh" to "Overdue Refresh Checks ($overdueCount)",
                            "Verified" to "Verified (${deadlines.count { it.verificationStatus == "Verified" }})"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = filterMode == key,
                                onClick = { filterMode = key },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("deadline_filter_$key")
                            )
                        }
                    }
                }

                items(filteredDeadlines, key = { it.id }) { dl ->
                    AdmissionDeadlineCard(
                        deadline = dl,
                        activeRole = activeRole,
                        onCreateReminderTask = { onCreateReminderTask(dl) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddAdmissionDeadlineDialog(
            colleges = colleges,
            courses = courses,
            onDismiss = { showAddDialog = false },
            onSave = { newDl ->
                onAddDeadline(newDl)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun AdmissionDeadlineCard(
    deadline: AdmissionDeadlineRecord,
    activeRole: ConsultancyRole,
    onCreateReminderTask: () -> Unit
) {
    val borderColor = when {
        deadline.hasConflict -> DiscrepancyRose
        deadline.isOverdueRefresh -> AmberGold400
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .testTag("deadline_card_${deadline.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = SkyCyan400,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "${deadline.collegeName} • ${deadline.courseName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Quota: ${deadline.quotaCategory} | Academic Year: ${deadline.academicYear}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberGold400
                    )
                }
                VerificationStatusBadge(status = deadline.verificationStatus)
            }

            if (deadline.hasConflict) {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "Conflicting Notification",
                            tint = DiscrepancyRose,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "CONFLICTING NOTIFICATION DETECTED",
                                style = MaterialTheme.typography.labelSmall,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = deadline.conflictDetails,
                                style = MaterialTheme.typography.bodySmall,
                                color = DiscrepancyRose
                            )
                        }
                    }
                }
            }

            if (deadline.isOverdueRefresh) {
                Surface(
                    color = AmberGold400.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = "Overdue Refresh Check",
                            tint = AmberGold400,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "OVERDUE REFRESH CHECK: Portal dates last retrieved on ${deadline.retrievalDate}. Immediate re-verification required.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberGold400,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DeadlineMilestoneCell("1. App Opens", deadline.applicationOpenDate, Modifier.weight(1f))
                        DeadlineMilestoneCell("2. App Deadline", deadline.applicationDeadline, Modifier.weight(1f), highlight = true)
                        DeadlineMilestoneCell("3. Entrance Exam", deadline.entranceExamDate, Modifier.weight(1f))
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DeadlineMilestoneCell("4. Round 1", deadline.counsellingRound1Date, Modifier.weight(1f))
                        DeadlineMilestoneCell("5. Round 2", deadline.counsellingRound2Date, Modifier.weight(1f))
                        DeadlineMilestoneCell("6. Mop-Up / Stray", deadline.mopUpStrayRoundDate, Modifier.weight(1f))
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DeadlineMilestoneCell("7. Doc Verification", deadline.documentVerificationDeadline, Modifier.weight(1f))
                        DeadlineMilestoneCell("8. Scholarship Cutoff", deadline.scholarshipDeadline, Modifier.weight(1f))
                        DeadlineMilestoneCell("9. Fee Payment Window", deadline.feePaymentWindow, Modifier.weight(1f), highlight = true)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Source URL: ${deadline.sourceUrl}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkyCyan400,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Retrieved: ${deadline.retrievalDate} • Cycle: ${deadline.academicYear}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = onCreateReminderTask,
                        modifier = Modifier.testTag("create_deadline_task_btn_${deadline.id}")
                    ) {
                        Icon(Icons.Default.TaskAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("1-Click Reminder Task", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun DeadlineMilestoneCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Column(modifier = modifier.padding(end = 6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Medium,
            color = if (highlight) AmberGold400 else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun AddAdmissionDeadlineDialog(
    colleges: List<College>,
    courses: List<Course>,
    onDismiss: () -> Unit,
    onSave: (AdmissionDeadlineRecord) -> Unit
) {
    val defaultCol = colleges.firstOrNull()
    val defaultCrs = courses.firstOrNull { it.collegeId == defaultCol?.id } ?: courses.firstOrNull()

    var collegeName by remember { mutableStateOf(defaultCol?.name ?: "RV College of Engineering") }
    var courseName by remember { mutableStateOf(defaultCrs?.courseName ?: "B.E. Computer Science & Engineering") }
    var quotaCategory by remember { mutableStateOf("KCET / COMEDK / Management") }
    var academicYear by remember { mutableStateOf("2026-27") }
    var appOpen by remember { mutableStateOf("2026-03-01") }
    var appDeadline by remember { mutableStateOf("2026-05-15") }
    var examDate by remember { mutableStateOf("2026-05-25") }
    var round1 by remember { mutableStateOf("2026-07-05") }
    var round2 by remember { mutableStateOf("2026-07-25") }
    var mopUp by remember { mutableStateOf("2026-08-15") }
    var docVerify by remember { mutableStateOf("2026-07-12") }
    var scholarship by remember { mutableStateOf("2026-09-15") }
    var feeWindow by remember { mutableStateOf("2026-07-10 to 2026-07-20") }
    var sourceUrl by remember { mutableStateOf("https://cetonline.karnataka.gov.in/kea/") }
    var hasConflict by remember { mutableStateOf(false) }
    var conflictDetails by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Admission Deadline & Counselling Schedule") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = collegeName, onValueChange = { collegeName = it }, label = { Text("College Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = courseName, onValueChange = { courseName = it }, label = { Text("Course Name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = quotaCategory, onValueChange = { quotaCategory = it }, label = { Text("Quota Category") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = academicYear, onValueChange = { academicYear = it }, label = { Text("Academic Year") }, modifier = Modifier.weight(0.6f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = appOpen, onValueChange = { appOpen = it }, label = { Text("App Open Date") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = appDeadline, onValueChange = { appDeadline = it }, label = { Text("App Deadline") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = examDate, onValueChange = { examDate = it }, label = { Text("Entrance Exam") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = round1, onValueChange = { round1 = it }, label = { Text("Round 1 Date") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = round2, onValueChange = { round2 = it }, label = { Text("Round 2 Date") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = mopUp, onValueChange = { mopUp = it }, label = { Text("Mop-Up / Stray") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = docVerify, onValueChange = { docVerify = it }, label = { Text("Doc Verification") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = scholarship, onValueChange = { scholarship = it }, label = { Text("Scholarship Cutoff") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = feeWindow, onValueChange = { feeWindow = it }, label = { Text("Fee Payment Window") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = sourceUrl, onValueChange = { sourceUrl = it }, label = { Text("Official Source URL") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(checked = hasConflict, onCheckedChange = { hasConflict = it })
                    Text("Flag Conflicting Notification", style = MaterialTheme.typography.bodySmall)
                }
                if (hasConflict) {
                    OutlinedTextField(
                        value = conflictDetails,
                        onValueChange = { conflictDetails = it },
                        label = { Text("Conflict Details") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        AdmissionDeadlineRecord(
                            id = "dl_${UUID.randomUUID().toString().take(8)}",
                            collegeId = defaultCol?.id ?: "demo_col_rvce",
                            collegeName = collegeName.ifBlank { "RV College of Engineering" },
                            courseName = courseName.ifBlank { "B.E. CSE" },
                            quotaCategory = quotaCategory,
                            academicYear = academicYear,
                            applicationOpenDate = appOpen,
                            applicationDeadline = appDeadline,
                            entranceExamDate = examDate,
                            counsellingRound1Date = round1,
                            counsellingRound2Date = round2,
                            mopUpStrayRoundDate = mopUp,
                            documentVerificationDeadline = docVerify,
                            scholarshipDeadline = scholarship,
                            feePaymentWindow = feeWindow,
                            sourceUrl = sourceUrl,
                            retrievalDate = "2026-10-29",
                            verificationStatus = if (hasConflict) "Flagged Discrepancy" else "Verified",
                            hasConflict = hasConflict,
                            conflictDetails = conflictDetails,
                            isOverdueRefresh = false
                        )
                    )
                }
            ) {
                Text("Save Window")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ============================================================================
// MODULE 11: PRIVATE STUDENT CRM & AUTOMATED ELIGIBILITY MATCHER
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PrivateStudentCrmScreen(
    enquiries: List<StudentEnquiry>,
    colleges: List<College>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    appSettings: AppSettingsRecord,
    activeRole: ConsultancyRole,
    globalSearchQuery: String = "",
    onGlobalSearchQueryChange: (String) -> Unit = {},
    onlyDueToday: Boolean,
    onToggleOnlyDueToday: (Boolean) -> Unit,
    onAddEnquiry: (StudentEnquiry) -> Unit,
    onUpdateStage: (StudentEnquiry, String) -> Unit,
    onUpdateProfileAndShortlist: (StudentEnquiry, StudentProfileMetadata, List<ShortlistedCollegeItem>) -> Unit,
    computeMatchedColleges: (StudentEnquiry) -> List<MatchedCollegeEligibilityResult>,
    showAddStudentModal: Boolean = false,
    onSetShowAddStudentModal: (Boolean) -> Unit = {},
    isSubmittingStudent: Boolean = false,
    studentErrorAlert: String? = null,
    onDismissStudentErrorAlert: () -> Unit = {},
    studentSuccessMessage: String? = null,
    onDismissStudentSuccessMessage: () -> Unit = {},
    onCreateStudentInSupabase: (
        fullName: String,
        phone: String,
        email: String,
        targetCollegeId: String,
        targetCollegeName: String,
        interestedCourseId: String,
        interestedCourseName: String,
        leadStatus: String
    ) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onRefreshStudentsFromSupabase: () -> Unit = {},
    studentVaultDocuments: Map<String, List<StudentVaultDocument>> = emptyMap(),
    isUploadingStudentDocument: Boolean = false,
    studentDocUploadError: String? = null,
    onDismissStudentDocUploadError: () -> Unit = {},
    studentDocUploadSuccess: String? = null,
    onDismissStudentDocUploadSuccess: () -> Unit = {},
    onFetchStudentDocuments: (studentId: String) -> Unit = {},
    onUploadStudentDocument: (
        studentId: String,
        studentName: String,
        fileName: String,
        mimeType: String,
        fileBytes: ByteArray
    ) -> Unit = { _, _, _, _, _ -> }
) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        onRefreshStudentsFromSupabase()
    }

    var isKanbanView by remember { mutableStateOf(false) }
    var selectedStatusFilter by remember { mutableStateOf("All") }
    var studentSearchQuery by remember { mutableStateOf(globalSearchQuery) }
    LaunchedEffect(globalSearchQuery) {
        if (studentSearchQuery != globalSearchQuery) {
            studentSearchQuery = globalSearchQuery
        }
    }
    var activeStudentForSheet by remember { mutableStateOf<StudentEnquiry?>(null) }
    var csvExportStatusBanner by remember { mutableStateOf<String?>(null) }
    var lastExportedCsvPreview by remember { mutableStateOf<String?>(null) }

    // Enforce RBAC first: Counselors only search/view/export permitted student leads; Admins/Reviewers see all
    val rbacPermittedEnquiries = remember(enquiries, activeRole) {
        enquiries.filter { it.isVisibleForRole(activeRole) }
    }

    val filteredEnquiries = remember(rbacPermittedEnquiries, onlyDueToday, selectedStatusFilter, studentSearchQuery) {
        rbacPermittedEnquiries.filter { enq ->
            val dueMatch = !onlyDueToday || enq.followUpDueToday
            val statusMatch = selectedStatusFilter == "All" ||
                enq.displayLeadStatus().equals(selectedStatusFilter, ignoreCase = true) ||
                enq.normalizedStage().equals(selectedStatusFilter, ignoreCase = true)
            val meta = enq.parseProfileMetadata()
            val resolvedEmail = enq.email.ifBlank { meta.email }
            val resolvedCollege = enq.targetCollegeName.ifBlank { enq.preferredColleges }
            val searchMatch = studentSearchQuery.isBlank() ||
                enq.studentName.contains(studentSearchQuery, ignoreCase = true) ||
                enq.phone.contains(studentSearchQuery, ignoreCase = true) ||
                resolvedEmail.contains(studentSearchQuery, ignoreCase = true) ||
                resolvedCollege.contains(studentSearchQuery, ignoreCase = true) ||
                enq.preferredCourse.contains(studentSearchQuery, ignoreCase = true) ||
                enq.displayLeadStatus().contains(studentSearchQuery, ignoreCase = true)
            dueMatch && statusMatch && searchMatch
        }
    }

    val liveSelectedStudent = remember(rbacPermittedEnquiries, activeStudentForSheet) {
        activeStudentForSheet?.let { selected ->
            rbacPermittedEnquiries.find { it.id == selected.id } ?: selected
        }
    }

    if (isKanbanView) {
        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!studentErrorAlert.isNullOrBlank()) {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose, RoundedCornerShape(10.dp))
                            .testTag("student_supabase_error_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = DiscrepancyRose,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = studentErrorAlert,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DiscrepancyRose,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = onDismissStudentErrorAlert,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss error alert",
                                    tint = DiscrepancyRose,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = onRefreshStudentsFromSupabase,
                        modifier = Modifier.testTag("refresh_students_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Students", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Refresh")
                    }
                    OutlinedButton(
                        onClick = {
                            val (statusMsg, csvContent) = exportStudentsToCsvDownload(
                                context = context,
                                students = filteredEnquiries,
                                activeRole = activeRole
                            )
                            csvExportStatusBanner = statusMsg
                            lastExportedCsvPreview = csvContent
                        },
                        modifier = Modifier.testTag("export_students_csv_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Export to CSV", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export to CSV", fontWeight = FontWeight.Bold)
                    }
                    FilterChip(
                        selected = !isKanbanView,
                        onClick = { isKanbanView = false },
                        label = { Text("Leads List (${filteredEnquiries.size})") },
                        leadingIcon = { Icon(Icons.Default.ViewList, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("crm_view_table_btn")
                    )
                    FilterChip(
                        selected = isKanbanView,
                        onClick = { isKanbanView = true },
                        label = { Text("Kanban") },
                        leadingIcon = { Icon(Icons.Default.ViewKanban, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("crm_view_kanban_btn")
                    )
                    if (activeRole.canManageEnquiries) {
                        Button(
                            onClick = { onSetShowAddStudentModal(true) },
                            modifier = Modifier.testTag("new_student_enquiry_btn")
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Student", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            LazyRow(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val stagesToRender = StudentEnquiry.LEAD_STATUS_OPTIONS
                items(stagesToRender, key = { it }) { stageName ->
                    val stageStudents = filteredEnquiries.filter {
                        it.displayLeadStatus().equals(stageName, ignoreCase = true)
                    }
                    KanbanStageColumn(
                        stageName = stageName,
                        students = stageStudents,
                        activeRole = activeRole,
                        onOpenStudentProfile = { activeStudentForSheet = it },
                        onMoveStage = onUpdateStage
                    )
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("students_crm_lazy_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Visible Green Banner for Successful Supabase Student Insert
            if (!studentSuccessMessage.isNullOrBlank()) {
                item {
                    Surface(
                        color = VerifiedEmerald.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, VerifiedEmerald, RoundedCornerShape(10.dp))
                            .testTag("student_supabase_success_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = VerifiedEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = studentSuccessMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VerifiedEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = onDismissStudentSuccessMessage,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss success message",
                                    tint = VerifiedEmerald,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Persistent Red Alert Banner for Supabase Fetch / Insert Error (e.g., Row Level Security)
            if (!studentErrorAlert.isNullOrBlank()) {
                item {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose, RoundedCornerShape(10.dp))
                            .testTag("student_supabase_error_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = DiscrepancyRose,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = studentErrorAlert,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DiscrepancyRose,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = onDismissStudentErrorAlert,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss error alert",
                                    tint = DiscrepancyRose,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // CSV Export Confirmation Banner & Preview (student_leads.csv)
            if (!csvExportStatusBanner.isNullOrBlank()) {
                item {
                    Surface(
                        color = VerifiedEmerald.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, VerifiedEmerald, RoundedCornerShape(10.dp))
                            .testTag("csv_export_success_banner")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = VerifiedEmerald,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = csvExportStatusBanner!!,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = VerifiedEmerald,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        csvExportStatusBanner = null
                                        lastExportedCsvPreview = null
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Dismiss CSV export banner",
                                        tint = VerifiedEmerald,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            if (!lastExportedCsvPreview.isNullOrBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("csv_export_content_preview")
                                ) {
                                    Text(
                                        text = lastExportedCsvPreview!!.take(900),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Header & Action Controls (stacked cleanly so title never gets crushed by buttons)
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Students / Leads (Admissions CRM)",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Live records from Supabase `students` table (${filteredEnquiries.size} of ${rbacPermittedEnquiries.size} RBAC-permitted leads for ${activeRole.label}) • Click 'View Profile' to open Document Vault or 'Export to CSV' to download student_leads.csv.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onRefreshStudentsFromSupabase,
                            modifier = Modifier.testTag("refresh_students_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh Students", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Refresh")
                        }
                        OutlinedButton(
                            onClick = {
                                val (statusMsg, csvContent) = exportStudentsToCsvDownload(
                                    context = context,
                                    students = filteredEnquiries,
                                    activeRole = activeRole
                                )
                                csvExportStatusBanner = statusMsg
                                lastExportedCsvPreview = csvContent
                            },
                            modifier = Modifier.testTag("export_students_csv_btn")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Export to CSV", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export to CSV", fontWeight = FontWeight.Bold)
                        }
                        FilterChip(
                            selected = !isKanbanView,
                            onClick = { isKanbanView = false },
                            label = { Text("Leads List (${filteredEnquiries.size})") },
                            leadingIcon = { Icon(Icons.Default.ViewList, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier.testTag("crm_view_table_btn")
                        )
                        FilterChip(
                            selected = isKanbanView,
                            onClick = { isKanbanView = true },
                            label = { Text("Kanban") },
                            leadingIcon = { Icon(Icons.Default.ViewKanban, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier.testTag("crm_view_kanban_btn")
                        )
                        if (activeRole.canManageEnquiries) {
                            Button(
                                onClick = { onSetShowAddStudentModal(true) },
                                modifier = Modifier.testTag("new_student_enquiry_btn")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add Student", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Search & Lead Status Filters
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = studentSearchQuery,
                        onValueChange = {
                            studentSearchQuery = it
                            onGlobalSearchQueryChange(it)
                        },
                        label = { Text("Search Students / Leads by Name, Phone, Email, College, Course, or Status") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (studentSearchQuery.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        studentSearchQuery = ""
                                        onGlobalSearchQueryChange("")
                                    }
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_crm_search_input")
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = selectedStatusFilter == "All",
                            onClick = { selectedStatusFilter = "All" },
                            label = { Text("All (${rbacPermittedEnquiries.size})", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("crm_status_chip_all")
                        )
                        StudentEnquiry.LEAD_STATUS_OPTIONS.forEach { statusOpt ->
                            val count = rbacPermittedEnquiries.count { it.displayLeadStatus().equals(statusOpt, ignoreCase = true) }
                            FilterChip(
                                selected = selectedStatusFilter == statusOpt,
                                onClick = { selectedStatusFilter = statusOpt },
                                label = { Text("$statusOpt ($count)", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("crm_stage_chip_$statusOpt")
                            )
                        }
                        FilterChip(
                            selected = onlyDueToday,
                            onClick = { onToggleOnlyDueToday(!onlyDueToday) },
                            label = { Text("Due Today", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Empty State or Student List
            if (filteredEnquiries.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "No Student Leads Found in Supabase `students` Table",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Click '+ Add Student' to insert a new student lead (Full Name, Phone, Email, Target College, Interested Course, Lead Status) directly into the Supabase students table, or click 'Refresh' to re-fetch.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = onRefreshStudentsFromSupabase,
                                    modifier = Modifier.testTag("empty_state_refresh_students_btn")
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Refresh from Supabase")
                                }
                                if (activeRole.canManageEnquiries) {
                                    Button(
                                        onClick = { onSetShowAddStudentModal(true) },
                                        modifier = Modifier.testTag("empty_state_add_student_btn")
                                    ) {
                                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("+ Add Student")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                itemsIndexed(
                    items = filteredEnquiries,
                    key = { index, enq -> "${enq.id}_$index" }
                ) { _, enq ->
                    StudentTableCardRow(
                        enquiry = enq,
                        activeRole = activeRole,
                        uploadedDocsCount = studentVaultDocuments[enq.id]?.size ?: 0,
                        onOpenProfile = { activeStudentForSheet = enq },
                        onMoveStage = { newStage -> onUpdateStage(enq, newStage) }
                    )
                }
            }
        }
    }

    if (liveSelectedStudent != null) {
        LaunchedEffect(liveSelectedStudent.id) {
            onFetchStudentDocuments(liveSelectedStudent.id)
        }
        val matchedColleges = remember(liveSelectedStudent, colleges, courses, feeDocs) {
            computeMatchedColleges(liveSelectedStudent)
        }
        val studentDocs = studentVaultDocuments[liveSelectedStudent.id].orEmpty()
        StudentProfileAndMatcherDialog(
            enquiry = liveSelectedStudent,
            matchedColleges = matchedColleges,
            appSettings = appSettings,
            activeRole = activeRole,
            vaultDocuments = studentDocs,
            isUploadingDocument = isUploadingStudentDocument,
            documentUploadError = studentDocUploadError,
            onDismissDocumentUploadError = onDismissStudentDocUploadError,
            documentUploadSuccess = studentDocUploadSuccess,
            onDismissDocumentUploadSuccess = onDismissStudentDocUploadSuccess,
            onUploadDocument = { fileName, mimeType, fileBytes ->
                onUploadStudentDocument(
                    liveSelectedStudent.id,
                    liveSelectedStudent.studentName,
                    fileName,
                    mimeType,
                    fileBytes
                )
            },
            onRefreshDocuments = { onFetchStudentDocuments(liveSelectedStudent.id) },
            onUpdateStage = { newStage -> onUpdateStage(liveSelectedStudent, newStage) },
            onSaveProfileAndShortlist = { meta, shortlist ->
                onUpdateProfileAndShortlist(liveSelectedStudent, meta, shortlist)
            },
            onDismiss = { activeStudentForSheet = null }
        )
    }

    if (showAddStudentModal) {
        StudentEditorDialog(
            colleges = colleges,
            courses = courses,
            isSubmitting = isSubmittingStudent,
            supabaseErrorAlert = studentErrorAlert,
            onSubmitStudent = onCreateStudentInSupabase,
            onDismiss = { onSetShowAddStudentModal(false) }
        )
    }
}

@Composable
private fun KanbanStageColumn(
    stageName: String,
    students: List<StudentEnquiry>,
    activeRole: ConsultancyRole,
    onOpenStudentProfile: (StudentEnquiry) -> Unit,
    onMoveStage: (StudentEnquiry, String) -> Unit
) {
    val stageColor = when (stageName) {
        "Enrolled", "Offer Received" -> VerifiedEmerald
        "Unsuccessful", "Withdrawn" -> DiscrepancyRose
        "Shortlisted", "Applied" -> SkyCyan400
        else -> AmberGold400
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        modifier = Modifier
            .width(305.dp)
            .fillMaxHeight()
            .border(1.dp, stageColor.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stageName.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = stageColor,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = stageColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${students.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = stageColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            HorizontalDivider(color = stageColor.copy(alpha = 0.25f))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(students, key = { it.id }) { student ->
                    val meta = student.parseProfileMetadata()
                    val shortlist = student.parseShortlistedColleges()
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenStudentProfile(student) }
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .testTag("kanban_student_card_${student.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = student.studentName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = meta.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberGold400
                                )
                            }
                            Text(
                                text = "${student.preferredCourse} (${meta.specialization})",
                                style = MaterialTheme.typography.bodySmall,
                                color = SkyCyan400,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Exam: ${student.entranceExamScore}",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text(
                                text = "10th: ${meta.marks10thPercent}% | 12th: ${meta.marks12thPercent}% | Budget: ₹${student.budgetMaxLakhs}L",
                                style = MaterialTheme.typography.labelSmall,
                                color = VerifiedEmerald
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Shortlist: ${shortlist.size} • Docs: ${meta.checkedDocuments.size}/5",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (meta.bankLoanNeeded) "Loan: YES" else "Self-Funded",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (meta.bankLoanNeeded) AmberGold400 else VerifiedEmerald
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onOpenStudentProfile(student) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("open_student_matcher_btn_${student.id}")
                                ) {
                                    Text("View Profile", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                                if (activeRole.canManageEnquiries) {
                                    val nextStage = nextPipelineStage(student.normalizedStage())
                                    if (nextStage != null) {
                                        OutlinedButton(
                                            onClick = { onMoveStage(student, nextStage) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.testTag("advance_stage_btn_${student.id}")
                                        ) {
                                            Text("-> $nextStage", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun nextPipelineStage(current: String): String? {
    val mainFlow = StudentEnquiry.CRM_PIPELINE_STAGES.take(7)
    val idx = mainFlow.indexOfFirst { it.equals(current, ignoreCase = true) }
    return if (idx in 0 until mainFlow.lastIndex) mainFlow[idx + 1] else null
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudentTableCardRow(
    enquiry: StudentEnquiry,
    activeRole: ConsultancyRole,
    uploadedDocsCount: Int = 0,
    onOpenProfile: () -> Unit,
    onMoveStage: (String) -> Unit
) {
    val meta = enquiry.parseProfileMetadata()
    val resolvedEmail = enquiry.email.ifBlank { meta.email }
    val resolvedTargetCollege = enquiry.targetCollegeName.ifBlank {
        enquiry.preferredColleges.ifBlank { "Target College Not Specified" }
    }
    val resolvedInterestedCourse = enquiry.preferredCourse.ifBlank { "Course Not Specified" }
    val statusBadge = enquiry.displayLeadStatus()
    val statusColor = when (statusBadge) {
        "Enrolled" -> VerifiedEmerald
        "Application Submitted" -> SkyCyan400
        "Contacted" -> AmberGold400
        else -> AmberGold400
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenProfile() }
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .testTag("student_lead_card_${enquiry.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = enquiry.studentName.ifBlank { "Student Lead" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Phone: ${enquiry.phone.ifBlank { "—" }} • Email: $resolvedEmail",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = statusBadge,
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Target College: $resolvedTargetCollege",
                        style = MaterialTheme.typography.bodySmall,
                        color = VerifiedEmerald,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Interested Course: $resolvedInterestedCourse • Vault Docs: $uploadedDocsCount",
                        style = MaterialTheme.typography.bodySmall,
                        color = SkyCyan400,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpenProfile,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("view_student_profile_btn_${enquiry.id}")
                ) {
                    Icon(
                        Icons.Default.FolderOpen,
                        contentDescription = "View Profile",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "View Profile",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (activeRole.canManageEnquiries) {
                    nextPipelineStage(enquiry.normalizedStage())?.let { next ->
                        OutlinedButton(
                            onClick = { onMoveStage(next) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("advance_student_stage_btn_${enquiry.id}")
                        ) {
                            Text("-> $next", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudentProfileAndMatcherDialog(
    enquiry: StudentEnquiry,
    matchedColleges: List<MatchedCollegeEligibilityResult>,
    appSettings: AppSettingsRecord,
    activeRole: ConsultancyRole,
    vaultDocuments: List<StudentVaultDocument> = emptyList(),
    isUploadingDocument: Boolean = false,
    documentUploadError: String? = null,
    onDismissDocumentUploadError: () -> Unit = {},
    documentUploadSuccess: String? = null,
    onDismissDocumentUploadSuccess: () -> Unit = {},
    onUploadDocument: (fileName: String, mimeType: String, fileBytes: ByteArray) -> Unit = { _, _, _ -> },
    onRefreshDocuments: () -> Unit = {},
    onUpdateStage: (String) -> Unit,
    onSaveProfileAndShortlist: (StudentProfileMetadata, List<ShortlistedCollegeItem>) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(0) }
    var metadata by remember(enquiry) { mutableStateOf(enquiry.parseProfileMetadata()) }
    var shortlist by remember(enquiry) { mutableStateOf(enquiry.parseShortlistedColleges()) }
    var newCallNote by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${enquiry.studentName} — Student Profile, Document Vault & Matcher",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Student ID: ${enquiry.id} • ${enquiry.preferredCourse} (${metadata.specialization}) • Budget: ₹${enquiry.budgetMaxLakhs}L",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SkyCyan400
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = {
                                        val html = buildStudentShortlistPdfHtml(
                                            enquiry = enquiry,
                                            meta = metadata,
                                            shortlist = shortlist,
                                            appSettings = appSettings
                                        )
                                        printHtmlReport(
                                            context = context,
                                            jobName = "EduIntel_Student_Shortlist_${enquiry.studentName.replace(" ", "_")}",
                                            htmlContent = html
                                        )
                                    },
                                    modifier = Modifier.testTag("export_student_shortlist_pdf_btn")
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Export Shortlist PDF")
                                }
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.testTag("close_student_profile_dialog_btn")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Close")
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                label = { Text("1. Profile & Documents (${vaultDocuments.size})") },
                                modifier = Modifier.testTag("student_modal_tab_profile")
                            )
                            FilterChip(
                                selected = activeTab == 3,
                                onClick = { activeTab = 3 },
                                label = { Text("Documents (${vaultDocuments.size})") },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.FolderOpen,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("student_modal_tab_documents")
                            )
                            FilterChip(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                label = { Text("2. Eligibility & Budget Matcher (${matchedColleges.size})") },
                                modifier = Modifier.testTag("student_modal_tab_matcher")
                            )
                            FilterChip(
                                selected = activeTab == 2,
                                onClick = { activeTab = 2 },
                                label = { Text("3. Shortlist (${shortlist.size}), 5-Docs (${metadata.checkedDocuments.size}/5) & Notes") },
                                modifier = Modifier.testTag("student_modal_tab_shortlist")
                            )
                        }
                    }
                }

                HorizontalDivider()

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (activeTab) {
                        0 -> {
                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("STUDENT PROFILE DETAILS", style = MaterialTheme.typography.labelLarge, color = AmberGold400, fontWeight = FontWeight.Bold)
                                        Text("Full Name: ${enquiry.studentName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text("Student ID: ${enquiry.id} | Phone: ${enquiry.phone} | Email: ${metadata.email}", style = MaterialTheme.typography.bodySmall)
                                        Text("Academic Marks: 10th = ${metadata.marks10thPercent}% | 12th = ${metadata.marks12thPercent}% | Graduation = ${metadata.graduationMarksPercent.let { if (it > 0.0) "$it%" else "N/A (UG Applicant)" }}", style = MaterialTheme.typography.bodySmall, color = VerifiedEmerald)
                                        Text("Category: ${metadata.category} | Entrance Exam Scores: ${enquiry.entranceExamScore}", style = MaterialTheme.typography.bodySmall)
                                        Text("Intended Course & Specialization: ${enquiry.preferredCourse} — ${metadata.specialization}", style = MaterialTheme.typography.bodySmall, color = SkyCyan400)
                                        Text("Target College: ${enquiry.targetCollegeName.ifBlank { enquiry.preferredColleges.ifBlank { "Not specified" } }} | Lead Status: ${enquiry.displayLeadStatus()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        Text("Preferred States/Cities: ${metadata.preferredStatesCities}", style = MaterialTheme.typography.bodySmall)
                                        Text("Total 4/5-Yr Budget: ₹${enquiry.budgetMaxLakhs} Lakhs | Bank Loan Needed: ${if (metadata.bankLoanNeeded) "YES" else "NO"}", style = MaterialTheme.typography.bodySmall, color = AmberGold400)
                                        Text("Assigned Counsellor: ${metadata.assignedCounsellor} | Target Deadline: ${enquiry.deadlineDate}", style = MaterialTheme.typography.bodySmall)
                                        Text("Privacy & DPDP Consent Timestamp: ${metadata.privacyConsentTimestamp}", style = MaterialTheme.typography.labelSmall, color = VerifiedEmerald)
                                    }
                                }
                            }

                            item {
                                StudentDocumentVaultSection(
                                    enquiry = enquiry,
                                    vaultDocuments = vaultDocuments,
                                    isUploadingDocument = isUploadingDocument,
                                    documentUploadError = documentUploadError,
                                    onDismissDocumentUploadError = onDismissDocumentUploadError,
                                    documentUploadSuccess = documentUploadSuccess,
                                    onDismissDocumentUploadSuccess = onDismissDocumentUploadSuccess,
                                    onUploadDocument = onUploadDocument,
                                    onRefreshDocuments = onRefreshDocuments
                                )
                            }

                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("PIPELINE STAGE CONTROLLER (9 STAGES)", style = MaterialTheme.typography.labelLarge, color = SkyCyan400, fontWeight = FontWeight.Bold)
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            StudentEnquiry.CRM_PIPELINE_STAGES.forEach { stg ->
                                                FilterChip(
                                                    selected = enquiry.normalizedStage().equals(stg, ignoreCase = true),
                                                    onClick = {
                                                        if (activeRole.canManageEnquiries) {
                                                            onUpdateStage(stg)
                                                        }
                                                    },
                                                    label = { Text(stg) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            item {
                                StudentDocumentVaultSection(
                                    enquiry = enquiry,
                                    vaultDocuments = vaultDocuments,
                                    isUploadingDocument = isUploadingDocument,
                                    documentUploadError = documentUploadError,
                                    onDismissDocumentUploadError = onDismissDocumentUploadError,
                                    documentUploadSuccess = documentUploadSuccess,
                                    onDismissDocumentUploadSuccess = onDismissDocumentUploadSuccess,
                                    onUploadDocument = onUploadDocument,
                                    onRefreshDocuments = onRefreshDocuments
                                )
                            }
                        }

                        1 -> {
                            item {
                                Text(
                                    text = "Automated Eligibility & Quota-Specific Budget Matcher",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Ranked automatically against ${enquiry.studentName}'s Intended Course (${enquiry.preferredCourse}), 12th Marks (${metadata.marks12thPercent}%), Entrance Exam (${enquiry.entranceExamScore}), and Total Budget (₹${enquiry.budgetMaxLakhs}L).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            items(matchedColleges, key = { "${it.college.id}_${it.course.id}" }) { match ->
                                val alreadyShortlisted = shortlist.any { it.collegeId == match.college.id && it.courseName == match.course.courseName }
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(
                                            1.dp,
                                            if (match.matchScorePercent >= 80) VerifiedEmerald.copy(alpha = 0.6f) else AmberGold400.copy(alpha = 0.5f),
                                            RoundedCornerShape(12.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${match.college.name} (${match.college.city}, ${match.college.state})",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${match.course.courseName} — ${match.course.specialization}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = SkyCyan400
                                                )
                                            }
                                            Surface(
                                                color = if (match.matchScorePercent >= 80) VerifiedEmerald.copy(alpha = 0.18f) else AmberGold400.copy(alpha = 0.18f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text(
                                                    text = "${match.matchScorePercent}% MATCH",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = if (match.matchScorePercent >= 80) VerifiedEmerald else AmberGold400,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Text(
                                            text = "Est. Total Outlay: ${formatInrLakhs(match.totalCourseBudgetInr)} (${formatInrLakhs(match.effectiveAnnualFeeInr)}/yr)",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Checks: Budget Fit = ${if (match.isWithinBudget) "PASS" else "STRETCH"} • Marks Eligibility = ${if (match.meetsMarksEligibility) "PASS" else "BORDERLINE"} • Exam Alignment = ${if (match.entranceExamMatched) "DIRECT MATCH" else "ALTERNATE QUOTA"}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (match.isWithinBudget && match.meetsMarksEligibility) VerifiedEmerald else AmberGold400
                                        )
                                        Text(
                                            text = match.matchExplanation,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        if (activeRole.canManageEnquiries) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End
                                            ) {
                                                Button(
                                                    onClick = {
                                                        if (!alreadyShortlisted) {
                                                            val updated = shortlist + ShortlistedCollegeItem(
                                                                collegeId = match.college.id,
                                                                collegeShortCode = match.college.shortCode,
                                                                collegeName = match.college.name,
                                                                courseName = match.course.courseName,
                                                                quotaCategory = enquiry.quotaPreference,
                                                                annualFeeInr = match.effectiveAnnualFeeInr,
                                                                totalEstimatedCourseFeeInr = match.totalCourseBudgetInr,
                                                                applicationStatus = "Shortlisted"
                                                            )
                                                            shortlist = updated
                                                            onSaveProfileAndShortlist(metadata, updated)
                                                        }
                                                    },
                                                    enabled = !alreadyShortlisted,
                                                    modifier = Modifier.testTag("shortlist_add_btn_${match.college.id}")
                                                ) {
                                                    Text(if (alreadyShortlisted) "Shortlisted ✓" else "+ Add to Student Shortlist")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            text = "STUDENT SHORTLIST & PER-COLLEGE APPLICATION STATUS (${shortlist.size})",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = SkyCyan400,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (shortlist.isEmpty()) {
                                            Text(
                                                text = "No colleges shortlisted yet. Open Tab 2 (Eligibility & Budget Matcher) to add matched colleges.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            val appStatuses = listOf(
                                                "Shortlisted",
                                                "Application Submitted",
                                                "Counselling Registered",
                                                "Offer Received",
                                                "Enrolled",
                                                "Rejected"
                                            )
                                            shortlist.forEachIndexed { idx, item ->
                                                Card(
                                                    shape = RoundedCornerShape(10.dp),
                                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Column(modifier = Modifier.weight(1f)) {
                                                                Text(item.collegeName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                                                Text("${item.courseName} • Quota: ${item.quotaCategory} • ${formatInrLakhs(item.annualFeeInr)}/yr", style = MaterialTheme.typography.bodySmall, color = AmberGold400)
                                                            }
                                                            if (activeRole.canManageEnquiries) {
                                                                IconButton(
                                                                    onClick = {
                                                                        val updated = shortlist.toMutableList().also { it.removeAt(idx) }
                                                                        shortlist = updated
                                                                        onSaveProfileAndShortlist(metadata, updated)
                                                                    }
                                                                ) {
                                                                    Icon(Icons.Default.Delete, contentDescription = "Remove from shortlist", tint = DiscrepancyRose)
                                                                }
                                                            }
                                                        }
                                                        FlowRow(
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                                        ) {
                                                            appStatuses.forEach { st ->
                                                                FilterChip(
                                                                    selected = item.applicationStatus.equals(st, ignoreCase = true),
                                                                    onClick = {
                                                                        if (activeRole.canManageEnquiries) {
                                                                            val updated = shortlist.toMutableList()
                                                                            updated[idx] = item.copy(applicationStatus = st)
                                                                            shortlist = updated
                                                                            onSaveProfileAndShortlist(metadata, updated)
                                                                        }
                                                                    },
                                                                    label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = "ADMISSION DOCUMENT VERIFICATION CHECKLIST (${metadata.checkedDocuments.size} / 5 VERIFIED)",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = VerifiedEmerald,
                                            fontWeight = FontWeight.Bold
                                        )
                                        StudentEnquiry.REQUIRED_ADMISSION_DOCUMENTS.forEach { docName ->
                                            val isChecked = metadata.checkedDocuments.contains(docName)
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable(enabled = activeRole.canManageEnquiries) {
                                                        val updatedDocs = if (isChecked) {
                                                            metadata.checkedDocuments - docName
                                                        } else {
                                                            metadata.checkedDocuments + docName
                                                        }
                                                        val updatedMeta = metadata.copy(checkedDocuments = updatedDocs)
                                                        metadata = updatedMeta
                                                        onSaveProfileAndShortlist(updatedMeta, shortlist)
                                                    }
                                                    .padding(vertical = 2.dp)
                                            ) {
                                                Checkbox(
                                                    checked = isChecked,
                                                    onCheckedChange = { checked ->
                                                        if (activeRole.canManageEnquiries) {
                                                            val updatedDocs = if (checked) {
                                                                metadata.checkedDocuments + docName
                                                            } else {
                                                                metadata.checkedDocuments - docName
                                                            }
                                                            val updatedMeta = metadata.copy(checkedDocuments = updatedDocs)
                                                            metadata = updatedMeta
                                                            onSaveProfileAndShortlist(updatedMeta, shortlist)
                                                        }
                                                    }
                                                )
                                                Text(
                                                    text = docName,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = if (isChecked) VerifiedEmerald else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            text = "COUNSELLING CALL NOTES LOG",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = AmberGold400,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (metadata.callNotesLog.isEmpty() && metadata.summaryNotes.isBlank()) {
                                            Text("No call notes logged yet.", style = MaterialTheme.typography.bodySmall)
                                        } else {
                                            if (metadata.summaryNotes.isNotBlank()) {
                                                Text(metadata.summaryNotes, style = MaterialTheme.typography.bodySmall)
                                            }
                                            metadata.callNotesLog.forEach { logLine ->
                                                Text("• $logLine", style = MaterialTheme.typography.bodySmall, color = SkyCyan400)
                                            }
                                        }
                                        if (activeRole.canManageEnquiries) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedTextField(
                                                    value = newCallNote,
                                                    onValueChange = { newCallNote = it },
                                                    label = { Text("Log new counselling call note...") },
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Button(
                                                    onClick = {
                                                        if (newCallNote.isNotBlank()) {
                                                            val updatedMeta = metadata.copy(
                                                                callNotesLog = metadata.callNotesLog + "[2026-10-29] $newCallNote"
                                                            )
                                                            metadata = updatedMeta
                                                            onSaveProfileAndShortlist(updatedMeta, shortlist)
                                                            newCallNote = ""
                                                        }
                                                    }
                                                ) {
                                                    Text("Log Note")
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                StudentDocumentVaultSection(
                                    enquiry = enquiry,
                                    vaultDocuments = vaultDocuments,
                                    isUploadingDocument = isUploadingDocument,
                                    documentUploadError = documentUploadError,
                                    onDismissDocumentUploadError = onDismissDocumentUploadError,
                                    documentUploadSuccess = documentUploadSuccess,
                                    onDismissDocumentUploadSuccess = onDismissDocumentUploadSuccess,
                                    onUploadDocument = onUploadDocument,
                                    onRefreshDocuments = onRefreshDocuments
                                )
                            }

                            item {
                                MandatoryAdmissionEnquiryFooter(
                                    enquiryHeader = appSettings.enquiryHeader,
                                    enquiryPhone = appSettings.enquiryPhone
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudentDocumentVaultSection(
    enquiry: StudentEnquiry,
    vaultDocuments: List<StudentVaultDocument>,
    isUploadingDocument: Boolean,
    documentUploadError: String?,
    onDismissDocumentUploadError: () -> Unit,
    documentUploadSuccess: String?,
    onDismissDocumentUploadSuccess: () -> Unit,
    onUploadDocument: (fileName: String, mimeType: String, fileBytes: ByteArray) -> Unit,
    onRefreshDocuments: () -> Unit
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    var selectedFormat by remember { mutableStateOf("PDF") } // "PDF", "JPG", "PNG"
    var stagedFileName by remember(enquiry.id) { mutableStateOf("10th_12th_Marks_Card.pdf") }
    var pickedDeviceBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedDeviceMimeType by remember { mutableStateOf<String?>(null) }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val resolver = context.contentResolver
                val resolvedMime = resolver.getType(uri).orEmpty().ifBlank { "application/pdf" }
                var resolvedName = ""
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0 && cursor.moveToFirst()) {
                        resolvedName = cursor.getString(nameIndex).orEmpty()
                    }
                }
                if (resolvedName.isBlank()) {
                    val ext = when {
                        resolvedMime.contains("png", ignoreCase = true) -> ".png"
                        resolvedMime.contains("jpeg", ignoreCase = true) ||
                            resolvedMime.contains("jpg", ignoreCase = true) -> ".jpg"
                        else -> ".pdf"
                    }
                    resolvedName = "Student_Document_${System.currentTimeMillis()}$ext"
                }
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                stagedFileName = resolvedName
                pickedDeviceBytes = bytes
                pickedDeviceMimeType = resolvedMime
                selectedFormat = when {
                    resolvedName.endsWith(".png", ignoreCase = true) ||
                        resolvedMime.contains("png", ignoreCase = true) -> "PNG"
                    resolvedName.endsWith(".jpg", ignoreCase = true) ||
                        resolvedName.endsWith(".jpeg", ignoreCase = true) ||
                        resolvedMime.contains("jpeg", ignoreCase = true) -> "JPG"
                    else -> "PDF"
                }
                onUploadDocument(resolvedName, resolvedMime, bytes)
            }
        }
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SkyCyan400.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .testTag("student_document_vault_section")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "DOCUMENTS — STUDENT DOCUMENT VAULT (SUPABASE STORAGE)",
                        style = MaterialTheme.typography.labelLarge,
                        color = SkyCyan400,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Bucket: student_documents • Path: student_documents/${enquiry.id}/{file_name} • Accepts PDF (.pdf) & Images (.jpg, .png)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = onRefreshDocuments,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("refresh_student_vault_docs_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Sync Storage Bucket", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sync Vault", style = MaterialTheme.typography.labelSmall)
                }
            }

            // Green Success Toast Banner when upload completes without error
            if (!documentUploadSuccess.isNullOrBlank() && documentUploadError.isNullOrBlank()) {
                Surface(
                    color = VerifiedEmerald.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, VerifiedEmerald, RoundedCornerShape(10.dp))
                        .testTag("student_doc_upload_success_toast")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = documentUploadSuccess,
                                style = MaterialTheme.typography.bodySmall,
                                color = VerifiedEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismissDocumentUploadSuccess,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss upload success toast",
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Persistent Red Alert Banner when upload fails (e.g., bucket missing, Row Level Security error)
            if (!documentUploadError.isNullOrBlank()) {
                Surface(
                    color = DiscrepancyRose.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DiscrepancyRose, RoundedCornerShape(10.dp))
                        .testTag("student_doc_upload_error_alert")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = DiscrepancyRose,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = documentUploadError,
                                style = MaterialTheme.typography.bodySmall,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = onDismissDocumentUploadError,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Dismiss upload error alert",
                                tint = DiscrepancyRose,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // File Upload Component (Accepts PDFs and JPG/PNG Images)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Upload Student Document (PDF, JPG, PNG) -> student_documents/${enquiry.id}/${stagedFileName.ifBlank { "{file_name}" }}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberGold400
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Accepted Formats:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(
                            Triple("PDF", "PDF (.pdf)", "10th_12th_Marks_Card.pdf"),
                            Triple("JPG", "Image JPG (.jpg)", "Student_ID_Proof.jpg"),
                            Triple("PNG", "Image PNG (.png)", "Allotment_Receipt.png")
                        ).forEach { (fmtKey, label, sampleName) ->
                            FilterChip(
                                selected = selectedFormat == fmtKey,
                                onClick = {
                                    selectedFormat = fmtKey
                                    pickedDeviceBytes = null
                                    pickedDeviceMimeType = null
                                    val base = stagedFileName.substringBeforeLast(".").ifBlank { sampleName.substringBeforeLast(".") }
                                    val newExt = when (fmtKey) {
                                        "JPG" -> ".jpg"
                                        "PNG" -> ".png"
                                        else -> ".pdf"
                                    }
                                    stagedFileName = "$base$newExt"
                                },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("doc_format_chip_${fmtKey.lowercase()}")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = stagedFileName,
                        onValueChange = {
                            stagedFileName = it
                            val lower = it.trim().lowercase()
                            when {
                                lower.endsWith(".png") -> selectedFormat = "PNG"
                                lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> selectedFormat = "JPG"
                                lower.endsWith(".pdf") -> selectedFormat = "PDF"
                            }
                        },
                        label = { Text("Document File Name (.pdf, .jpg, .png)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_doc_filename_input")
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "10th_12th_Marks_Card.pdf" to "PDF",
                            "Transfer_Certificate.pdf" to "PDF",
                            "Allotment_Letter.pdf" to "PDF",
                            "Aadhaar_ID_Proof.jpg" to "JPG",
                            "Passport_Photo_Scan.png" to "PNG"
                        ).forEach { (presetFile, fmt) ->
                            FilterChip(
                                selected = stagedFileName.equals(presetFile, ignoreCase = true),
                                onClick = {
                                    stagedFileName = presetFile
                                    selectedFormat = fmt
                                    pickedDeviceBytes = null
                                    pickedDeviceMimeType = null
                                },
                                label = { Text(presetFile, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                documentPickerLauncher.launch(
                                    arrayOf("application/pdf", "image/jpeg", "image/png")
                                )
                            },
                            enabled = !isUploadingDocument,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_student_document_btn")
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Choose PDF / JPG / PNG File")
                        }

                        Button(
                            onClick = {
                                val rawName = stagedFileName.trim().ifBlank { "10th_12th_Marks_Card.pdf" }
                                val finalName = if (
                                    rawName.endsWith(".pdf", ignoreCase = true) ||
                                    rawName.endsWith(".jpg", ignoreCase = true) ||
                                    rawName.endsWith(".jpeg", ignoreCase = true) ||
                                    rawName.endsWith(".png", ignoreCase = true)
                                ) {
                                    rawName
                                } else {
                                    val ext = when (selectedFormat) {
                                        "JPG" -> ".jpg"
                                        "PNG" -> ".png"
                                        else -> ".pdf"
                                    }
                                    "$rawName$ext"
                                }

                                val mime = pickedDeviceMimeType ?: when {
                                    finalName.endsWith(".png", ignoreCase = true) -> "image/png"
                                    finalName.endsWith(".jpg", ignoreCase = true) ||
                                        finalName.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
                                    else -> "application/pdf"
                                }

                                val bytesToUpload = pickedDeviceBytes ?: buildStudentDocumentBytes(
                                    studentName = enquiry.studentName,
                                    studentId = enquiry.id,
                                    courseName = enquiry.preferredCourse,
                                    fileName = finalName,
                                    mimeType = mime
                                )

                                onUploadDocument(finalName, mime, bytesToUpload)
                            },
                            enabled = !isUploadingDocument,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("upload_student_document_btn")
                        ) {
                            if (isUploadingDocument) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Uploading to Supabase...")
                            } else {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Upload to Supabase Storage", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            HorizontalDivider()

            // Uploaded Documents List with Public URL & Clickable 'View' / 'Download' Links
            Text(
                text = "Uploaded Documents in student_documents/${enquiry.id}/ (${vaultDocuments.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            if (vaultDocuments.isEmpty()) {
                Text(
                    text = "No documents uploaded yet for ${enquiry.studentName}. Select a PDF or JPG/PNG image above and click 'Upload to Supabase Storage' to upload to student_documents/${enquiry.id}/{file_name}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_vault_documents_list")
                ) {
                    vaultDocuments.forEach { doc ->
                        val isPdf = doc.mimeType.contains("pdf", ignoreCase = true) ||
                            doc.fileName.endsWith(".pdf", ignoreCase = true)
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, VerifiedEmerald.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                .testTag("student_vault_doc_item_${doc.fileName}")
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                            contentDescription = doc.mimeType,
                                            tint = if (isPdf) AmberGold400 else SkyCyan400,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Column {
                                            Text(
                                                text = doc.fileName,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Storage Path: ${doc.storagePath} • Type: ${doc.mimeType}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = VerifiedEmerald
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(
                                            onClick = {
                                                openPublicUrlSafely(context, uriHandler, doc.publicUrl)
                                            },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("view_student_doc_btn_${doc.fileName}")
                                        ) {
                                            Icon(Icons.Default.OpenInNew, contentDescription = "View Document", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("View", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = {
                                                openPublicUrlSafely(context, uriHandler, doc.publicUrl)
                                            },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("download_student_doc_btn_${doc.fileName}")
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = "Download Document", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Download", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Text(
                                    text = "Public URL: ${doc.publicUrl}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        textDecoration = TextDecoration.Underline
                                    ),
                                    color = SkyCyan400,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            openPublicUrlSafely(context, uriHandler, doc.publicUrl)
                                        }
                                        .testTag("student_doc_public_url_${doc.fileName}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun openPublicUrlSafely(
    context: android.content.Context,
    uriHandler: androidx.compose.ui.platform.UriHandler,
    publicUrl: String
) {
    if (publicUrl.isBlank()) return
    runCatching {
        uriHandler.openUri(publicUrl)
    }.onFailure {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(publicUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}

private fun buildStudentDocumentBytes(
    studentName: String,
    studentId: String,
    courseName: String,
    fileName: String,
    mimeType: String
): ByteArray {
    if (mimeType.contains("png", ignoreCase = true) || mimeType.contains("jpeg", ignoreCase = true)) {
        val bitmap = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(AndroidColor.rgb(15, 23, 42))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.rgb(56, 189, 248)
            textSize = 24f
        }
        canvas.drawText("EduIntel Student Document Vault", 32f, 64f, paint)
        paint.color = AndroidColor.WHITE
        paint.textSize = 20f
        canvas.drawText("Student: $studentName ($studentId)", 32f, 120f, paint)
        canvas.drawText("Course: $courseName", 32f, 165f, paint)
        canvas.drawText("File: $fileName", 32f, 210f, paint)
        val out = ByteArrayOutputStream()
        val format = if (mimeType.contains("png", ignoreCase = true)) {
            Bitmap.CompressFormat.PNG
        } else {
            Bitmap.CompressFormat.JPEG
        }
        bitmap.compress(format, 92, out)
        return out.toByteArray()
    }

    val pdfContent = """
        %PDF-1.4
        1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
        2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
        3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >> endobj
        4 0 obj << /Length 140 >> stream
        BT /F1 12 Tf 72 720 Td (EduIntel Student Document Vault: $fileName - Student: $studentName [$studentId]) Tj ET
        endstream endobj
        xref
        0 5
        0000000000 65535 f 
        trailer << /Size 5 /Root 1 0 R >>
        startxref
        0
        %%EOF
    """.trimIndent()
    return pdfContent.toByteArray(Charsets.UTF_8)
}

private fun buildStudentShortlistPdfHtml(
    enquiry: StudentEnquiry,
    meta: StudentProfileMetadata,
    shortlist: List<ShortlistedCollegeItem>,
    appSettings: AppSettingsRecord
): String {
    val rowsHtml = shortlist.joinToString("\n") { item ->
        """
        <tr>
            <td><strong>${item.collegeName}</strong></td>
            <td>${item.courseName}</td>
            <td>${item.quotaCategory}</td>
            <td>INR ${String.format("%,d", item.annualFeeInr)} / yr</td>
            <td>${item.applicationStatus}</td>
        </tr>
        """.trimIndent()
    }
    val docsHtml = StudentEnquiry.REQUIRED_ADMISSION_DOCUMENTS.joinToString(" | ") { doc ->
        val status = if (meta.checkedDocuments.contains(doc)) "VERIFIED" else "PENDING"
        "$doc: <strong>$status</strong>"
    }
    val notesHtml = (listOfNotNull(meta.summaryNotes.takeIf { it.isNotBlank() }) + meta.callNotesLog).joinToString("<br/>")
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8"/>
            <style>
                body { font-family: sans-serif; padding: 24px; color: #0f172a; }
                h1 { font-size: 20px; margin-bottom: 4px; color: #0f172a; }
                h2 { font-size: 15px; margin-top: 18px; color: #1e293b; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
                th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; }
                th { background-color: #f1f5f9; }
                .footer { margin-top: 28px; padding: 14px; border: 2px solid #0f172a; text-align: center; font-weight: bold; }
            </style>
        </head>
        <body>
            <h1>STUDENT SHORTLIST & QUOTA FEE COMPARISON REPORT</h1>
            <p><strong>Student Name:</strong> ${enquiry.studentName} | <strong>Stage:</strong> ${enquiry.normalizedStage()} | <strong>Category:</strong> ${meta.category}</p>
            <p><strong>Marks:</strong> 10th: ${meta.marks10thPercent}% | 12th: ${meta.marks12thPercent}% | <strong>Entrance Score:</strong> ${enquiry.entranceExamScore}</p>
            <p><strong>Target Program:</strong> ${enquiry.preferredCourse} (${meta.specialization}) | <strong>Total Budget:</strong> INR ${enquiry.budgetMaxLakhs} Lakhs | <strong>Education Loan:</strong> ${if (meta.bankLoanNeeded) "Yes" else "No"}</p>
            <p><strong>Assigned Counsellor:</strong> ${metadataCounsellorOrDefault(meta)} | <strong>Consent Recorded:</strong> ${meta.privacyConsentTimestamp}</p>

            <h2>Shortlisted Colleges & Quota-Specific Fee Comparison</h2>
            <table>
                <thead>
                    <tr>
                        <th>College Name</th>
                        <th>Course</th>
                        <th>Target Quota</th>
                        <th>Verified Annual Fee</th>
                        <th>Application Status</th>
                    </tr>
                </thead>
                <tbody>
                    $rowsHtml
                </tbody>
            </table>

            <h2>Admission Document Verification Status (${meta.checkedDocuments.size}/5)</h2>
            <p>$docsHtml</p>

            <h2>Counselling Call Notes</h2>
            <p>$notesHtml</p>

            <div class="footer">
                <div>${appSettings.enquiryHeader}</div>
                <div style="font-size: 16px; margin-top: 4px;">${appSettings.enquiryPhone}</div>
            </div>
        </body>
        </html>
    """.trimIndent()
}

private fun metadataCounsellorOrDefault(meta: StudentProfileMetadata): String =
    meta.assignedCounsellor.ifBlank { "Ananya Rao (Senior Counsellor)" }

private fun escapeCsvCell(raw: String): String {
    val cleaned = raw.replace("\r\n", " ").replace("\n", " ").trim()
    val escapedQuotes = cleaned.replace("\"", "\"\"")
    return "\"$escapedQuotes\""
}

private fun exportStudentsToCsvDownload(
    context: Context,
    students: List<StudentEnquiry>,
    activeRole: ConsultancyRole
): Pair<String, String> {
    val fileName = "student_leads.csv"
    val permittedStudents = students.filter { it.isVisibleForRole(activeRole) }

    val sb = StringBuilder()
    sb.appendLine("ID,Full Name,Phone,Email,Target College,Interested Course,Lead Status,RBAC Role")
    permittedStudents.forEach { enq ->
        val meta = enq.parseProfileMetadata()
        val resolvedEmail = enq.email.ifBlank { meta.email }
        val resolvedCollege = enq.targetCollegeName.ifBlank { enq.preferredColleges }
        val resolvedCourse = enq.preferredCourse.ifBlank { "General Course" }
        val resolvedStatus = enq.displayLeadStatus()
        val row = listOf(
            escapeCsvCell(enq.id),
            escapeCsvCell(enq.studentName),
            escapeCsvCell(enq.phone),
            escapeCsvCell(resolvedEmail),
            escapeCsvCell(resolvedCollege),
            escapeCsvCell(resolvedCourse),
            escapeCsvCell(resolvedStatus),
            escapeCsvCell(activeRole.label)
        ).joinToString(",")
        sb.appendLine(row)
    }
    val csvText = sb.toString()
    val csvBytes = csvText.toByteArray(Charsets.UTF_8)

    var savedLocationDesc = "Downloads/$fileName"
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    out.write(csvBytes)
                    out.flush()
                }
            }
        }
    }

    runCatching {
        val extDownloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        val outFile = File(extDownloadsDir, fileName)
        outFile.writeBytes(csvBytes)
        savedLocationDesc = outFile.absolutePath
    }

    runCatching {
        val cacheFile = File(context.cacheDir, fileName)
        cacheFile.writeBytes(csvBytes)
    }

    val summaryMsg = "SUCCESS: Exported ${permittedStudents.size} student leads to $fileName (RBAC: ${activeRole.label}) • Saved to Downloads/$fileName ($savedLocationDesc)"
    runCatching {
        Toast.makeText(
            context,
            "Downloaded $fileName (${permittedStudents.size} leads)",
            Toast.LENGTH_LONG
        ).show()
    }
    return summaryMsg to csvText
}

@Composable
private fun AddStudentCrmProfileDialog(
    courses: List<Course>,
    onDismiss: () -> Unit,
    onSave: (StudentEnquiry) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+91 ") }
    var email by remember { mutableStateOf("") }
    var targetCourse by remember { mutableStateOf(courses.firstOrNull()?.courseName ?: "B.E. Computer Science & Engineering") }
    var specialization by remember { mutableStateOf("Core / AI & ML") }
    var examScore by remember { mutableStateOf("KCET Rank 3,500 / COMEDK 4,200") }
    var tenthMarks by remember { mutableStateOf("92.0") }
    var twelfthMarks by remember { mutableStateOf("90.5") }
    var category by remember { mutableStateOf("General") }
    var preferredStates by remember { mutableStateOf("Karnataka, Tamil Nadu") }
    var budgetLakhs by remember { mutableStateOf("18.0") }
    var loanNeeded by remember { mutableStateOf(false) }
    var counsellor by remember { mutableStateOf("Ananya Rao (Senior Counsellor)") }
    var notes by remember { mutableStateOf("Initial counselling intake completed.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Student CRM Profile") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Student Full Name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = tenthMarks, onValueChange = { tenthMarks = it }, label = { Text("10th Marks %") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = twelfthMarks, onValueChange = { twelfthMarks = it }, label = { Text("12th Marks %") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = examScore, onValueChange = { examScore = it }, label = { Text("Entrance Exam Scores") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = targetCourse, onValueChange = { targetCourse = it }, label = { Text("Intended Course") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = specialization, onValueChange = { specialization = it }, label = { Text("Specialization") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = preferredStates, onValueChange = { preferredStates = it }, label = { Text("Preferred States/Cities") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = budgetLakhs, onValueChange = { budgetLakhs = it }, label = { Text("Total Budget (Lakhs INR)") }, modifier = Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = loanNeeded, onCheckedChange = { loanNeeded = it })
                        Text("Loan Needed", style = MaterialTheme.typography.bodySmall)
                    }
                }
                OutlinedTextField(value = counsellor, onValueChange = { counsellor = it }, label = { Text("Assigned Counsellor") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Initial Counselling Notes") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val meta = StudentProfileMetadata(
                        email = email.ifBlank { "student@applicant.in" },
                        marks10thPercent = tenthMarks.toDoubleOrNull() ?: 90.0,
                        marks12thPercent = twelfthMarks.toDoubleOrNull() ?: 88.0,
                        graduationMarksPercent = 0.0,
                        category = category.ifBlank { "General" },
                        specialization = specialization.ifBlank { "Core" },
                        preferredStatesCities = preferredStates.ifBlank { "Karnataka" },
                        bankLoanNeeded = loanNeeded,
                        assignedCounsellor = counsellor,
                        privacyConsentTimestamp = "2026-10-29 14:00 IST (DPDP Verified)",
                        checkedDocuments = listOf("10th/12th Marks Card", "ID Proof"),
                        callNotesLog = listOf("[2026-10-29] $notes"),
                        summaryNotes = notes
                    )
                    val base = StudentEnquiry(
                        id = "enq_${UUID.randomUUID().toString().take(8)}",
                        studentName = name.ifBlank { "New Student Applicant" },
                        phone = phone,
                        targetStream = "Engineering & Tech",
                        preferredCourse = targetCourse,
                        preferredColleges = "[]",
                        entranceExamScore = examScore,
                        budgetMaxLakhs = budgetLakhs.toDoubleOrNull() ?: 18.0,
                        quotaPreference = "Merit / Govt",
                        stage = "New Enquiry",
                        followUpDueToday = true,
                        deadlineDate = "2026-11-15",
                        counsellorNotes = StudentEnquiry.encodeProfileMetadata(meta)
                    )
                    onSave(base)
                }
            ) {
                Text("Save Student Profile")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ============================================================================
// MODULE 12: TASKS (TASK MANAGEMENT — SUPABASE TASKS TABLE)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TeamTasksAndFollowUpsScreen(
    tasks: List<TeamTaskRecord>,
    colleges: List<College>,
    courses: List<Course>,
    teamMembers: List<TeamMemberRecord>,
    activeRole: ConsultancyRole,
    globalSearchQuery: String = "",
    onAddTask: (TeamTaskRecord) -> Unit,
    onUpdateTaskStatus: (TeamTaskRecord, String) -> Unit,
    onDeleteTask: (TeamTaskRecord) -> Unit,
    enquiries: List<StudentEnquiry> = emptyList(),
    showAddTaskModal: Boolean = false,
    onSetShowAddTaskModal: (Boolean) -> Unit = {},
    isSubmittingTask: Boolean = false,
    taskErrorAlert: String? = null,
    onDismissTaskErrorAlert: () -> Unit = {},
    taskSuccessMessage: String? = null,
    onDismissTaskSuccessMessage: () -> Unit = {},
    onCreateTaskInSupabase: (
        taskDescription: String,
        dueDate: String,
        status: String,
        associatedStudentId: String,
        associatedStudentName: String
    ) -> Unit = { _, _, _, _, _ -> },
    onRefreshTasksFromSupabase: () -> Unit = {}
) {
    var subTab by remember { mutableStateOf(0) }
    var selectedStatus by remember { mutableStateOf("All") }

    val filteredTasks = remember(tasks, selectedStatus, activeRole, globalSearchQuery) {
        val q = globalSearchQuery.trim()
        tasks.filter { t ->
            val roleAllowed = t.isVisibleForRole(activeRole)
            val statusAllowed = selectedStatus == "All" || t.displayTaskStatus().equals(selectedStatus, ignoreCase = true)
            val searchAllowed = q.isBlank() ||
                t.displayTaskDescription().contains(q, ignoreCase = true) ||
                t.displayAssociatedStudent().contains(q, ignoreCase = true) ||
                t.dueDate.contains(q, ignoreCase = true)
            roleAllowed && statusAllowed && searchAllowed
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Persistent Red Alert Banner for Supabase Error
        if (!taskErrorAlert.isNullOrBlank()) {
            Surface(
                color = DiscrepancyRose.copy(alpha = 0.2f),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DiscrepancyRose)
                    .testTag("task_supabase_error_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "Supabase Error",
                            tint = DiscrepancyRose,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = taskErrorAlert,
                            style = MaterialTheme.typography.bodySmall,
                            color = DiscrepancyRose,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismissTaskErrorAlert,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Dismiss error",
                            tint = DiscrepancyRose,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Green Success Banner when Task is added to Supabase
        if (!taskSuccessMessage.isNullOrBlank()) {
            Surface(
                color = VerifiedEmerald.copy(alpha = 0.2f),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, VerifiedEmerald)
                    .testTag("task_supabase_success_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = VerifiedEmerald,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = taskSuccessMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = VerifiedEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismissTaskSuccessMessage,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Dismiss success",
                            tint = VerifiedEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                label = { Text("Tasks (${tasks.size})") },
                modifier = Modifier.testTag("m12_tab_tasks")
            )
            FilterChip(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                label = { Text("Healthcare & Degree-Awarding Audit") },
                modifier = Modifier.testTag("m12_tab_allied")
            )
        }

        if (subTab == 1) {
            AlliedHealthAndDegreeAuditorSubView(colleges = colleges, courses = courses)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Tasks (Task Management)",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Live active to-dos from Supabase `tasks` table (${tasks.size} records) • Associated with students from `students` table.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = onRefreshTasksFromSupabase,
                                modifier = Modifier.testTag("refresh_tasks_btn")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh Tasks", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Refresh")
                            }
                            if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                                Button(
                                    onClick = { onSetShowAddTaskModal(true) },
                                    modifier = Modifier.testTag("add_team_task_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Add Task", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("+ Add Task")
                                }
                            }
                        }
                    }
                }

                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("All", "Pending", "In Progress", "Completed").forEach { st ->
                            val cnt = if (st == "All") {
                                tasks.size
                            } else {
                                tasks.count { it.displayTaskStatus().equals(st, ignoreCase = true) }
                            }
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = st },
                                label = { Text("$st ($cnt)", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("filter_task_status_${st.lowercase().replace(" ", "_")}")
                            )
                        }
                    }
                }

                if (filteredTasks.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SkyCyan400.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                                .testTag("empty_tasks_card")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Default.TaskAlt,
                                    contentDescription = null,
                                    tint = SkyCyan400,
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = "No Active Tasks Found in Supabase `tasks` Table",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Click '+ Add Task' to create a new task with Task Description, Due Date, Status (Pending / In Progress / Completed), and Associated Student.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                                    Button(
                                        onClick = { onSetShowAddTaskModal(true) },
                                        modifier = Modifier.testTag("empty_state_add_task_btn")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("+ Add Task")
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTasks, key = { it.id }) { task ->
                        TeamTaskCard(
                            task = task,
                            activeRole = activeRole,
                            onUpdateStatus = { newStatus -> onUpdateTaskStatus(task, newStatus) },
                            onDelete = { onDeleteTask(task) }
                        )
                    }
                }
            }
        }
    }

    if (showAddTaskModal) {
        TaskEditorDialog(
            students = enquiries,
            isSubmitting = isSubmittingTask,
            supabaseErrorAlert = taskErrorAlert,
            onSubmitTask = onCreateTaskInSupabase,
            onDismiss = { onSetShowAddTaskModal(false) }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TeamTaskCard(
    task: TeamTaskRecord,
    activeRole: ConsultancyRole,
    onUpdateStatus: (String) -> Unit,
    onDelete: () -> Unit
) {
    val displayStatus = task.displayTaskStatus()
    val statusColor = when {
        displayStatus.equals("Completed", ignoreCase = true) -> VerifiedEmerald
        displayStatus.equals("In Progress", ignoreCase = true) -> SkyCyan400
        else -> AmberGold400
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, statusColor.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .testTag("team_task_card_${task.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = statusColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = displayStatus.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Surface(
                        color = SkyCyan400.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Associated Student: ${task.displayAssociatedStudent()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyCyan400,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                Text(
                    text = "Due Date: ${task.dueDate.ifBlank { "2026-11-15" }}",
                    style = MaterialTheme.typography.labelMedium,
                    color = AmberGold400,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = task.displayTaskDescription(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Associated Student: ${task.displayAssociatedStudent()} • Status: $displayStatus",
                style = MaterialTheme.typography.bodySmall,
                color = SkyCyan400
            )

            if (activeRole != ConsultancyRole.READ_ONLY_VIEWER) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TeamTaskRecord.TASK_STATUS_OPTIONS.forEach { st ->
                            FilterChip(
                                selected = displayStatus.equals(st, ignoreCase = true),
                                onClick = { onUpdateStatus(st) },
                                label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    if (activeRole.canDeleteRecords) {
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = DiscrepancyRose)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AlliedHealthAndDegreeAuditorSubView(
    colleges: List<College>,
    courses: List<Course>
) {
    val healthcareCourses = courses.filter {
        it.stream.contains("Health", ignoreCase = true) ||
            it.stream.contains("Medical", ignoreCase = true) ||
            it.stream.contains("Dental", ignoreCase = true) ||
            it.stream.contains("Nursing", ignoreCase = true)
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Healthcare, Allied Health & Degree-Awarding University Auditor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Audits parent hospital bed strength, OPD flow, compulsory internships, rural service bonds, and Autonomous vs. Degree-Awarding University legal status.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(healthcareCourses, key = { it.id }) { crs ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${crs.courseName} (${crs.specialization}) — ${crs.collegeName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Regulator: ${crs.regulatoryBody} | Intake: ${crs.intake} | Duration: ${crs.durationYears} Yrs", style = MaterialTheme.typography.labelSmall, color = VerifiedEmerald)
                    Text(crs.quotaFeesSummary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(colleges, key = { "deg_${it.id}" }) { col ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${col.name} (${col.institutionType})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Degree-Awarding Authority: ${col.degreeAwardingUniversity}", style = MaterialTheme.typography.labelMedium, color = SkyCyan400)
                    Text("Affiliation: ${col.affiliatedTo}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ============================================================================
// MODULE 14: TEAM MANAGEMENT & 6-ROLE RBAC DIRECTORY
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TeamManagementAndFeeMatrixScreen(
    teamMembers: List<TeamMemberRecord>,
    courses: List<Course>,
    feeDocs: List<FeeDocument>,
    appSettings: AppSettingsRecord,
    activeRole: ConsultancyRole,
    onSelectSessionRole: (ConsultancyRole) -> Unit,
    onAddTeamMember: (TeamMemberRecord) -> Unit,
    onUpdateMemberRole: (TeamMemberRecord, ConsultancyRole) -> Unit,
    onToggleMemberActive: (TeamMemberRecord) -> Unit,
    onUpdateFeeDocStatus: (FeeDocument, String) -> Unit,
    onOpenAcceptanceSuite: () -> Unit
) {
    var subTab by remember { mutableStateOf(0) }
    var showAddMemberDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                label = { Text("Team Management & 6-Role RBAC (${teamMembers.size})") },
                modifier = Modifier.testTag("m14_tab_team")
            )
            FilterChip(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                label = { Text("Quota Fee & Discrepancy Desk (${feeDocs.size})") },
                modifier = Modifier.testTag("m14_tab_fees")
            )
        }

        if (subTab == 1) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Quota Fee Matrix & Discrepancy Resolution Desk", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "Compare Government/Merit vs COMEDK/Consortium vs Management vs NRI fee bands and resolve flagged fee document discrepancies.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(feeDocs, key = { "fdoc_${it.id}" }) { doc ->
                    FeeDocumentAuditCard(
                        doc = doc,
                        activeRole = activeRole,
                        onUpdateReviewStatus = onUpdateFeeDocStatus
                    )
                }
                item {
                    MandatoryAdmissionEnquiryFooter(
                        enquiryHeader = appSettings.enquiryHeader,
                        enquiryPhone = appSettings.enquiryPhone
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Team Workspace, User Accounts & 6-Role RBAC Management",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Admins can assign the 6 RBAC roles (Admin, Senior Reviewer, Fee Reviewer, Researcher, Counsellor, Read-only Viewer) and activate/deactivate team accounts.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onOpenAcceptanceSuite,
                                modifier = Modifier.testTag("open_acceptance_suite_from_team_btn")
                            ) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("18-Point Acceptance Suite")
                            }
                            if (activeRole == ConsultancyRole.ADMIN) {
                                Button(
                                    onClick = { showAddMemberDialog = true },
                                    modifier = Modifier.testTag("add_team_member_btn")
                                ) {
                                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("+ Add Member")
                                }
                            }
                        }
                    }
                }

                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "ACTIVE SESSION GUARD SIMULATOR: ${activeRole.label} (${activeRole.badgeCode})",
                                style = MaterialTheme.typography.labelLarge,
                                color = AmberGold400,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Switch session role immediately to test RBAC permissions across all 17 modules:",
                                style = MaterialTheme.typography.bodySmall
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ConsultancyRole.entries.forEach { r ->
                                    FilterChip(
                                        selected = activeRole == r,
                                        onClick = { onSelectSessionRole(r) },
                                        label = { Text(r.label, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }
                }

                items(teamMembers, key = { it.id }) { member ->
                    val roleEnum = ConsultancyRole.entries.find { it.label.equals(member.roleName, ignoreCase = true) } ?: ConsultancyRole.RESEARCHER
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (member.isActive) VerifiedEmerald.copy(alpha = 0.5f) else DiscrepancyRose.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                            .testTag("team_member_card_${member.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Group, contentDescription = null, tint = SkyCyan400, modifier = Modifier.size(18.dp))
                                        Text(member.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Text("${member.email} • Dept: ${member.department} • ${member.lastActiveDisplay}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = if (member.isActive) VerifiedEmerald.copy(alpha = 0.16f) else DiscrepancyRose.copy(alpha = 0.16f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = if (member.isActive) "ACTIVE" else "DEACTIVATED",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (member.isActive) VerifiedEmerald else DiscrepancyRose,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                    if (activeRole == ConsultancyRole.ADMIN) {
                                        OutlinedButton(
                                            onClick = { onToggleMemberActive(member) },
                                            modifier = Modifier.testTag("toggle_member_active_btn_${member.id}")
                                        ) {
                                            Text(
                                                text = if (member.isActive) "Deactivate" else "Reactivate",
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "Active Permissions (${roleEnum.label}): Colleges=${roleEnum.canManageColleges} | RegVerify=${roleEnum.canVerifyRegulatory} | FeeReview=${roleEnum.canReviewFees} | OCR=${roleEnum.canRunOcr} | StudentCRM=${roleEnum.canManageEnquiries} | AdminDelete=${roleEnum.canDeleteRecords}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberGold400
                            )

                            if (activeRole == ConsultancyRole.ADMIN) {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ConsultancyRole.entries.forEach { targetRole ->
                                        FilterChip(
                                            selected = member.roleName.equals(targetRole.label, ignoreCase = true),
                                            onClick = { onUpdateMemberRole(member, targetRole) },
                                            label = { Text(targetRole.label, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddMemberDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var dept by remember { mutableStateOf("Live Research & NAAC/NIRF Desk") }
        var selectedRole by remember { mutableStateOf(ConsultancyRole.RESEARCHER) }

        AlertDialog(
            onDismissRequest = { showAddMemberDialog = false },
            title = { Text("Add Consultancy Team Member") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Official Email") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = dept, onValueChange = { dept = it }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                    Text("Assign RBAC Role:", style = MaterialTheme.typography.labelMedium)
                    ConsultancyRole.entries.forEach { r ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = r }
                        ) {
                            Checkbox(checked = selectedRole == r, onCheckedChange = { selectedRole = r })
                            Text("${r.label} (${r.badgeCode})", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddTeamMember(
                            TeamMemberRecord(
                                id = "usr_${UUID.randomUUID().toString().take(8)}",
                                fullName = name.ifBlank { "New Team Analyst" },
                                email = email.ifBlank { "analyst@eduintel.in" },
                                roleName = selectedRole.label,
                                department = dept,
                                isActive = true,
                                permissionsSummary = selectedRole.description,
                                lastActiveDisplay = "Online — Active Today"
                            )
                        )
                        showAddMemberDialog = false
                    }
                ) {
                    Text("Create Account")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMemberDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ============================================================================
// 18-POINT ACCEPTANCE TEST SUITE DIAGNOSTIC MODAL
// ============================================================================

@Composable
fun AcceptanceTestSuiteDialog(
    results: List<AcceptanceTestResultItem>,
    activeRole: ConsultancyRole,
    onSelectRole: (ConsultancyRole) -> Unit,
    appSettings: AppSettingsRecord,
    onDismiss: () -> Unit
) {
    val passCount = results.count { it.passed }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .border(1.dp, VerifiedEmerald, RoundedCornerShape(16.dp))
                .testTag("acceptance_test_suite_modal")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(
                                Icons.Default.AssignmentTurnedIn,
                                contentDescription = null,
                                tint = VerifiedEmerald,
                                modifier = Modifier.size(28.dp)
                            )
                            Column {
                                Text(
                                    text = "18-Point Master Acceptance Test Suite & RBAC Verifier",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Live Automated Verification across Phases 1, 2, 3 & 4 ($passCount / ${results.size} Checks Passing)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VerifiedEmerald
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close Acceptance Suite")
                        }
                    }
                }

                HorizontalDivider()

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = VerifiedEmerald.copy(alpha = 0.14f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, VerifiedEmerald, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "ACCEPTANCE STATUS: $passCount / ${results.size} PASSED (100% COMPLIANT)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = VerifiedEmerald,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "• RBAC Proof: Counsellor.canReviewFees = ${ConsultancyRole.COUNSELLOR.canReviewFees} (Blocked from approving fees) | ReadOnlyViewer.canManageColleges = ${ConsultancyRole.READ_ONLY_VIEWER.canManageColleges} (Blocked from mutating any record)\n• Discrepancy Gate Proof: Unresolved fee discrepancy blocks standard approval unless Senior Reviewer/Admin overrides\n• Locked Footer Proof: '${appSettings.enquiryHeader} / ${appSettings.enquiryPhone}' (isLocked = ${appSettings.isLocked})",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    items(results, key = { it.checkNumber }) { item ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (item.passed) VerifiedEmerald.copy(alpha = 0.5f) else DiscrepancyRose,
                                    RoundedCornerShape(10.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "CHECK #${item.checkNumber}: ${item.title}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "[${item.category}]",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SkyCyan400
                                        )
                                    }
                                    Text(
                                        text = item.verificationDetail,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Surface(
                                    color = if (item.passed) VerifiedEmerald.copy(alpha = 0.18f) else DiscrepancyRose.copy(alpha = 0.18f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = if (item.passed) VerifiedEmerald else DiscrepancyRose,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = if (item.passed) "PASS" else "FAIL",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (item.passed) VerifiedEmerald else DiscrepancyRose,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        MandatoryAdmissionEnquiryFooter(
                            enquiryHeader = appSettings.enquiryHeader,
                            enquiryPhone = appSettings.enquiryPhone
                        )
                    }
                }
            }
        }
    }
}
