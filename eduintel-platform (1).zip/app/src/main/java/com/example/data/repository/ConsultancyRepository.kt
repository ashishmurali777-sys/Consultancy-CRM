package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AdmissionDeadlineRecord
import com.example.data.model.AppSettingsRecord
import com.example.data.model.AuditLogEntry
import com.example.data.model.College
import com.example.data.model.CollegeBriefingVersion
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.PlacementRecord
import com.example.data.model.SourceVerificationItem
import com.example.data.model.StudentEnquiry
import com.example.data.model.TeamMemberRecord
import com.example.data.model.TeamTaskRecord
import com.example.data.seed.DemoSeedData
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ConsultancyRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    // -------------------------------------------------------------------------
    // 1. REAL-TIME STREAMS (Scoped to userId to satisfy Firestore Security Rules)
    // -------------------------------------------------------------------------

    fun observeColleges(userId: String): Flow<List<College>> =
        db.collection(COL_COLLEGES)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(College::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.name }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_COLLEGES)
                throw error
            }

    fun observeCourses(userId: String): Flow<List<Course>> =
        db.collection(COL_COURSES)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Course::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.courseName }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_COURSES)
                throw error
            }

    fun observeFeeDocuments(userId: String): Flow<List<FeeDocument>> =
        db.collection(COL_FEE_DOCS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(FeeDocument::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_FEE_DOCS)
                throw error
            }

    fun observeEnquiries(userId: String): Flow<List<StudentEnquiry>> =
        db.collection(COL_ENQUIRIES)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(StudentEnquiry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.deadlineDate }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_ENQUIRIES)
                throw error
            }

    fun observeSourceQueue(userId: String): Flow<List<SourceVerificationItem>> =
        db.collection(COL_SOURCE_QUEUE)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(SourceVerificationItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_SOURCE_QUEUE)
                throw error
            }

    fun observeBriefingVersions(userId: String): Flow<List<CollegeBriefingVersion>> =
        db.collection(COL_BRIEFING_VERSIONS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(CollegeBriefingVersion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedWith(
                    compareBy<CollegeBriefingVersion> { it.collegeName }
                        .thenByDescending { it.versionNumber }
                )
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_BRIEFING_VERSIONS)
                throw error
            }

    fun observeAuditLogs(userId: String): Flow<List<AuditLogEntry>> =
        db.collection(COL_AUDIT_LOGS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(AuditLogEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_AUDIT_LOGS)
                throw error
            }

    fun observeAppSettings(userId: String): Flow<AppSettingsRecord> =
        db.collection(COL_APP_SETTINGS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.firstOrNull()
                    ?.toObject(AppSettingsRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: AppSettingsRecord(userId = userId)
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_APP_SETTINGS)
                throw error
            }

    fun observePlacements(userId: String): Flow<List<PlacementRecord>> =
        db.collection(COL_PLACEMENTS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(PlacementRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedWith(
                    compareBy<PlacementRecord> { it.collegeName }
                        .thenByDescending { it.academicYear }
                )
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_PLACEMENTS)
                throw error
            }

    fun observeCollegeReviews(userId: String): Flow<List<CollegeReviewRecord>> =
        db.collection(COL_COLLEGE_REVIEWS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(CollegeReviewRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.retrievedDate }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_COLLEGE_REVIEWS)
                throw error
            }

    fun observeAdmissionDeadlines(userId: String): Flow<List<AdmissionDeadlineRecord>> =
        db.collection(COL_ADMISSION_DEADLINES)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(AdmissionDeadlineRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedWith(
                    compareByDescending<AdmissionDeadlineRecord> { it.hasConflict || it.isOverdueRefresh }
                        .thenBy { it.collegeName }
                )
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_ADMISSION_DEADLINES)
                throw error
            }

    fun observeTeamTasks(userId: String): Flow<List<TeamTaskRecord>> =
        db.collection(COL_TEAM_TASKS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(TeamTaskRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedWith(
                    compareBy<TeamTaskRecord> { it.status == "Completed" }
                        .thenBy { it.dueDate }
                )
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_TEAM_TASKS)
                throw error
            }

    fun observeTeamMembers(userId: String): Flow<List<TeamMemberRecord>> =
        db.collection(COL_TEAM_MEMBERS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(TeamMemberRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.fullName }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, COL_TEAM_MEMBERS)
                throw error
            }

    // -------------------------------------------------------------------------
    // 2. SEED INITIAL [DEMO] WORKSPACE RECORDS IF EMPTY
    // -------------------------------------------------------------------------

    suspend fun ensureDemoWorkspaceSeeded(userId: String): Result<Boolean> = runCatching {
        val existingColleges = try {
            db.collection(COL_COLLEGES)
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, COL_COLLEGES)
            throw e
        }

        if (existingColleges.isEmpty) {
            seedDemoDataBatch(userId)
            return@runCatching true
        }

        // Ensure Phase 2 collections are seeded if upgrading from Phase 1 workspace
        val existingQueue = try {
            db.collection(COL_SOURCE_QUEUE)
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, COL_SOURCE_QUEUE)
            throw e
        }

        if (existingQueue.isEmpty) {
            seedPhase2And3Collections(userId)
            seedPhase4CollectionsOnly(userId)
            return@runCatching true
        }

        // Ensure Phase 3 collections are seeded if upgrading from Phase 2 workspace
        val existingPlacements = try {
            db.collection(COL_PLACEMENTS)
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, COL_PLACEMENTS)
            throw e
        }

        if (existingPlacements.isEmpty) {
            seedPhase3CollectionsOnly(userId)
            seedPhase4CollectionsOnly(userId)
            return@runCatching true
        }

        // Ensure Phase 4 collections are seeded if upgrading from Phase 3 workspace
        val existingDeadlines = try {
            db.collection(COL_ADMISSION_DEADLINES)
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, COL_ADMISSION_DEADLINES)
            throw e
        }

        if (existingDeadlines.isEmpty) {
            seedPhase4CollectionsOnly(userId)
            return@runCatching true
        }

        false
    }

    suspend fun seedDemoDataBatch(userId: String) {
        val suffix = userId.take(8).replace(Regex("[^a-zA-Z0-9_\\-]"), "u")
        val batch = db.batch()

        val colleges = DemoSeedData.buildDemoColleges(userId)
        val courses = DemoSeedData.buildDemoCourses(userId)
        val feeDocs = DemoSeedData.buildDemoFeeDocuments(userId)
        val enquiries = DemoSeedData.buildDemoEnquiries(userId)
        val sourceQueue = DemoSeedData.buildDemoSourceQueue(userId)
        val auditLogs = DemoSeedData.buildDemoAuditLogs(userId)
        val briefings = DemoSeedData.buildDemoBriefingVersions(userId, colleges, courses, feeDocs, sourceQueue)
        val placements = DemoSeedData.buildDemoPlacements(userId)
        val reviews = DemoSeedData.buildDemoCollegeReviews(userId)
        val deadlines = DemoSeedData.buildDemoAdmissionDeadlines(userId)
        val tasks = DemoSeedData.buildDemoTeamTasks(userId)
        val members = DemoSeedData.buildDemoTeamMembers(userId)
        val (settingsBaseId, appSettings) = DemoSeedData.buildDefaultAppSettings(userId)

        for ((baseId, college) in colleges) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_COLLEGES).document(docId)
            batch.set(ref, college.copy(id = docId, userId = userId, createdAt = null, updatedAt = null))
        }

        for ((baseId, course) in courses) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${course.collegeId}_$suffix"
            val ref = db.collection(COL_COURSES).document(docId)
            batch.set(
                ref,
                course.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, feeDoc) in feeDocs) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${feeDoc.collegeId}_$suffix"
            val ref = db.collection(COL_FEE_DOCS).document(docId)
            batch.set(
                ref,
                feeDoc.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, enquiry) in enquiries) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_ENQUIRIES).document(docId)
            batch.set(ref, enquiry.copy(id = docId, userId = userId, createdAt = null, updatedAt = null))
        }

        for ((baseId, item) in sourceQueue) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${item.collegeId}_$suffix"
            val ref = db.collection(COL_SOURCE_QUEUE).document(docId)
            batch.set(
                ref,
                item.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, briefing) in briefings) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${briefing.collegeId}_$suffix"
            val ref = db.collection(COL_BRIEFING_VERSIONS).document(docId)
            batch.set(
                ref,
                briefing.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, auditLog) in auditLogs) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_AUDIT_LOGS).document(docId)
            batch.set(ref, auditLog.copy(id = docId, userId = userId, createdAt = null, updatedAt = null))
        }

        for ((baseId, placement) in placements) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${placement.collegeId}_$suffix"
            val ref = db.collection(COL_PLACEMENTS).document(docId)
            batch.set(
                ref,
                placement.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, review) in reviews) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${review.collegeId}_$suffix"
            val ref = db.collection(COL_COLLEGE_REVIEWS).document(docId)
            batch.set(
                ref,
                review.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, deadline) in deadlines) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${deadline.collegeId}_$suffix"
            val ref = db.collection(COL_ADMISSION_DEADLINES).document(docId)
            batch.set(
                ref,
                deadline.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, task) in tasks) {
            val docId = "${baseId}_$suffix"
            val mappedLinkedId = if (task.linkedRecordId.isNotBlank()) "${task.linkedRecordId}_$suffix" else ""
            val ref = db.collection(COL_TEAM_TASKS).document(docId)
            batch.set(
                ref,
                task.copy(
                    id = docId,
                    userId = userId,
                    linkedRecordId = mappedLinkedId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, member) in members) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_TEAM_MEMBERS).document(docId)
            batch.set(
                ref,
                member.copy(
                    id = docId,
                    userId = userId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        val settingsDocId = "${settingsBaseId}_$suffix"
        val settingsRef = db.collection(COL_APP_SETTINGS).document(settingsDocId)
        batch.set(
            settingsRef,
            appSettings.copy(id = settingsDocId, userId = userId, createdAt = null, updatedAt = null)
        )

        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "batch_seed_demo")
            throw e
        }
    }

    private suspend fun seedPhase2And3Collections(userId: String) {
        val suffix = userId.take(8).replace(Regex("[^a-zA-Z0-9_\\-]"), "u")
        val batch = db.batch()
        val colleges = DemoSeedData.buildDemoColleges(userId)
        val courses = DemoSeedData.buildDemoCourses(userId)
        val feeDocs = DemoSeedData.buildDemoFeeDocuments(userId)
        val sourceQueue = DemoSeedData.buildDemoSourceQueue(userId)
        val auditLogs = DemoSeedData.buildDemoAuditLogs(userId)
        val briefings = DemoSeedData.buildDemoBriefingVersions(userId, colleges, courses, feeDocs, sourceQueue)
        val placements = DemoSeedData.buildDemoPlacements(userId)
        val reviews = DemoSeedData.buildDemoCollegeReviews(userId)
        val (settingsBaseId, appSettings) = DemoSeedData.buildDefaultAppSettings(userId)

        for ((baseId, item) in sourceQueue) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${item.collegeId}_$suffix"
            val ref = db.collection(COL_SOURCE_QUEUE).document(docId)
            batch.set(
                ref,
                item.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, briefing) in briefings) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${briefing.collegeId}_$suffix"
            val ref = db.collection(COL_BRIEFING_VERSIONS).document(docId)
            batch.set(
                ref,
                briefing.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, auditLog) in auditLogs) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_AUDIT_LOGS).document(docId)
            batch.set(ref, auditLog.copy(id = docId, userId = userId, createdAt = null, updatedAt = null))
        }

        for ((baseId, placement) in placements) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${placement.collegeId}_$suffix"
            val ref = db.collection(COL_PLACEMENTS).document(docId)
            batch.set(
                ref,
                placement.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, review) in reviews) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${review.collegeId}_$suffix"
            val ref = db.collection(COL_COLLEGE_REVIEWS).document(docId)
            batch.set(
                ref,
                review.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        val settingsDocId = "${settingsBaseId}_$suffix"
        val settingsRef = db.collection(COL_APP_SETTINGS).document(settingsDocId)
        batch.set(
            settingsRef,
            appSettings.copy(id = settingsDocId, userId = userId, createdAt = null, updatedAt = null)
        )

        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "batch_seed_phase2_3")
            throw e
        }
    }

    private suspend fun seedPhase3CollectionsOnly(userId: String) {
        val suffix = userId.take(8).replace(Regex("[^a-zA-Z0-9_\\-]"), "u")
        val batch = db.batch()
        val placements = DemoSeedData.buildDemoPlacements(userId)
        val reviews = DemoSeedData.buildDemoCollegeReviews(userId)

        for ((baseId, placement) in placements) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${placement.collegeId}_$suffix"
            val ref = db.collection(COL_PLACEMENTS).document(docId)
            batch.set(
                ref,
                placement.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, review) in reviews) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${review.collegeId}_$suffix"
            val ref = db.collection(COL_COLLEGE_REVIEWS).document(docId)
            batch.set(
                ref,
                review.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "batch_seed_phase3")
            throw e
        }
    }

    private suspend fun seedPhase4CollectionsOnly(userId: String) {
        val suffix = userId.take(8).replace(Regex("[^a-zA-Z0-9_\\-]"), "u")
        val batch = db.batch()
        val deadlines = DemoSeedData.buildDemoAdmissionDeadlines(userId)
        val tasks = DemoSeedData.buildDemoTeamTasks(userId)
        val members = DemoSeedData.buildDemoTeamMembers(userId)
        val enquiries = DemoSeedData.buildDemoEnquiries(userId)

        // Seed only new enquiries 4..6 so existing user-edited enquiries 1..3 aren't overwritten
        for ((baseId, enquiry) in enquiries.filter { it.first in listOf("demo_enq_4", "demo_enq_5", "demo_enq_6") }) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_ENQUIRIES).document(docId)
            batch.set(ref, enquiry.copy(id = docId, userId = userId, createdAt = null, updatedAt = null))
        }

        for ((baseId, deadline) in deadlines) {
            val docId = "${baseId}_$suffix"
            val mappedCollegeId = "${deadline.collegeId}_$suffix"
            val ref = db.collection(COL_ADMISSION_DEADLINES).document(docId)
            batch.set(
                ref,
                deadline.copy(
                    id = docId,
                    userId = userId,
                    collegeId = mappedCollegeId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, task) in tasks) {
            val docId = "${baseId}_$suffix"
            val mappedLinkedId = if (task.linkedRecordId.isNotBlank()) "${task.linkedRecordId}_$suffix" else ""
            val ref = db.collection(COL_TEAM_TASKS).document(docId)
            batch.set(
                ref,
                task.copy(
                    id = docId,
                    userId = userId,
                    linkedRecordId = mappedLinkedId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        for ((baseId, member) in members) {
            val docId = "${baseId}_$suffix"
            val ref = db.collection(COL_TEAM_MEMBERS).document(docId)
            batch.set(
                ref,
                member.copy(
                    id = docId,
                    userId = userId,
                    createdAt = null,
                    updatedAt = null
                )
            )
        }

        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "batch_seed_phase4")
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 3. COLLEGE CRUD OPERATIONS
    // -------------------------------------------------------------------------

    suspend fun createCollege(college: College): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (college.id.isNotBlank()) {
            db.collection(COL_COLLEGES).document(college.id)
        } else {
            db.collection(COL_COLLEGES).document()
        }
        val payload = college.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateCollege(college: College): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(college.id.isNotBlank()) { "College ID must not be blank for update" }
        requireNotNull(college.createdAt) { "College createdAt must not be null for update" }
        val docRef = db.collection(COL_COLLEGES).document(college.id)
        try {
            docRef.set(college.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteCollege(collegeId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_COLLEGES).document(collegeId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun getCollegeById(collegeId: String): Result<College?> = runCatching {
        val docRef = db.collection(COL_COLLEGES).document(collegeId)
        try {
            docRef.get().await().toObject(College::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 4. COURSE CRUD OPERATIONS
    // -------------------------------------------------------------------------

    suspend fun createCourse(course: Course): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (course.id.isNotBlank()) {
            db.collection(COL_COURSES).document(course.id)
        } else {
            db.collection(COL_COURSES).document()
        }
        val payload = course.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateCourse(course: Course): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(course.id.isNotBlank()) { "Course ID must not be blank for update" }
        requireNotNull(course.createdAt) { "Course createdAt must not be null for update" }
        val docRef = db.collection(COL_COURSES).document(course.id)
        try {
            docRef.set(course.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteCourse(courseId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_COURSES).document(courseId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 5. FEE DOCUMENT CRUD OPERATIONS
    // -------------------------------------------------------------------------

    suspend fun createFeeDocument(feeDoc: FeeDocument): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (feeDoc.id.isNotBlank()) {
            db.collection(COL_FEE_DOCS).document(feeDoc.id)
        } else {
            db.collection(COL_FEE_DOCS).document()
        }
        val payload = feeDoc.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateFeeDocument(feeDoc: FeeDocument): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(feeDoc.id.isNotBlank()) { "FeeDocument ID must not be blank for update" }
        requireNotNull(feeDoc.createdAt) { "FeeDocument createdAt must not be null for update" }
        val docRef = db.collection(COL_FEE_DOCS).document(feeDoc.id)
        try {
            docRef.set(feeDoc.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteFeeDocument(docId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_FEE_DOCS).document(docId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 6. STUDENT ENQUIRY CRUD OPERATIONS
    // -------------------------------------------------------------------------

    suspend fun createEnquiry(enquiry: StudentEnquiry): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (enquiry.id.isNotBlank()) {
            db.collection(COL_ENQUIRIES).document(enquiry.id)
        } else {
            db.collection(COL_ENQUIRIES).document()
        }
        val payload = enquiry.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateEnquiry(enquiry: StudentEnquiry): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(enquiry.id.isNotBlank()) { "Enquiry ID must not be blank for update" }
        requireNotNull(enquiry.createdAt) { "Enquiry createdAt must not be null for update" }
        val docRef = db.collection(COL_ENQUIRIES).document(enquiry.id)
        try {
            docRef.set(enquiry.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteEnquiry(enquiryId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_ENQUIRIES).document(enquiryId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 7. SOURCE VERIFICATION QUEUE CRUD OPERATIONS (MODULES 3 & 15)
    // -------------------------------------------------------------------------

    suspend fun createSourceQueueItem(item: SourceVerificationItem): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (item.id.isNotBlank()) {
            db.collection(COL_SOURCE_QUEUE).document(item.id)
        } else {
            db.collection(COL_SOURCE_QUEUE).document()
        }
        val payload = item.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateSourceQueueItem(item: SourceVerificationItem): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(item.id.isNotBlank()) { "SourceVerificationItem ID must not be blank for update" }
        requireNotNull(item.createdAt) { "SourceVerificationItem createdAt must not be null for update" }
        val docRef = db.collection(COL_SOURCE_QUEUE).document(item.id)
        try {
            docRef.set(item.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 8. 20-POINT AI BRIEFING VERSION CRUD OPERATIONS (MODULE 10)
    // -------------------------------------------------------------------------

    suspend fun saveBriefingVersion(version: CollegeBriefingVersion): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (version.id.isNotBlank()) {
            db.collection(COL_BRIEFING_VERSIONS).document(version.id)
        } else {
            db.collection(COL_BRIEFING_VERSIONS).document()
        }
        val payload = version.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 9. IMMUTABLE AUDIT LOGS & APP SETTINGS (MODULE 16)
    // -------------------------------------------------------------------------

    suspend fun createAuditLog(entry: AuditLogEntry): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (entry.id.isNotBlank()) {
            db.collection(COL_AUDIT_LOGS).document(entry.id)
        } else {
            db.collection(COL_AUDIT_LOGS).document()
        }
        val payload = entry.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun createAppSettings(settings: AppSettingsRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (settings.id.isNotBlank()) {
            db.collection(COL_APP_SETTINGS).document(settings.id)
        } else {
            db.collection(COL_APP_SETTINGS).document()
        }
        val payload = settings.copy(
            id = docRef.id,
            userId = uid,
            enquiryHeader = AppSettingsRecord.MANDATORY_ENQUIRY_HEADER,
            enquiryPhone = AppSettingsRecord.MANDATORY_ENQUIRY_PHONE,
            isLocked = true,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 10. PLACEMENTS & CAREER OUTCOMES CRUD OPERATIONS (MODULE 6)
    // -------------------------------------------------------------------------

    suspend fun createPlacementRecord(record: PlacementRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (record.id.isNotBlank()) {
            db.collection(COL_PLACEMENTS).document(record.id)
        } else {
            db.collection(COL_PLACEMENTS).document()
        }
        val payload = record.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updatePlacementRecord(record: PlacementRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(record.id.isNotBlank()) { "PlacementRecord ID must not be blank for update" }
        requireNotNull(record.createdAt) { "PlacementRecord createdAt must not be null for update" }
        val docRef = db.collection(COL_PLACEMENTS).document(record.id)
        try {
            docRef.set(record.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 11. COLLEGE REVIEWS & 7-DIMENSION QUALITY CRUD OPERATIONS (MODULE 7)
    // -------------------------------------------------------------------------

    suspend fun createCollegeReviewRecord(record: CollegeReviewRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (record.id.isNotBlank()) {
            db.collection(COL_COLLEGE_REVIEWS).document(record.id)
        } else {
            db.collection(COL_COLLEGE_REVIEWS).document()
        }
        val payload = record.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 12. ADMISSION DEADLINES & CALENDAR ALERTS CRUD OPERATIONS (MODULE 8)
    // -------------------------------------------------------------------------

    suspend fun createAdmissionDeadline(record: AdmissionDeadlineRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (record.id.isNotBlank()) {
            db.collection(COL_ADMISSION_DEADLINES).document(record.id)
        } else {
            db.collection(COL_ADMISSION_DEADLINES).document()
        }
        val payload = record.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateAdmissionDeadline(record: AdmissionDeadlineRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(record.id.isNotBlank()) { "AdmissionDeadlineRecord ID must not be blank for update" }
        requireNotNull(record.createdAt) { "AdmissionDeadlineRecord createdAt must not be null for update" }
        val docRef = db.collection(COL_ADMISSION_DEADLINES).document(record.id)
        try {
            docRef.set(record.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteAdmissionDeadline(deadlineId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_ADMISSION_DEADLINES).document(deadlineId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 13. TEAM TASKS & FOLLOW-UPS CRUD OPERATIONS (MODULE 12)
    // -------------------------------------------------------------------------

    suspend fun createTeamTask(task: TeamTaskRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (task.id.isNotBlank()) {
            db.collection(COL_TEAM_TASKS).document(task.id)
        } else {
            db.collection(COL_TEAM_TASKS).document()
        }
        val payload = task.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateTeamTask(task: TeamTaskRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(task.id.isNotBlank()) { "TeamTaskRecord ID must not be blank for update" }
        requireNotNull(task.createdAt) { "TeamTaskRecord createdAt must not be null for update" }
        val docRef = db.collection(COL_TEAM_TASKS).document(task.id)
        try {
            docRef.set(task.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteTeamTask(taskId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_TEAM_TASKS).document(taskId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // -------------------------------------------------------------------------
    // 14. TEAM MEMBERS & RBAC DIRECTORY CRUD OPERATIONS (MODULE 14)
    // -------------------------------------------------------------------------

    suspend fun createTeamMember(member: TeamMemberRecord): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = if (member.id.isNotBlank()) {
            db.collection(COL_TEAM_MEMBERS).document(member.id)
        } else {
            db.collection(COL_TEAM_MEMBERS).document()
        }
        val payload = member.copy(
            id = docRef.id,
            userId = uid,
            createdAt = null,
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateTeamMember(member: TeamMemberRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(member.id.isNotBlank()) { "TeamMemberRecord ID must not be blank for update" }
        requireNotNull(member.createdAt) { "TeamMemberRecord createdAt must not be null for update" }
        val docRef = db.collection(COL_TEAM_MEMBERS).document(member.id)
        try {
            docRef.set(member.copy(userId = uid, updatedAt = null)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteTeamMember(memberId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(COL_TEAM_MEMBERS).document(memberId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    companion object {
        const val COL_COLLEGES = "colleges"
        const val COL_COURSES = "courses"
        const val COL_FEE_DOCS = "fee_documents"
        const val COL_ENQUIRIES = "enquiries"
        const val COL_SOURCE_QUEUE = "source_queue"
        const val COL_BRIEFING_VERSIONS = "college_briefing_versions"
        const val COL_AUDIT_LOGS = "audit_logs"
        const val COL_APP_SETTINGS = "app_settings"
        const val COL_PLACEMENTS = "placements"
        const val COL_COLLEGE_REVIEWS = "college_reviews"
        const val COL_ADMISSION_DEADLINES = "admission_deadlines"
        const val COL_TEAM_TASKS = "team_tasks"
        const val COL_TEAM_MEMBERS = "team_members"
    }
}
