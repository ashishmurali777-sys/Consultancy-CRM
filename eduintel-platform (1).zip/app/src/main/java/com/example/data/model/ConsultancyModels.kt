package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * 6 RBAC Roles enforced across UI and service operations
 */
enum class ConsultancyRole(
    val label: String,
    val badgeCode: String,
    val description: String,
    val canManageColleges: Boolean,
    val canVerifyRegulatory: Boolean,
    val canReviewFees: Boolean,
    val canRunOcr: Boolean,
    val canManageEnquiries: Boolean,
    val canDeleteRecords: Boolean
) {
    ADMIN(
        label = "Admin",
        badgeCode = "ADM",
        description = "Full system control, schema audit, role governance, and record deletion",
        canManageColleges = true,
        canVerifyRegulatory = true,
        canReviewFees = true,
        canRunOcr = true,
        canManageEnquiries = true,
        canDeleteRecords = true
    ),
    SENIOR_REVIEWER(
        label = "Senior Reviewer",
        badgeCode = "SRV",
        description = "Approves source queue items, regulatory verifications, fee discrepancies, and briefings",
        canManageColleges = true,
        canVerifyRegulatory = true,
        canReviewFees = true,
        canRunOcr = true,
        canManageEnquiries = true,
        canDeleteRecords = false
    ),
    FEE_REVIEWER(
        label = "Fee Reviewer",
        badgeCode = "FRV",
        description = "Extracts fee structures via Gemini OCR and audits quota-wise discrepancies",
        canManageColleges = false,
        canVerifyRegulatory = false,
        canReviewFees = true,
        canRunOcr = true,
        canManageEnquiries = false,
        canDeleteRecords = false
    ),
    RESEARCHER(
        label = "Researcher",
        badgeCode = "RSH",
        description = "Runs live internet grounding, queues source diffs, and edits colleges/courses/placements/reviews",
        canManageColleges = true,
        canVerifyRegulatory = false,
        canReviewFees = false,
        canRunOcr = true,
        canManageEnquiries = false,
        canDeleteRecords = false
    ),
    COUNSELLOR(
        label = "Counselor",
        badgeCode = "CNS",
        description = "Read-only access to College & Fee modules; views verified briefings, fee comparisons, and student counselling data",
        canManageColleges = false,
        canVerifyRegulatory = false,
        canReviewFees = false,
        canRunOcr = false,
        canManageEnquiries = true,
        canDeleteRecords = false
    ),
    READ_ONLY_VIEWER(
        label = "Read-only Viewer",
        badgeCode = "ROV",
        description = "Read-only inspection of colleges, courses, fees, placements, reviews, briefings, and analytics",
        canManageColleges = false,
        canVerifyRegulatory = false,
        canReviewFees = false,
        canRunOcr = false,
        canManageEnquiries = false,
        canDeleteRecords = false
    )
}

/**
 * All 17 Enterprise Modules in Navigation Shell
 */
enum class ConsultancyModule(
    val routeId: String,
    val number: Int,
    val title: String,
    val shortTitle: String,
    val category: String,
    val subtitle: String
) {
    OPERATIONAL_DASHBOARD(
        "operational_dashboard", 1, "Operational Dashboard", "Dashboard",
        "CORE INTELLIGENCE", "Live KPIs, discrepancy alerts & counselling command center"
    ),
    COLLEGE_INTELLIGENCE_DB(
        "college_intelligence_db", 2, "College Intelligence DB", "Colleges",
        "CORE INTELLIGENCE", "Indian institutions, ownership, degree-awarding university & accreditations"
    ),
    LIVE_RESEARCH_ENGINE(
        "live_research_engine", 3, "Live Internet Research Engine", "Live Research",
        "CORE INTELLIGENCE", "Gemini Google Search grounding, official domain citations & side-by-side diff engine"
    ),
    COURSE_CATALOG_MATRIX(
        "course_catalog_matrix", 4, "Course & Intake Management", "Courses",
        "CORE INTELLIGENCE", "Supabase courses table, college mapping, duration in years & seat quota types (Merit, Management, NRI)"
    ),
    FEE_OCR_VERIFICATION_LAB(
        "fee_ocr_verification_lab", 5, "Gemini Fee OCR & Audit Lab", "Fee OCR",
        "VERIFICATION & OUTCOMES", "Multimodal fee extraction, quota matrix & discrepancy resolution"
    ),
    PLACEMENT_CAREER_OUTCOMES(
        "placement_career_outcomes", 6, "Placements & Career Outcomes", "Placements",
        "VERIFICATION & OUTCOMES", "Multi-year CTC analytics, UG/PG & Domestic/International classification safeguards"
    ),
    COLLEGE_REVIEWS_ANALYSIS(
        "college_reviews_analysis", 7, "College Reviews & Quality Analysis", "Reviews",
        "VERIFICATION & OUTCOMES", "Public third-party reviews vs internal consultancy observations & 7-dimension AI theme summarizer"
    ),
    REGULATORY_APPROVAL_TRACKER(
        "regulatory_approval_tracker", 8, "Admission Calendar & Deadlines", "Calendar (M8)",
        "ADMISSIONS & BRIEFINGS", "Course/quota deadlines, counselling rounds, conflict alerts, 1-click task reminders & regulatory registry"
    ),
    COLLEGE_COMPARISON_ENGINE(
        "college_comparison_engine", 9, "College Comparison Engine", "Compare (2-5)",
        "ADMISSIONS & BRIEFINGS", "Side-by-side 2-to-5 college comparator, quota/year normalizer & weighted suitability calculator"
    ),
    AI_COLLEGE_BRIEFINGS(
        "ai_college_briefings", 10, "20-Point AI College Briefings", "AI Briefings",
        "ADMISSIONS & BRIEFINGS", "20-section verified intelligence dossier, clinical metrics & version history"
    ),
    STUDENT_ENQUIRY_CRM(
        "student_enquiry_crm", 11, "Students / Leads (Admissions CRM)", "Students/Leads",
        "ADMISSIONS & BRIEFINGS", "Supabase students table, + Add Student lead intake, college/course mapping & lead status pipeline"
    ),
    ALLIED_HEALTH_COUNCIL_DESK(
        "allied_health_council_desk", 12, "Tasks (Task Management)", "Tasks",
        "GOVERNANCE & OPS", "Supabase tasks table, + Add Task modal, due dates, status & associated student mapping"
    ),
    CONSULTANCY_EXPORT_REPORTS(
        "consultancy_export_reports", 13, "Reports & Exports (PDF/CSV)", "Reports",
        "GOVERNANCE & OPS", "Printable PDF briefings, comparison sheets, student shortlists & bank loan fee quotations"
    ),
    QUOTA_FEE_COMPARATOR(
        "quota_fee_comparator", 14, "Team Management & Fee Matrix", "Team & RBAC",
        "GOVERNANCE & OPS", "Admin team directory, 6-role assignment, account controls & quota fee discrepancy desk"
    ),
    SOURCE_VERIFICATION_QUEUE(
        "source_verification_queue", 15, "Source & Verification Queue", "Source Queue",
        "GOVERNANCE & OPS", "Human-in-the-loop diff approval queue for live web research findings"
    ),
    SQL_FIRESTORE_SYNC_CENTER(
        "sql_firestore_sync_center", 16, "Sync, Audit Log & App Settings", "Sync & Audit",
        "SYSTEM & ARCHITECTURE", "Live Firestore sync across 13 collections, immutable audit trail & locked enquiry footer"
    ),
    RBAC_SECURITY_GOVERNANCE(
        "rbac_security_governance", 17, "Settings & Integrations", "Settings & Integrations",
        "SYSTEM & ARCHITECTURE", "Supabase Connection (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY), 6-tier RBAC & 18-Point Test Suite"
    );

    companion object {
        val ADMISSION_CALENDAR_DEADLINES = REGULATORY_APPROVAL_TRACKER
        val TEAM_TASKS_FOLLOW_UPS = ALLIED_HEALTH_COUNCIL_DESK
        val TEAM_MANAGEMENT = QUOTA_FEE_COMPARATOR
        val AI_WEB_EVIDENCE_GROUNDING = LIVE_RESEARCH_ENGINE
        val STALE_RECORDS_REFRESH_QUEUE = SOURCE_VERIFICATION_QUEUE
        val COUNSELLING_DEADLINE_CALENDAR = REGULATORY_APPROVAL_TRACKER
        val REPORTS_AND_EXPORTS = CONSULTANCY_EXPORT_REPORTS
        val DISCREPANCY_RESOLUTION_DESK = QUOTA_FEE_COMPARATOR
        val ENTRANCE_EXAM_CUTOFF_HUB = REGULATORY_APPROVAL_TRACKER
        val AUTONOMOUS_VS_DEGREE_AUDITOR = ALLIED_HEALTH_COUNCIL_DESK
    }
}

@IgnoreExtraProperties
data class College(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val shortCode: String = "",
    val state: String = "",
    val city: String = "",
    val ownership: String = "Private Unaided",
    val institutionType: String = "Autonomous College",
    val degreeAwardingUniversity: String = "",
    val affiliatedTo: String = "",
    val establishedYear: Long = 2000L,
    val websiteUrl: String = "",
    val verificationStatus: String = "Verified",
    val naacGrade: String = "A+",
    val naacCgpa: Double = 3.4,
    val nirfRank: Long = 0L,
    val regulators: List<String> = emptyList(),
    val regulatorDetailsSummary: String = "",
    val needsRefresh: Boolean = false,
    @get:PropertyName("isDemo") @set:PropertyName("isDemo")
    var isDemo: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Course(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseName: String = "",
    val degree: String = "UG",
    val specialization: String = "",
    val stream: String = "Medical",
    val durationYears: Double = 4.0,
    val seatQuotaType: String = "Merit",
    val intake: Long = 60L,
    val eligibility: String = "",
    val entranceExams: List<String> = emptyList(),
    @get:PropertyName("isLateralEntry") @set:PropertyName("isLateralEntry")
    var isLateralEntry: Boolean = false,
    val annualTuitionMinInr: Long = 0L,
    val annualTuitionMaxInr: Long = 0L,
    val quotaFeesSummary: String = "",
    val regulatoryBody: String = "UGC",
    val approvalStatus: String = "Verified",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FeeDocument(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseName: String = "",
    val academicYear: String = "2026-27",
    val quotaCategory: String = "Government / Merit",
    val tuitionFeeAnnualInr: Long = 0L,
    val hostelAndMessAnnualInr: Long = 0L,
    val cautionDepositInr: Long = 0L,
    val otherChargesInr: Long = 0L,
    val extractedRawSummary: String = "",
    val webComparisonNotes: String = "",
    val hasDiscrepancy: Boolean = false,
    val discrepancyDetails: String = "",
    val reviewStatus: String = "Pending Review",
    val sourceTitle: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val totalFirstYearInr: Long
        get() = tuitionFeeAnnualInr + hostelAndMessAnnualInr + cautionDepositInr + otherChargesInr
}

/**
 * Per-college shortlist item inside a Student Profile (Module 11)
 */
data class ShortlistedCollegeItem(
    val collegeId: String,
    val collegeShortCode: String,
    val collegeName: String,
    val courseName: String,
    val quotaCategory: String,
    val annualFeeInr: Long,
    val totalEstimatedCourseFeeInr: Long,
    val applicationStatus: String // "Shortlisted", "Application Submitted", "Counselling Registered", "Offer Received", "Enrolled", "Rejected"
)

/**
 * Structured Student Profile Metadata (Module 11) serialized inside StudentEnquiry
 */
data class StudentProfileMetadata(
    val email: String = "candidate.admissions@eduintel.in",
    val marks10thPercent: Double = 91.4,
    val marks12thPercent: Double = 88.6,
    val graduationMarksPercent: Double = 0.0, // 0.0 if UG applicant
    val category: String = "General", // "General", "OBC-NCL", "SC", "ST", "EWS", "NRI"
    val specialization: String = "Core / General",
    val preferredStatesCities: String = "Karnataka (Bengaluru, Manipal), Tamil Nadu (Chennai)",
    val bankLoanNeeded: Boolean = false,
    val assignedCounsellor: String = "Ananya Rao (Senior Counsellor)",
    val privacyConsentTimestamp: String = "2026-10-15 11:20 IST (DPDP Act Verified)",
    val checkedDocuments: List<String> = listOf("10th/12th Marks Card", "ID Proof"),
    val callNotesLog: List<String> = emptyList(),
    val summaryNotes: String = ""
)

@IgnoreExtraProperties
data class StudentEnquiry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val studentName: String = "",
    val phone: String = "",
    val email: String = "",
    val targetCollegeId: String = "",
    val targetCollegeName: String = "",
    val interestedCourseId: String = "",
    val targetStream: String = "",
    val preferredCourse: String = "",
    val preferredColleges: String = "",
    val leadStatus: String = "New",
    val entranceExamScore: String = "",
    val budgetMaxLakhs: Double = 15.0,
    val quotaPreference: String = "Merit / Govt",
    val stage: String = "New",
    val followUpDueToday: Boolean = true,
    val deadlineDate: String = "2026-11-15",
    val counsellorNotes: String = "",
    val assignedToRole: String = "Counselor",
    val assignedToName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun isVisibleForRole(role: ConsultancyRole): Boolean {
        return when (role) {
            ConsultancyRole.ADMIN,
            ConsultancyRole.SENIOR_REVIEWER -> true
            ConsultancyRole.COUNSELLOR -> {
                val roleStr = assignedToRole.trim()
                val nameStr = assignedToName.trim().ifBlank { parseProfileMetadata().assignedCounsellor.trim() }
                val notesStr = counsellorNotes.trim()
                val explicitlyOtherRole =
                    roleStr.equals("Admin", ignoreCase = true) ||
                    roleStr.equals("Senior Reviewer", ignoreCase = true) ||
                    roleStr.equals("Fee Reviewer", ignoreCase = true) ||
                    roleStr.equals("Researcher", ignoreCase = true) ||
                    nameStr.contains("[Admin Only]", ignoreCase = true) ||
                    notesStr.contains("[Admin Only]", ignoreCase = true) ||
                    notesStr.contains("[Restricted]", ignoreCase = true)
                !explicitlyOtherRole && (
                    roleStr.isBlank() ||
                    roleStr.equals("Counselor", ignoreCase = true) ||
                    roleStr.equals("Counsellor", ignoreCase = true) ||
                    nameStr.isBlank() ||
                    nameStr.contains("Counselor", ignoreCase = true) ||
                    nameStr.contains("Counsellor", ignoreCase = true) ||
                    nameStr.contains("Admissions", ignoreCase = true) ||
                    nameStr.contains("Ananya", ignoreCase = true)
                )
            }
            else -> {
                val roleStr = assignedToRole.trim()
                roleStr.isBlank() ||
                    roleStr.equals("Counselor", ignoreCase = true) ||
                    roleStr.equals(role.label, ignoreCase = true)
            }
        }
    }

    @Exclude
    fun displayLeadStatus(): String {
        val raw = leadStatus.ifBlank { stage }.trim()
        return when {
            raw.equals("New", ignoreCase = true) || raw.equals("New Enquiry", ignoreCase = true) -> "New"
            raw.equals("Contacted", ignoreCase = true) -> "Contacted"
            raw.equals("Application Submitted", ignoreCase = true) || raw.equals("Applied", ignoreCase = true) -> "Application Submitted"
            raw.equals("Enrolled", ignoreCase = true) -> "Enrolled"
            raw.isNotBlank() -> raw
            else -> "New"
        }
    }

    @Exclude
    fun normalizedStage(): String = when (stage.ifBlank { leadStatus }) {
        "New" -> "New Enquiry"
        "Shortlisting" -> "Shortlisted"
        "Document Verification" -> "Counselling"
        "Counselling Applied", "Application Submitted" -> "Applied"
        "Seat Allotted" -> "Offer Received"
        else -> stage.ifBlank { "New Enquiry" }
    }

    @Exclude
    fun parseProfileMetadata(): StudentProfileMetadata {
        val fallbackEmail = email.ifBlank {
            "${studentName.lowercase(Locale.US).replace(" ", ".").take(18)}@student.in"
        }
        if (!counsellorNotes.trimStart().startsWith("{")) {
            return StudentProfileMetadata(
                email = fallbackEmail,
                marks10thPercent = 90.0,
                marks12thPercent = if (targetStream.contains("Medical", true)) 89.5 else 86.0,
                graduationMarksPercent = if (preferredCourse.startsWith("M", true)) 78.5 else 0.0,
                category = if (quotaPreference.contains("NRI", true)) "NRI" else "General",
                specialization = if (preferredCourse.contains("CSE", true)) "Computer Science & AI" else "Core Clinical / Honours",
                preferredStatesCities = "Karnataka (Bengaluru, Manipal), Kerala, Tamil Nadu",
                bankLoanNeeded = budgetMaxLakhs >= 18.0,
                assignedCounsellor = "Ananya Rao (Senior Counsellor)",
                privacyConsentTimestamp = "2026-10-18 14:15 IST (Verified Consent)",
                checkedDocuments = listOf("10th/12th Marks Card", "ID Proof"),
                callNotesLog = if (counsellorNotes.isNotBlank()) listOf(counsellorNotes) else emptyList(),
                summaryNotes = counsellorNotes
            )
        }
        return try {
            val obj = JSONObject(counsellorNotes)
            val docsArr = obj.optJSONArray("checkedDocuments") ?: JSONArray()
            val docs = buildList {
                for (i in 0 until docsArr.length()) {
                    val d = docsArr.optString(i)
                    if (d.isNotBlank()) add(d)
                }
            }
            val logsArr = obj.optJSONArray("callNotesLog") ?: JSONArray()
            val logs = buildList {
                for (i in 0 until logsArr.length()) {
                    val l = logsArr.optString(i)
                    if (l.isNotBlank()) add(l)
                }
            }
            StudentProfileMetadata(
                email = email.ifBlank { obj.optString("email", fallbackEmail) },
                marks10thPercent = obj.optDouble("marks10thPercent", 90.0),
                marks12thPercent = obj.optDouble("marks12thPercent", 88.0),
                graduationMarksPercent = obj.optDouble("graduationMarksPercent", 0.0),
                category = obj.optString("category", "General"),
                specialization = obj.optString("specialization", "Core"),
                preferredStatesCities = obj.optString("preferredStatesCities", "Karnataka, Tamil Nadu"),
                bankLoanNeeded = obj.optBoolean("bankLoanNeeded", false),
                assignedCounsellor = obj.optString("assignedCounsellor", "Ananya Rao"),
                privacyConsentTimestamp = obj.optString("privacyConsentTimestamp", "2026-10-20 10:00 IST"),
                checkedDocuments = docs,
                callNotesLog = logs,
                summaryNotes = obj.optString("summaryNotes", "")
            )
        } catch (_: Exception) {
            StudentProfileMetadata(email = fallbackEmail, summaryNotes = counsellorNotes)
        }
    }

    @Exclude
    fun parseShortlistedColleges(): List<ShortlistedCollegeItem> {
        if (!preferredColleges.trimStart().startsWith("[")) {
            val rawColleges = preferredColleges.ifBlank { targetCollegeName }
            if (rawColleges.isBlank()) return emptyList()
            return rawColleges.split(",").mapNotNull { token ->
                val clean = token.trim()
                if (clean.isBlank()) null
                else ShortlistedCollegeItem(
                    collegeId = targetCollegeId.ifBlank {
                        "col_${clean.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "_").take(12)}"
                    },
                    collegeShortCode = clean,
                    collegeName = clean,
                    courseName = preferredCourse,
                    quotaCategory = quotaPreference,
                    annualFeeInr = ((budgetMaxLakhs * 100000.0) / 4.0).toLong(),
                    totalEstimatedCourseFeeInr = (budgetMaxLakhs * 100000.0).toLong(),
                    applicationStatus = when (normalizedStage()) {
                        "Applied" -> "Application Submitted"
                        "Offer Received" -> "Offer Received"
                        "Enrolled" -> "Enrolled"
                        else -> "Shortlisted"
                    }
                )
            }
        }
        return try {
            val arr = JSONArray(preferredColleges)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    add(
                        ShortlistedCollegeItem(
                            collegeId = o.optString("collegeId", ""),
                            collegeShortCode = o.optString("collegeShortCode", ""),
                            collegeName = o.optString("collegeName", ""),
                            courseName = o.optString("courseName", preferredCourse),
                            quotaCategory = o.optString("quotaCategory", quotaPreference),
                            annualFeeInr = o.optLong("annualFeeInr", 250000L),
                            totalEstimatedCourseFeeInr = o.optLong("totalEstimatedCourseFeeInr", 1000000L),
                            applicationStatus = o.optString("applicationStatus", "Shortlisted")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Exclude
    fun displayShortlistedSummary(): String {
        val list = parseShortlistedColleges()
        return if (list.isEmpty()) targetCollegeName.ifBlank { "None shortlisted yet" }
        else list.joinToString(", ") { "${it.collegeShortCode} (${it.applicationStatus})" }
    }

    companion object {
        val LEAD_STATUS_OPTIONS = listOf(
            "New",
            "Contacted",
            "Application Submitted",
            "Enrolled"
        )

        val CRM_PIPELINE_STAGES = listOf(
            "New Enquiry",
            "Contacted",
            "Counselling",
            "Shortlisted",
            "Applied",
            "Offer Received",
            "Enrolled",
            "Unsuccessful",
            "Withdrawn"
        )

        val REQUIRED_ADMISSION_DOCUMENTS = listOf(
            "10th/12th Marks Card",
            "Transfer Certificate",
            "Migration Certificate",
            "Allotment Letter",
            "ID Proof"
        )

        fun encodeProfileMetadata(meta: StudentProfileMetadata): String {
            val obj = JSONObject()
            obj.put("email", meta.email)
            obj.put("marks10thPercent", meta.marks10thPercent)
            obj.put("marks12thPercent", meta.marks12thPercent)
            obj.put("graduationMarksPercent", meta.graduationMarksPercent)
            obj.put("category", meta.category)
            obj.put("specialization", meta.specialization)
            obj.put("preferredStatesCities", meta.preferredStatesCities)
            obj.put("bankLoanNeeded", meta.bankLoanNeeded)
            obj.put("assignedCounsellor", meta.assignedCounsellor)
            obj.put("privacyConsentTimestamp", meta.privacyConsentTimestamp)
            val docsArr = JSONArray()
            meta.checkedDocuments.forEach { docsArr.put(it) }
            obj.put("checkedDocuments", docsArr)
            val logsArr = JSONArray()
            meta.callNotesLog.forEach { logsArr.put(it) }
            obj.put("callNotesLog", logsArr)
            obj.put("summaryNotes", meta.summaryNotes)
            return obj.toString().take(7900)
        }

        fun encodeShortlistedColleges(items: List<ShortlistedCollegeItem>): String {
            val arr = JSONArray()
            items.forEach { item ->
                val o = JSONObject()
                o.put("collegeId", item.collegeId)
                o.put("collegeShortCode", item.collegeShortCode)
                o.put("collegeName", item.collegeName)
                o.put("courseName", item.courseName)
                o.put("quotaCategory", item.quotaCategory)
                o.put("annualFeeInr", item.annualFeeInr)
                o.put("totalEstimatedCourseFeeInr", item.totalEstimatedCourseFeeInr)
                o.put("applicationStatus", item.applicationStatus)
                arr.put(o)
            }
            return arr.toString().take(3900)
        }
    }
}

/**
 * Module 11: Automated Eligibility & Budget Match Result for a Student Profile
 */
data class MatchedCollegeEligibilityResult(
    val college: College,
    val course: Course,
    val matchedFeeDoc: FeeDocument?,
    val effectiveAnnualFeeInr: Long,
    val totalCourseBudgetInr: Long,
    val studentBudgetInr: Long,
    val isWithinBudget: Boolean,
    val minimumRequiredMarksPercent: Double,
    val meetsMarksEligibility: Boolean,
    val entranceExamMatched: Boolean,
    val matchScorePercent: Int,
    val matchExplanation: String
)

/**
 * Module 8: Admission Calendar, Deadlines & Alerts Record
 * Stored in `/admission_deadlines/{deadlineId}`
 */
@IgnoreExtraProperties
data class AdmissionDeadlineRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseName: String = "",
    val quotaCategory: String = "All India / Merit",
    val academicYear: String = "2026-27",
    val applicationOpenDate: String = "2026-03-01",
    val applicationDeadline: String = "2026-05-15",
    val entranceExamDate: String = "2026-05-03 (NEET-UG)",
    val counsellingRound1Date: String = "2026-07-18",
    val counsellingRound2Date: String = "2026-08-12",
    val mopUpStrayRoundDate: String = "2026-09-08",
    val documentVerificationDeadline: String = "2026-07-24",
    val scholarshipDeadline: String = "2026-08-30",
    val feePaymentWindow: String = "2026-07-20 to 2026-07-28",
    val sourceUrl: String = "https://mcc.nic.in",
    val retrievalDate: String = "2026-10-28",
    val verificationStatus: String = "Verified",
    val hasConflict: Boolean = false,
    val conflictDetails: String = "",
    @get:PropertyName("isOverdueRefresh") @set:PropertyName("isOverdueRefresh")
    var isOverdueRefresh: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

/**
 * Module 12: Collaborative Team Task & Follow-up Record
 * Synced with Supabase `tasks` table and `/team_tasks/{taskId}`
 */
@IgnoreExtraProperties
data class TeamTaskRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val taskDescription: String = "",
    val taskType: String = "Student Follow-up", // "Research Job", "Fee Document Review", "Discrepancy Resolution", "Student Counselling Follow-up"
    val assignedToName: String = "",
    val assignedToRole: String = "Counselor",
    val priority: String = "High", // "Low", "Medium", "High", "Urgent"
    val dueDate: String = "2026-11-15",
    val linkedRecordType: String = "Student", // "College", "Fee Doc", "Student", "Deadline"
    val linkedRecordId: String = "",
    val linkedRecordName: String = "",
    val associatedStudentId: String = "",
    val associatedStudentName: String = "",
    val status: String = "Pending", // "Pending", "In Progress", "Completed"
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun displayTaskDescription(): String =
        taskDescription.ifBlank { title.ifBlank { notes.ifBlank { "Task To-Do" } } }

    @Exclude
    fun displayAssociatedStudent(): String =
        associatedStudentName.ifBlank {
            linkedRecordName.ifBlank {
                associatedStudentId.ifBlank {
                    linkedRecordId.ifBlank { "Unassigned Student" }
                }
            }
        }

    @Exclude
    fun displayTaskStatus(): String = when {
        status.equals("Pending", ignoreCase = true) || status.equals("To Do", ignoreCase = true) -> "Pending"
        status.equals("In Progress", ignoreCase = true) -> "In Progress"
        status.equals("Completed", ignoreCase = true) || status.equals("Done", ignoreCase = true) -> "Completed"
        status.isNotBlank() -> status
        else -> "Pending"
    }

    @Exclude
    fun isPendingTask(): Boolean {
        val st = displayTaskStatus()
        return st.equals("Pending", ignoreCase = true)
    }

    @Exclude
    fun priorityRank(): Int = when {
        priority.equals("Urgent", ignoreCase = true) || priority.equals("Critical", ignoreCase = true) -> 0
        priority.equals("High", ignoreCase = true) -> 1
        priority.equals("Medium", ignoreCase = true) || priority.equals("Normal", ignoreCase = true) -> 2
        else -> 3
    }

    @Exclude
    fun isVisibleForRole(role: ConsultancyRole): Boolean {
        return when (role) {
            ConsultancyRole.ADMIN,
            ConsultancyRole.SENIOR_REVIEWER -> true
            ConsultancyRole.COUNSELLOR -> {
                val roleStr = assignedToRole.trim()
                val nameStr = assignedToName.trim()
                val descStr = displayTaskDescription()
                val explicitlyOtherRole =
                    roleStr.equals("Admin", ignoreCase = true) ||
                    roleStr.equals("Senior Reviewer", ignoreCase = true) ||
                    roleStr.equals("Fee Reviewer", ignoreCase = true) ||
                    roleStr.equals("Researcher", ignoreCase = true) ||
                    nameStr.contains("Admin", ignoreCase = true) ||
                    nameStr.contains("Reviewer", ignoreCase = true) ||
                    nameStr.contains("Researcher", ignoreCase = true) ||
                    descStr.contains("[Admin]", ignoreCase = true)
                !explicitlyOtherRole && (
                    roleStr.isBlank() ||
                    roleStr.equals("Counselor", ignoreCase = true) ||
                    roleStr.equals("Counsellor", ignoreCase = true) ||
                    nameStr.isBlank() ||
                    nameStr.contains("Counselor", ignoreCase = true) ||
                    nameStr.contains("Counsellor", ignoreCase = true) ||
                    nameStr.contains("Admissions", ignoreCase = true) ||
                    nameStr.contains("Ananya", ignoreCase = true)
                )
            }
            else -> {
                val roleStr = assignedToRole.trim()
                val nameStr = assignedToName.trim()
                roleStr.isBlank() ||
                    roleStr.equals(role.label, ignoreCase = true) ||
                    nameStr.contains(role.label, ignoreCase = true)
            }
        }
    }

    companion object {
        val TASK_STATUS_OPTIONS = listOf(
            "Pending",
            "In Progress",
            "Completed"
        )
    }
}

/**
 * Module 14: Team Member & Role Governance Record
 * Stored in `/team_members/{memberId}`
 */
@IgnoreExtraProperties
data class TeamMemberRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val roleName: String = "Counsellor", // "Admin", "Senior Reviewer", "Fee Reviewer", "Researcher", "Counsellor", "Read-only Viewer"
    val department: String = "Admissions & Counselling",
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true,
    val permissionsSummary: String = "",
    val lastActiveDisplay: String = "Online — Active Today",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

/**
 * Single Check Item in the 18-Point Acceptance Test Suite Diagnostic Runner
 */
data class AcceptanceTestResultItem(
    val checkNumber: Int,
    val category: String,
    val title: String,
    val verificationDetail: String,
    val passed: Boolean
)

/**
 * Module 3 & 15: Live Internet Research Grounding & Source Verification Queue Item
 * Stored in `/source_queue/{itemId}`
 */
@IgnoreExtraProperties
data class SourceVerificationItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseName: String = "All Programmes",
    val researchTarget: String = "Verify UGC/AICTE/NMC Status",
    val fieldKey: String = "regulatorDetailsSummary",
    val previousValue: String = "",
    val extractedValue: String = "",
    val sourceTitle: String = "",
    val sourceUrl: String = "Unable to verify online — manual document required",
    val sourceType: String = "Official Website",
    val academicYear: String = "2026-27",
    val confidenceScore: Long = 90L,
    val hasContradiction: Boolean = false,
    val contradictionNote: String = "",
    val verificationStatus: String = "Pending Verification",
    val retrievedAtIso: String = "2026-10-29 10:30 IST",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

/**
 * Single section inside the 20-Point AI College Briefing
 */
data class BriefingSectionItem(
    val sectionNumber: Int,
    val title: String,
    val content: String,
    val claimBadge: String, // "Verified Official", "College-Provided Unverified", "Third-Party", "Not Publicly Reported"
    val sourceCitation: String
)

/**
 * Module 10: 20-Point AI College Briefing Version Record
 * Stored in `/college_briefing_versions/{versionId}`
 */
@IgnoreExtraProperties
data class CollegeBriefingVersion(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseFocus: String = "",
    val versionNumber: Long = 1L,
    val versionLabel: String = "v1.0 — Initial Verified Synthesis",
    val editedByRole: String = "Senior Reviewer",
    val sectionsJson: String = "[]",
    val summaryHeadline: String = "",
    val clinicalExposureSummary: String = "",
    val enquiryFooterText: String = "ADMISSION ENQUIRIES\n+91 70122 74141",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun parseSections(): List<BriefingSectionItem> {
        return try {
            val arr = JSONArray(sectionsJson)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        BriefingSectionItem(
                            sectionNumber = obj.optInt("sectionNumber", i + 1),
                            title = obj.optString("title", "Section ${i + 1}"),
                            content = obj.optString("content", ""),
                            claimBadge = obj.optString("claimBadge", "Verified Official"),
                            sourceCitation = obj.optString("sourceCitation", "Stored Database Record")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        fun encodeSections(sections: List<BriefingSectionItem>): String {
            val arr = JSONArray()
            sections.sortedBy { it.sectionNumber }.forEach { item ->
                val obj = JSONObject()
                obj.put("sectionNumber", item.sectionNumber)
                obj.put("title", item.title)
                obj.put("content", item.content)
                obj.put("claimBadge", item.claimBadge)
                obj.put("sourceCitation", item.sourceCitation)
                arr.put(obj)
            }
            return arr.toString()
        }
    }
}

/**
 * Immutable Audit Log Record
 * Stored in `/audit_logs/{logId}`
 */
@IgnoreExtraProperties
data class AuditLogEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val actorRole: String = "Admin",
    val actionType: String = "SOURCE_VERIFIED",
    val targetModule: String = "Source & Verification Queue",
    val targetRecordName: String = "",
    val details: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

/**
 * Locked App Settings Record for Mandatory Admission Enquiry Contact Footer
 * Stored in `/app_settings/{settingId}`
 */
@IgnoreExtraProperties
data class AppSettingsRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val enquiryHeader: String = MANDATORY_ENQUIRY_HEADER,
    val enquiryPhone: String = MANDATORY_ENQUIRY_PHONE,
    @get:PropertyName("isLocked") @set:PropertyName("isLocked")
    var isLocked: Boolean = true,
    val organizationName: String = "Private Education Consultancy Intelligence Platform",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun formattedFooterBlock(): String = "$enquiryHeader\n$enquiryPhone"

    companion object {
        const val MANDATORY_ENQUIRY_HEADER = "ADMISSION ENQUIRIES"
        const val MANDATORY_ENQUIRY_PHONE = "+91 70122 74141"
        const val MANDATORY_FOOTER_BLOCK = "ADMISSION ENQUIRIES\n+91 70122 74141"
    }
}

/**
 * Module 6: Placement & Career Outcome Intelligence Record
 * Stored in `/placements/{placementId}`
 * Any numeric value < 0 (e.g., -1.0 or -1L) explicitly renders as "Not Publicly Reported" — never estimated.
 */
@IgnoreExtraProperties
data class PlacementRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseName: String = "",
    val specialization: String = "",
    val academicYear: String = "2025-26",
    val scopeType: String = "Course-Specific", // "Institution-Wide" or "Course-Specific"
    val levelType: String = "UG", // "UG" or "PG"
    val offerScope: String = "Domestic", // "Domestic" or "International"
    val highestPackageLpa: Double = -1.0,
    val averagePackageLpa: Double = -1.0,
    val medianPackageLpa: Double = -1.0,
    val placementRatePercent: Double = -1.0,
    val eligibleStudents: Long = -1L,
    val participatingStudents: Long = -1L,
    val placedStudents: Long = -1L,
    val totalRecruiters: Long = -1L,
    val internshipStipendMonthlyInr: Long = -1L,
    val topRecruiters: String = "Not Publicly Reported",
    val commonJobRoles: String = "Not Publicly Reported",
    val sourceCitation: String = "NIRF 2026 Submitted Data",
    val verificationStatus: String = "Verified",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun formatHighestLpa(): String =
        if (highestPackageLpa <= 0.0) "Not Publicly Reported"
        else String.format(Locale.US, "₹%.2f LPA (%s)", highestPackageLpa, offerScope)

    @Exclude
    fun formatAverageLpa(): String =
        if (averagePackageLpa <= 0.0) "Not Publicly Reported"
        else String.format(Locale.US, "₹%.2f LPA", averagePackageLpa)

    @Exclude
    fun formatMedianLpa(): String =
        if (medianPackageLpa <= 0.0) "Not Publicly Reported"
        else String.format(Locale.US, "₹%.2f LPA", medianPackageLpa)

    @Exclude
    fun formatPlacementRate(): String =
        if (placementRatePercent < 0.0) "Not Publicly Reported"
        else String.format(Locale.US, "%.1f%%", placementRatePercent)

    @Exclude
    fun formatCount(value: Long): String =
        if (value < 0L) "Not Publicly Reported" else value.toString()

    @Exclude
    fun formatStipend(): String =
        if (internshipStipendMonthlyInr < 0L) "Not Publicly Reported"
        else "₹${String.format(Locale.US, "%,d", internshipStipendMonthlyInr)}/mo"
}

/**
 * Module 7: Structured College Review & 7-Dimension Quality Analysis Record
 * Stored in `/college_reviews/{reviewId}`
 * Explicitly separates "Public Third-Party Review" from "Internal Consultancy Observation".
 */
@IgnoreExtraProperties
data class CollegeReviewRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val collegeId: String = "",
    val collegeName: String = "",
    val courseFocus: String = "All Programmes",
    val reviewCategory: String = "Public Third-Party Review", // "Public Third-Party Review" or "Internal Consultancy Observation"
    val sourceName: String = "",
    val overallRating: Double = 4.2,
    val reviewCount: Long = 10L,
    val retrievedDate: String = "2026-10-29",
    val positiveThemes: String = "",
    val negativeThemes: String = "",
    val recurringComplaints: String = "",
    val academicExperienceRating: Double = 4.2,
    val infrastructureLabsRating: Double = 4.3,
    val facultyQualityRating: Double = 4.1,
    val hostelMessRating: Double = 3.8,
    val placementSupportRating: Double = 4.0,
    val clinicalPracticalRating: Double = 4.4,
    val campusLifeSupportRating: Double = 4.1,
    val dimensionEvidenceSummary: String = "",
    @get:PropertyName("isContextualAiSummary") @set:PropertyName("isContextualAiSummary")
    var isContextualAiSummary: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @Exclude
    fun sevenDimensionList(): List<Pair<String, Double>> = listOf(
        "1. Academic Experience" to academicExperienceRating,
        "2. Infrastructure & Labs" to infrastructureLabsRating,
        "3. Faculty Quality" to facultyQualityRating,
        "4. Hostel & Mess Quality" to hostelMessRating,
        "5. Placement Support" to placementSupportRating,
        "6. Clinical / Practical Exposure" to clinicalPracticalRating,
        "7. Campus Life & Student Support" to campusLifeSupportRating
    )
}

/**
 * Structured output from Gemini 3.8 Flash AI Theme Summarizer in Module 7
 * Labeled strictly as Contextual Evidence Synthesis, never direct student quotes.
 */
data class AiReviewThemeSummaryResult(
    val collegeName: String,
    val courseFocus: String,
    val positiveThemes: String,
    val negativeThemes: String,
    val recurringComplaints: String,
    val academicExperienceRating: Double,
    val infrastructureLabsRating: Double,
    val facultyQualityRating: Double,
    val hostelMessRating: Double,
    val placementSupportRating: Double,
    val clinicalPracticalRating: Double,
    val campusLifeSupportRating: Double,
    val dimensionEvidenceSummary: String
)

/**
 * Module 9: Comparison Slot Selection (for 2 to 5 colleges)
 */
data class ComparisonSlot(
    val slotIndex: Int,
    val collegeId: String,
    val courseId: String,
    val selectedQuota: String, // "Government / Merit", "Management / Institutional", "COMEDK / Consortium", "NRI / Foreign"
    val selectedAcademicYear: String // "2026-27" or "2025-26"
)

/**
 * Module 9: Transparent Weighted Suitability Mathematical Breakdown
 */
data class WeightedCollegeScoreBreakdown(
    val collegeId: String,
    val collegeShortCode: String,
    val collegeName: String,
    val courseName: String,
    val selectedQuota: String,
    val feeSubScore: Double, // 0..100
    val placementRoiSubScore: Double, // 0..100
    val clinicalInfraSubScore: Double, // 0..100
    val regulatoryRankingSubScore: Double, // 0..100
    val feeWeightPercent: Double,
    val placementWeightPercent: Double,
    val clinicalWeightPercent: Double,
    val regulatoryWeightPercent: Double,
    val weightedFeeContribution: Double,
    val weightedPlacementContribution: Double,
    val weightedClinicalContribution: Double,
    val weightedRegulatoryContribution: Double,
    val finalSuitabilityScore: Double, // 0..100
    val formulaExplanation: String
)

/**
 * Structured OCR output from Gemini 3.8 Flash
 */
data class OcrFeeExtractionResult(
    val collegeName: String,
    val courseName: String,
    val academicYear: String,
    val quotaCategory: String,
    val tuitionFeeAnnualInr: Long,
    val hostelAndMessAnnualInr: Long,
    val cautionDepositInr: Long,
    val otherChargesInr: Long,
    val extractedRawSummary: String,
    val webComparisonNotes: String,
    val hasDiscrepancy: Boolean,
    val discrepancyDetails: String
)

/**
 * Live Internet Research result parsed from Gemini 3.8 Flash + Google Search Grounding
 */
data class LiveResearchGroundingResult(
    val collegeId: String,
    val collegeName: String,
    val courseName: String,
    val researchTarget: String,
    val fieldKey: String,
    val previousValue: String,
    val extractedValue: String,
    val sourceTitle: String,
    val sourceUrl: String,
    val sourceType: String,
    val academicYear: String,
    val confidenceScore: Long,
    val hasContradiction: Boolean,
    val contradictionNote: String,
    val retrievedAtIso: String,
    val allCitations: List<Pair<String, String>>, // title to url
    val webSearchQueries: List<String>
)

/**
 * Student Document Vault item stored in Supabase Storage bucket `student_documents`
 * at path `student_documents/{student_id}/{file_name}`
 */
data class StudentVaultDocument(
    val id: String,
    val studentId: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long = 0L,
    val bucketName: String = "student_documents",
    val objectPath: String, // "{student_id}/{file_name}"
    val storagePath: String, // "student_documents/{student_id}/{file_name}"
    val publicUrl: String, // "{supabaseUrl}/storage/v1/object/public/student_documents/{student_id}/{file_name}"
    val uploadedAt: String
)

