package com.example.data.seed

import com.example.data.model.AdmissionDeadlineRecord
import com.example.data.model.AppSettingsRecord
import com.example.data.model.AuditLogEntry
import com.example.data.model.BriefingSectionItem
import com.example.data.model.College
import com.example.data.model.CollegeBriefingVersion
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.PlacementRecord
import com.example.data.model.ShortlistedCollegeItem
import com.example.data.model.SourceVerificationItem
import com.example.data.model.StudentEnquiry
import com.example.data.model.StudentProfileMetadata
import com.example.data.model.TeamMemberRecord
import com.example.data.model.TeamTaskRecord

object DemoSeedData {

    fun buildDefaultAppSettings(userId: String): Pair<String, AppSettingsRecord> =
        "demo_app_settings" to AppSettingsRecord(
            id = "demo_app_settings",
            userId = userId,
            enquiryHeader = AppSettingsRecord.MANDATORY_ENQUIRY_HEADER,
            enquiryPhone = AppSettingsRecord.MANDATORY_ENQUIRY_PHONE,
            isLocked = true,
            organizationName = "Private Education Consultancy Intelligence Platform"
        )

    fun buildDemoColleges(userId: String): List<Pair<String, College>> = listOf(
        "demo_col_kmc" to College(
            id = "demo_col_kmc",
            userId = userId,
            name = "[DEMO] Kasturba Medical College (KMC) Manipal",
            shortCode = "KMC-MPL",
            state = "Karnataka",
            city = "Manipal",
            ownership = "Private Unaided",
            institutionType = "Deemed-to-be University",
            degreeAwardingUniversity = "Manipal Academy of Higher Education (MAHE)",
            affiliatedTo = "MAHE Constituent Unit",
            establishedYear = 1953L,
            websiteUrl = "https://manipal.edu/kmc-manipal.html",
            verificationStatus = "Verified",
            naacGrade = "A++",
            naacCgpa = 3.65,
            nirfRank = 9L,
            regulators = listOf("UGC", "NMC", "NAAC"),
            regulatorDetailsSummary = "NMC Recognized 250 MBBS seats (Ref: NMC/UG/2025/KMC); NAAC A++ (CGPA 3.65) valid till 2028; MCC Deemed Quota.",
            needsRefresh = false,
            isDemo = true
        ),
        "demo_col_rvce" to College(
            id = "demo_col_rvce",
            userId = userId,
            name = "[DEMO] R.V. College of Engineering (RVCE)",
            shortCode = "RVCE-BLR",
            state = "Karnataka",
            city = "Bengaluru",
            ownership = "Private Unaided",
            institutionType = "Autonomous College",
            degreeAwardingUniversity = "Visvesvaraya Technological University (VTU), Belagavi",
            affiliatedTo = "VTU Belagavi (Academic Autonomous, Degree by VTU)",
            establishedYear = 1963L,
            websiteUrl = "https://www.rvce.edu.in",
            verificationStatus = "Verified",
            naacGrade = "A+",
            naacCgpa = 3.46,
            nirfRank = 99L,
            regulators = listOf("UGC", "AICTE", "NBA", "NAAC"),
            regulatorDetailsSummary = "AICTE EoA 2026-27 Verified; Autonomous status under UGC till 2031; Degree strictly awarded by VTU Belagavi.",
            needsRefresh = false,
            isDemo = true
        ),
        "demo_col_stjohns" to College(
            id = "demo_col_stjohns",
            userId = userId,
            name = "[DEMO] St. John's National Academy of Health Sciences",
            shortCode = "SJMC-BLR",
            state = "Karnataka",
            city = "Bengaluru",
            ownership = "Private Unaided",
            institutionType = "Affiliated College",
            degreeAwardingUniversity = "Rajiv Gandhi University of Health Sciences (RGUHS), Karnataka",
            affiliatedTo = "RGUHS Bengaluru",
            establishedYear = 1963L,
            websiteUrl = "https://www.stjohns.in",
            verificationStatus = "Verified",
            naacGrade = "A+",
            naacCgpa = 3.48,
            nirfRank = 19L,
            regulators = listOf("NMC", "INC", "IAP", "NAAC"),
            regulatorDetailsSummary = "NMC 150 MBBS seats; INC & KNC approved B.Sc Nursing; RGUHS & IAP recognized BPT & MPT programs; KEA counselling.",
            needsRefresh = false,
            isDemo = true
        ),
        "demo_col_srm" to College(
            id = "demo_col_srm",
            userId = userId,
            name = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            shortCode = "SRM-KTR",
            state = "Tamil Nadu",
            city = "Chengalpattu (Chennai)",
            ownership = "Private Unaided",
            institutionType = "Deemed-to-be University",
            degreeAwardingUniversity = "SRM Institute of Science and Technology",
            affiliatedTo = "Self-Awarding Deemed University u/s 3 of UGC Act",
            establishedYear = 1985L,
            websiteUrl = "https://www.srmist.edu.in",
            verificationStatus = "Institution-Claimed",
            naacGrade = "A++",
            naacCgpa = 3.55,
            nirfRank = 12L,
            regulators = listOf("UGC", "AICTE", "NMC", "DCI", "PCI", "INC", "IAP"),
            regulatorDetailsSummary = "Multi-stream Deemed University; Dental (DCI), Pharmacy (PCI), Optometry & Physiotherapy circulars pending 2026 fee audit.",
            needsRefresh = true,
            isDemo = true
        ),
        "demo_col_aiims" to College(
            id = "demo_col_aiims",
            userId = userId,
            name = "[DEMO] All India Institute of Medical Sciences (AIIMS)",
            shortCode = "AIIMS-DEL",
            state = "Delhi",
            city = "New Delhi",
            ownership = "Public/Government",
            institutionType = "Institution of National Importance",
            degreeAwardingUniversity = "AIIMS New Delhi (Autonomous INI by Act of Parliament)",
            affiliatedTo = "Ministry of Health & Family Welfare, Govt. of India",
            establishedYear = 1956L,
            websiteUrl = "https://www.aiims.edu",
            verificationStatus = "Verified",
            naacGrade = "A++",
            naacCgpa = 3.92,
            nirfRank = 1L,
            regulators = listOf("NMC", "INC"),
            regulatorDetailsSummary = "Established under AIIMS Act 1956; #1 NIRF Medical; MCC All-India Open Seat Quota.",
            needsRefresh = false,
            isDemo = true
        ),
        "demo_col_christ" to College(
            id = "demo_col_christ",
            userId = userId,
            name = "[DEMO] Christ (Deemed to be University) Central Campus",
            shortCode = "CHRIST-BLR",
            state = "Karnataka",
            city = "Bengaluru",
            ownership = "Private Unaided",
            institutionType = "Deemed-to-be University",
            degreeAwardingUniversity = "Christ (Deemed to be University)",
            affiliatedTo = "UGC Category-I Deemed University",
            establishedYear = 1969L,
            websiteUrl = "https://christuniversity.in",
            verificationStatus = "Outdated",
            naacGrade = "A+",
            naacCgpa = 3.42,
            nirfRank = 60L,
            regulators = listOf("UGC", "AICTE", "NAAC"),
            regulatorDetailsSummary = "AICTE MBA approval verified; NRI & SAARC fee notification from 2025 needs refresh for 2026-27 cycle.",
            needsRefresh = true,
            isDemo = true
        )
    )

    fun buildDemoCourses(userId: String): List<Pair<String, Course>> = listOf(
        "demo_crs_kmc_mbbs" to Course(
            id = "demo_crs_kmc_mbbs",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            specialization = "General Medicine & Surgery (4.5 Yrs + 1 Yr Compulsory Rotating Internship)",
            stream = "Medical",
            durationYears = 5.5,
            intake = 250L,
            eligibility = "10+2 with Physics, Chemistry, Biology/Biotech & English (min 50% PCB) + NEET-UG Qualified",
            entranceExams = listOf("NEET"),
            isLateralEntry = false,
            annualTuitionMinInr = 1780000L,
            annualTuitionMaxInr = 4150000L,
            quotaFeesSummary = "MCC General/Deemed Quota: ₹17.80L/yr | NRI Quota: $50,800/yr (~₹41.50L/yr)",
            regulatoryBody = "NMC",
            approvalStatus = "Verified"
        ),
        "demo_crs_stjohns_bpt" to Course(
            id = "demo_crs_stjohns_bpt",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "BPT",
            specialization = "Bachelor of Physiotherapy (4 Yrs + 6 Months Internship)",
            stream = "Allied Health & Physiotherapy",
            durationYears = 4.5,
            intake = 60L,
            eligibility = "10+2 PCB with 50% aggregate; Lateral Entry available for 3-yr Diploma in Physiotherapy holders",
            entranceExams = listOf("KCET", "University Entrance"),
            isLateralEntry = true,
            annualTuitionMinInr = 95000L,
            annualTuitionMaxInr = 210000L,
            quotaFeesSummary = "KEA Govt Quota: ₹95,000/yr | St. John's Open/Institutional Merit: ₹2.10L/yr",
            regulatoryBody = "IAP",
            approvalStatus = "Verified"
        ),
        "demo_crs_stjohns_mpt" to Course(
            id = "demo_crs_stjohns_mpt",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "MPT",
            specialization = "MPT Neurology & Psychosomatic Disorders",
            stream = "Allied Health & Physiotherapy",
            durationYears = 2.0,
            intake = 12L,
            eligibility = "BPT from RGUHS/IAP recognized institution with 50% marks + 6 months internship completion",
            entranceExams = listOf("University Entrance"),
            isLateralEntry = false,
            annualTuitionMinInr = 185000L,
            annualTuitionMaxInr = 290000L,
            quotaFeesSummary = "Merit Quota: ₹1.85L/yr | Management Quota: ₹2.90L/yr",
            regulatoryBody = "IAP",
            approvalStatus = "Verified"
        ),
        "demo_crs_stjohns_nursing" to Course(
            id = "demo_crs_stjohns_nursing",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "B.Sc Nursing",
            specialization = "Basic B.Sc Nursing (INC & KNC Approved)",
            stream = "Nursing",
            durationYears = 4.0,
            intake = 100L,
            eligibility = "10+2 PCB & English with 45% aggregate + KCET Nursing / Academy Entrance",
            entranceExams = listOf("KCET", "University Entrance"),
            isLateralEntry = false,
            annualTuitionMinInr = 68000L,
            annualTuitionMaxInr = 145000L,
            quotaFeesSummary = "KEA Govt Quota: ₹68,000/yr | Private Institutional Quota: ₹1.45L/yr",
            regulatoryBody = "INC",
            approvalStatus = "Verified"
        ),
        "demo_crs_rvce_cse" to Course(
            id = "demo_crs_rvce_cse",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech",
            specialization = "Computer Science & Engineering (CSE)",
            stream = "Engineering",
            durationYears = 4.0,
            intake = 180L,
            eligibility = "10+2 PCM with 45% (60% for Management) + KCET / COMEDK; Lateral Entry via DCET for Diploma",
            entranceExams = listOf("KCET", "COMEDK"),
            isLateralEntry = true,
            annualTuitionMinInr = 107490L,
            annualTuitionMaxInr = 1600000L,
            quotaFeesSummary = "KCET Govt: ₹1.07L/yr | COMEDK: ₹2.86L/yr | Management Quota: ₹16.00L/yr + Dev Fee",
            regulatoryBody = "AICTE",
            approvalStatus = "Verified"
        ),
        "demo_crs_srm_bds" to Course(
            id = "demo_crs_srm_bds",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "BDS",
            specialization = "Bachelor of Dental Surgery (4 Yrs + 1 Yr Paid Rotating Internship)",
            stream = "Dental",
            durationYears = 5.0,
            intake = 100L,
            eligibility = "10+2 PCB 50% + NEET-UG Qualified (MCC Deemed Dental Counselling)",
            entranceExams = listOf("NEET"),
            isLateralEntry = false,
            annualTuitionMinInr = 390000L,
            annualTuitionMaxInr = 650000L,
            quotaFeesSummary = "General Deemed Quota: ₹3.90L/yr | NRI Quota: ₹6.50L/yr",
            regulatoryBody = "DCI",
            approvalStatus = "Institution-Claimed"
        ),
        "demo_crs_srm_boptom" to Course(
            id = "demo_crs_srm_boptom",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "B.Optom",
            specialization = "Bachelor of Optometry (3 Yrs Academic + 1 Yr Clinical Internship)",
            stream = "Allied Health & Physiotherapy",
            durationYears = 4.0,
            intake = 40L,
            eligibility = "10+2 PCB/PCM with 50% marks; Lateral Entry directly to 2nd year for 2-Yr Diploma in Optometry",
            entranceExams = listOf("University Entrance"),
            isLateralEntry = true,
            annualTuitionMinInr = 125000L,
            annualTuitionMaxInr = 175000L,
            quotaFeesSummary = "Domestic Merit: ₹1.25L/yr | Management/NRI: ₹1.75L/yr",
            regulatoryBody = "UGC",
            approvalStatus = "Verified"
        ),
        "demo_crs_christ_mba" to Course(
            id = "demo_crs_christ_mba",
            userId = userId,
            collegeId = "demo_col_christ",
            collegeName = "[DEMO] Christ (Deemed to be University) Central Campus",
            courseName = "MBA",
            specialization = "Finance & Business Analytics (Dual Specialization)",
            stream = "Management",
            durationYears = 2.0,
            intake = 240L,
            eligibility = "Undergraduate Degree with 50% aggregate + CAT / XAT / CMAT / MAT + Micro Presentation & PI",
            entranceExams = listOf("CAT", "University Entrance"),
            isLateralEntry = false,
            annualTuitionMinInr = 465000L,
            annualTuitionMaxInr = 620000L,
            quotaFeesSummary = "Karnataka Domicile: ₹4.65L/yr | Non-Karnataka: ₹4.95L/yr | NRI/PIO: ₹6.20L/yr",
            regulatoryBody = "AICTE",
            approvalStatus = "Outdated"
        )
    )

    fun buildDemoFeeDocuments(userId: String): List<Pair<String, FeeDocument>> = listOf(
        "demo_fee_rvce_mgmt" to FeeDocument(
            id = "demo_fee_rvce_mgmt",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech Computer Science & Engineering (CSE)",
            academicYear = "2026-27",
            quotaCategory = "Management / Institutional",
            tuitionFeeAnnualInr = 1600000L,
            hostelAndMessAnnualInr = 148000L,
            cautionDepositInr = 25000L,
            otherChargesInr = 67500L,
            extractedRawSummary = "RSST Trust Circular Ref: RVCE/ADM/MGMT/2026-27. B.E. CSE Management Quota Annual Tuition: ₹16,00,000. VTU University Registration & Autonomous Exam Fee: ₹17,500. Skill Lab & Autonomous Development Charge: ₹50,000. Hostel + Veg Mess: ₹1,48,000/yr.",
            webComparisonNotes = "Compared against KEA & COMEDK 2026 Fee Regulatory Notifications. While KEA Govt is ₹1,07,490 and COMEDK is ₹2,86,000, the uploaded Management Circular adds ₹50,000 'Skill Lab Autonomous Charge' not listed on public website brochure.",
            hasDiscrepancy = true,
            discrepancyDetails = "Uploaded trust circular includes an undisclosed ₹50,000/yr Skill Lab & Autonomous Development surcharge above the published ₹16.00L headline tuition.",
            reviewStatus = "Flagged Discrepancy",
            sourceTitle = "RVCE_RSST_Management_Fee_Circular_2026_27.pdf"
        ),
        "demo_fee_kmc_deemed" to FeeDocument(
            id = "demo_fee_kmc_deemed",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            academicYear = "2026-27",
            quotaCategory = "Government / Merit",
            tuitionFeeAnnualInr = 1780000L,
            hostelAndMessAnnualInr = 165000L,
            cautionDepositInr = 10000L,
            otherChargesInr = 0L,
            extractedRawSummary = "MAHE MCC Deemed University MBBS Fee Notification 2026-27: Annual Tuition ₹17,80,000 across 4.5 years (Total ₹80,10,000). Refundable Caution Deposit: ₹10,000. AC Twin Sharing Hostel + Mess: ₹1,65,000/yr.",
            webComparisonNotes = "Matches MCC (mcc.nic.in) Deemed University Seat Matrix & MAHE official prospectus 100% with zero hidden clinical fees.",
            hasDiscrepancy = false,
            discrepancyDetails = "",
            reviewStatus = "Verified",
            sourceTitle = "MAHE_KMC_MCC_Deemed_Fee_Schedule_2026.pdf"
        ),
        "demo_fee_stjohns_bpt" to FeeDocument(
            id = "demo_fee_stjohns_bpt",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "BPT (Bachelor of Physiotherapy)",
            academicYear = "2026-27",
            quotaCategory = "Management / Institutional",
            tuitionFeeAnnualInr = 210000L,
            hostelAndMessAnnualInr = 92000L,
            cautionDepositInr = 10000L,
            otherChargesInr = 18500L,
            extractedRawSummary = "St. John's Allied Health Admissions Bulletin 2026-27: BPT Annual Tuition ₹2,10,000. RGUHS Affiliation & Clinical Posting Fee: ₹18,500. Refundable Library & Lab Caution Deposit: ₹10,000.",
            webComparisonNotes = "Awaiting senior reviewer confirmation of RGUHS revised affiliation fee component (₹18,500 vs ₹14,200 last year).",
            hasDiscrepancy = false,
            discrepancyDetails = "Minor +₹4,300 RGUHS university exam/affiliation revision pending verification.",
            reviewStatus = "Pending Review",
            sourceTitle = "StJohns_AHS_BPT_MPT_Fee_Structure_2026.jpg"
        ),
        "demo_fee_srm_bds" to FeeDocument(
            id = "demo_fee_srm_bds",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "BDS (Dental Surgery)",
            academicYear = "2026-27",
            quotaCategory = "Management / Institutional",
            tuitionFeeAnnualInr = 450000L,
            hostelAndMessAnnualInr = 135000L,
            cautionDepositInr = 15000L,
            otherChargesInr = 85000L,
            extractedRawSummary = "SRM Kattankulathur Dental College Brochure Scan: Annual Tuition ₹4,50,000 + Compulsory Dental Material & Chair Instrument Kit Fee ₹85,000/yr.",
            webComparisonNotes = "MCC portal lists ₹3,90,000/yr tuition and does not disclose the mandatory ₹85,000/yr consumable/instrument charge.",
            hasDiscrepancy = true,
            discrepancyDetails = "₹60,000/yr tuition variance vs MCC portal + ₹85,000/yr mandatory clinical kit charge requires written clarification from admissions office.",
            reviewStatus = "Flagged Discrepancy",
            sourceTitle = "SRM_Dental_BDS_Fee_Brochure_Scan_2026.png"
        )
    )

    fun buildDemoEnquiries(userId: String): List<Pair<String, StudentEnquiry>> = listOf(
        "demo_enq_1" to StudentEnquiry(
            id = "demo_enq_1",
            userId = userId,
            studentName = "[DEMO] Aarav Nair",
            phone = "+91 98450 11234",
            targetStream = "Medical",
            preferredCourse = "MBBS",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(
                listOf(
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_kmc",
                        collegeShortCode = "KMC-MPL",
                        collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
                        courseName = "MBBS",
                        quotaCategory = "Government / Merit",
                        annualFeeInr = 1780000L,
                        totalEstimatedCourseFeeInr = 8010000L,
                        applicationStatus = "Counselling Registered"
                    ),
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_stjohns",
                        collegeShortCode = "SJNAHS-BLR",
                        collegeName = "[DEMO] St. John's National Academy of Health Sciences",
                        courseName = "MBBS",
                        quotaCategory = "Management / Institutional",
                        annualFeeInr = 768000L,
                        totalEstimatedCourseFeeInr = 3456000L,
                        applicationStatus = "Application Submitted"
                    )
                )
            ),
            entranceExamScore = "NEET-UG Score: 594/720 (AIR 24,810)",
            budgetMaxLakhs = 85.0,
            quotaPreference = "Government / Merit",
            stage = "Applied",
            followUpDueToday = true,
            deadlineDate = "2026-11-05",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "aarav.nair26@student.in",
                    marks10thPercent = 94.8,
                    marks12thPercent = 92.4,
                    graduationMarksPercent = 0.0,
                    category = "General",
                    specialization = "General Medicine & Surgery (MBBS)",
                    preferredStatesCities = "Karnataka (Manipal, Bengaluru), Kerala (Kochi)",
                    bankLoanNeeded = true,
                    assignedCounsellor = "Ananya Rao (Senior Counsellor)",
                    privacyConsentTimestamp = "2026-10-12 10:15 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf(
                        "10th/12th Marks Card",
                        "Transfer Certificate",
                        "Migration Certificate",
                        "ID Proof"
                    ),
                    callNotesLog = listOf(
                        "[2026-10-20 11:30] Parent counselled on MCC Round 1 vs KEA Open Private seats; ₹2,00,000 MCC security deposit RTGS ready.",
                        "[2026-10-27 16:45] Verified 10th/12th PCB original marks cards; SBI Premier Institute loan pre-approved for KMC Manipal."
                    ),
                    summaryNotes = "Eligible for MCC Round 2 Deemed Quota at KMC Manipal & KEA Private Merit at St. John's. Pending MCC Allotment Letter."
                )
            )
        ),
        "demo_enq_2" to StudentEnquiry(
            id = "demo_enq_2",
            userId = userId,
            studentName = "[DEMO] Diya Deshmukh",
            phone = "+91 97654 88910",
            targetStream = "Allied Health & Physiotherapy",
            preferredCourse = "BPT",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(
                listOf(
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_stjohns",
                        collegeShortCode = "SJNAHS-BLR",
                        collegeName = "[DEMO] St. John's National Academy of Health Sciences",
                        courseName = "BPT",
                        quotaCategory = "Management / Institutional",
                        annualFeeInr = 210000L,
                        totalEstimatedCourseFeeInr = 840000L,
                        applicationStatus = "Shortlisted"
                    )
                )
            ),
            entranceExamScore = "12th PCB: 84.6% | Diploma PT: 78.4%",
            budgetMaxLakhs = 9.5,
            quotaPreference = "Management / Institutional",
            stage = "Counselling",
            followUpDueToday = true,
            deadlineDate = "2026-11-08",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "diya.deshmukh@student.in",
                    marks10thPercent = 88.2,
                    marks12thPercent = 84.6,
                    graduationMarksPercent = 0.0,
                    category = "OBC-NCL",
                    specialization = "Bachelor of Physiotherapy (Neuro & Ortho Rehab)",
                    preferredStatesCities = "Karnataka (Bengaluru), Maharashtra (Pune)",
                    bankLoanNeeded = false,
                    assignedCounsellor = "Vikram Menon (Allied Health Desk)",
                    privacyConsentTimestamp = "2026-10-16 14:40 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf("10th/12th Marks Card", "Transfer Certificate", "ID Proof"),
                    callNotesLog = listOf(
                        "[2026-10-22 15:00] Discussed RGUHS equivalency certificate requirement for BPT Lateral Entry vs 1st Year entry at St. John's."
                    ),
                    summaryNotes = "Seeking BPT admission with strong hospital patient inflow. St. John's 1,350-bed hospital is #1 preference."
                )
            )
        ),
        "demo_enq_3" to StudentEnquiry(
            id = "demo_enq_3",
            userId = userId,
            studentName = "[DEMO] Rohan Kulkarni",
            phone = "+91 99001 44521",
            targetStream = "Engineering",
            preferredCourse = "B.Tech",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(
                listOf(
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_rvce",
                        collegeShortCode = "RVCE-BLR",
                        collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
                        courseName = "B.Tech",
                        quotaCategory = "COMEDK / Consortium",
                        annualFeeInr = 286000L,
                        totalEstimatedCourseFeeInr = 1144000L,
                        applicationStatus = "Offer Received"
                    )
                )
            ),
            entranceExamScore = "COMEDK Rank: 1,420 | KCET Rank: 2,890",
            budgetMaxLakhs = 14.0,
            quotaPreference = "COMEDK / Consortium",
            stage = "Offer Received",
            followUpDueToday = false,
            deadlineDate = "2026-11-18",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "rohan.kulkarni@student.in",
                    marks10thPercent = 96.0,
                    marks12thPercent = 93.8,
                    graduationMarksPercent = 0.0,
                    category = "General",
                    specialization = "Computer Science & Engineering (CSE)",
                    preferredStatesCities = "Karnataka (Bengaluru)",
                    bankLoanNeeded = true,
                    assignedCounsellor = "Ananya Rao (Senior Counsellor)",
                    privacyConsentTimestamp = "2026-10-10 09:30 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf(
                        "10th/12th Marks Card",
                        "Transfer Certificate",
                        "Migration Certificate",
                        "Allotment Letter",
                        "ID Proof"
                    ),
                    callNotesLog = listOf(
                        "[2026-10-19 12:15] Shared Autonomous vs VTU degree-awarding audit brief with parents.",
                        "[2026-10-28 17:10] COMEDK Round 2 allotment received for RVCE; fee DD being prepared."
                    ),
                    summaryNotes = "All 5 admission documents verified. Ready for final fee remittance at RVCE."
                )
            )
        ),
        "demo_enq_4" to StudentEnquiry(
            id = "demo_enq_4",
            userId = userId,
            studentName = "[DEMO] Meera Krishnan",
            phone = "+91 94441 77210",
            targetStream = "Dental",
            preferredCourse = "BDS",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(
                listOf(
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_srm",
                        collegeShortCode = "SRM-KTR",
                        collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
                        courseName = "BDS",
                        quotaCategory = "Management / Institutional",
                        annualFeeInr = 450000L,
                        totalEstimatedCourseFeeInr = 2250000L,
                        applicationStatus = "Shortlisted"
                    )
                )
            ),
            entranceExamScore = "NEET-UG Score: 412/720 (AIR 1,48,200)",
            budgetMaxLakhs = 26.0,
            quotaPreference = "Management / Institutional",
            stage = "Shortlisted",
            followUpDueToday = true,
            deadlineDate = "2026-11-12",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "meera.krishnan@student.in",
                    marks10thPercent = 89.0,
                    marks12thPercent = 82.5,
                    graduationMarksPercent = 0.0,
                    category = "General",
                    specialization = "Bachelor of Dental Surgery (BDS)",
                    preferredStatesCities = "Tamil Nadu (Chennai), Karnataka (Bengaluru)",
                    bankLoanNeeded = true,
                    assignedCounsellor = "Vikram Menon (Allied Health Desk)",
                    privacyConsentTimestamp = "2026-10-21 16:05 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf("10th/12th Marks Card", "ID Proof"),
                    callNotesLog = listOf(
                        "[2026-10-26 11:10] Briefed family on SRM BDS ₹85,000/yr clinical material kit charge flagged by our OCR audit desk."
                    ),
                    summaryNotes = "Comparing SRM Dental vs Manipal MCODS; awaiting Round 2 Deemed cutoff movement."
                )
            )
        ),
        "demo_enq_5" to StudentEnquiry(
            id = "demo_enq_5",
            userId = userId,
            studentName = "[DEMO] Kabir Sharma",
            phone = "+91 98112 63090",
            targetStream = "Management",
            preferredCourse = "MBA",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(
                listOf(
                    ShortlistedCollegeItem(
                        collegeId = "demo_col_christ",
                        collegeShortCode = "CHRIST-BLR",
                        collegeName = "[DEMO] Christ (Deemed to be University) Central Campus",
                        courseName = "MBA",
                        quotaCategory = "Management / Institutional",
                        annualFeeInr = 495000L,
                        totalEstimatedCourseFeeInr = 990000L,
                        applicationStatus = "Enrolled"
                    )
                )
            ),
            entranceExamScore = "CAT: 86.4 Percentile | MAT: 94.2 Percentile",
            budgetMaxLakhs = 12.0,
            quotaPreference = "Management / Institutional",
            stage = "Enrolled",
            followUpDueToday = false,
            deadlineDate = "2026-10-30",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "kabir.sharma@student.in",
                    marks10thPercent = 87.5,
                    marks12thPercent = 86.0,
                    graduationMarksPercent = 79.4,
                    category = "General",
                    specialization = "MBA Finance & Business Analytics",
                    preferredStatesCities = "Karnataka (Bengaluru)",
                    bankLoanNeeded = false,
                    assignedCounsellor = "Ananya Rao (Senior Counsellor)",
                    privacyConsentTimestamp = "2026-10-02 12:00 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf(
                        "10th/12th Marks Card",
                        "Transfer Certificate",
                        "Migration Certificate",
                        "Allotment Letter",
                        "ID Proof"
                    ),
                    callNotesLog = listOf(
                        "[2026-10-15 14:30] Cleared Christ University Micro Presentation & PI round.",
                        "[2026-10-24 10:20] Full 1st-year fee paid via official portal; admission letter archived."
                    ),
                    summaryNotes = "Successfully enrolled in MBA Finance & Business Analytics at Christ Central Campus."
                )
            )
        ),
        "demo_enq_6" to StudentEnquiry(
            id = "demo_enq_6",
            userId = userId,
            studentName = "[DEMO] Zoya Siddiqui",
            phone = "+91 96321 55409",
            targetStream = "Medical",
            preferredCourse = "MBBS",
            preferredColleges = StudentEnquiry.encodeShortlistedColleges(emptyList()),
            entranceExamScore = "NEET-UG Score: 618/720 (AIR 14,120)",
            budgetMaxLakhs = 42.0,
            quotaPreference = "Government / Merit",
            stage = "New Enquiry",
            followUpDueToday = true,
            deadlineDate = "2026-11-04",
            counsellorNotes = StudentEnquiry.encodeProfileMetadata(
                StudentProfileMetadata(
                    email = "zoya.siddiqui@student.in",
                    marks10thPercent = 95.6,
                    marks12thPercent = 94.2,
                    graduationMarksPercent = 0.0,
                    category = "EWS",
                    specialization = "MBBS General Medicine",
                    preferredStatesCities = "Karnataka (Bengaluru, Manipal), Delhi NCR",
                    bankLoanNeeded = true,
                    assignedCounsellor = "Ananya Rao (Senior Counsellor)",
                    privacyConsentTimestamp = "2026-10-29 09:15 IST (DPDP Consent Signed)",
                    checkedDocuments = listOf("10th/12th Marks Card", "ID Proof"),
                    callNotesLog = listOf(
                        "[2026-10-29 09:20] Inbound parent enquiry — run Automated Eligibility & Budget Matcher to shortlist colleges under ₹42L total budget."
                    ),
                    summaryNotes = "High NEET score (618); run Eligibility Matcher to compare St. John's KEA Merit vs AIIMS/Deemed options."
                )
            )
        )
    )

    fun buildDemoSourceQueue(userId: String): List<Pair<String, SourceVerificationItem>> = listOf(
        "demo_sq_rvce_comedk" to SourceVerificationItem(
            id = "demo_sq_rvce_comedk",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech Computer Science & Engineering (CSE)",
            researchTarget = "Fetch Latest 2026-27 Fee Circular",
            fieldKey = "quotaFeesSummary",
            previousValue = "KCET Govt: ₹1.07L/yr | COMEDK: ₹2.86L/yr | Management Quota: ₹16.00L/yr + Dev Fee",
            extractedValue = "KEA KCET Govt Quota: ₹1,07,495/yr | COMEDK Upper Cap: ₹3,01,520/yr (incl. VTU + Skill Lab Fee) | RSST Management Quota: ₹16,50,000/yr",
            sourceTitle = "KEA & COMEDK UGET 2026-27 Engineering Fee Notification Circular",
            sourceUrl = "https://cetonline.karnataka.gov.in/kea/",
            sourceType = "Counselling Authority",
            academicYear = "2026-27",
            confidenceScore = 94L,
            hasContradiction = true,
            contradictionNote = "COMEDK upper fee inclusive of Skill Lab/University charges is ₹3,01,520/yr (+₹15,520 variance vs stored ₹2.86L headline figure).",
            verificationStatus = "Pending Verification",
            retrievedAtIso = "2026-10-29 09:45 IST"
        ),
        "demo_sq_srm_dci" to SourceVerificationItem(
            id = "demo_sq_srm_dci",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "BDS (Dental Surgery)",
            researchTarget = "Verify UGC/AICTE/NMC Status",
            fieldKey = "regulatorDetailsSummary",
            previousValue = "Multi-stream Deemed University; Dental (DCI), Pharmacy (PCI), Optometry & Physiotherapy circulars pending 2026 fee audit.",
            extractedValue = "DCI Renewal of 100 BDS Seats verified under Ministry of Health Gazette; however, itemized 2026-27 clinical consumable & chair fee circular is not published on public portal.",
            sourceTitle = "SRM Kattankulathur Dental Consumable Annex — Not Found Online",
            sourceUrl = "Unable to verify online — manual document required",
            sourceType = "Manual Document Required",
            academicYear = "2026-27",
            confidenceScore = 68L,
            hasContradiction = true,
            contradictionNote = "Official website lists ₹3.90L/yr tuition but omits the ₹85,000/yr clinical chair kit charge seen on physical brochure scan.",
            verificationStatus = "Manual Document Required",
            retrievedAtIso = "2026-10-29 10:12 IST"
        ),
        "demo_sq_kmc_nirf" to SourceVerificationItem(
            id = "demo_sq_kmc_nirf",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            researchTarget = "Check NIRF/NAAC Accreditation",
            fieldKey = "regulatorDetailsSummary",
            previousValue = "NMC Recognized 250 MBBS seats (Ref: NMC/UG/2025/KMC); NAAC A++ (CGPA 3.65) valid till 2028; MCC Deemed Quota.",
            extractedValue = "NIRF Medical Rank #9 (Score 66.19); NAAC A++ (CGPA 3.65) under MAHE Deemed-to-be University; NMC 250 MBBS intake confirmed for 2026-27 MCC All-India Deemed Counselling.",
            sourceTitle = "NIRF India Rankings Medical & NMC College Information Portal",
            sourceUrl = "https://www.nirfindia.org/",
            sourceType = "Government/Regulator Portal",
            academicYear = "2026-27",
            confidenceScore = 98L,
            hasContradiction = false,
            contradictionNote = "Matches stored database record with zero contradictions.",
            verificationStatus = "Approved & Applied",
            retrievedAtIso = "2026-10-28 18:20 IST"
        )
    )

    fun buildDemoAuditLogs(userId: String): List<Pair<String, AuditLogEntry>> = listOf(
        "demo_aud_1" to AuditLogEntry(
            id = "demo_aud_1",
            userId = userId,
            actorRole = "Senior Reviewer",
            actionType = "SOURCE_VERIFIED",
            targetModule = "Source & Verification Queue",
            targetRecordName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            details = "Approved NIRF Medical #9 & NMC 250 MBBS seat verification from nirfindia.org (Confidence: 98%)."
        ),
        "demo_aud_2" to AuditLogEntry(
            id = "demo_aud_2",
            userId = userId,
            actorRole = "Fee Reviewer",
            actionType = "FEE_DISCREPANCY_FLAGGED",
            targetModule = "Gemini Fee OCR & Audit Lab",
            targetRecordName = "[DEMO] R.V. College of Engineering (RVCE) — B.Tech CSE",
            details = "Flagged ₹50,000/yr Skill Lab & Autonomous Development surcharge in RSST Management Circular vs published brochure."
        ),
        "demo_aud_3" to AuditLogEntry(
            id = "demo_aud_3",
            userId = userId,
            actorRole = "Researcher",
            actionType = "LIVE_RESEARCH_QUEUED",
            targetModule = "Live Internet Research Engine",
            targetRecordName = "[DEMO] SRMIST — BDS Dental",
            details = "Queued manual document requirement for SRM Dental ₹85,000/yr consumable fee annex (Unable to verify online)."
        )
    )

    fun buildDemoBriefingVersions(
        userId: String,
        colleges: List<Pair<String, College>>,
        courses: List<Pair<String, Course>>,
        feeDocs: List<Pair<String, FeeDocument>>,
        sourceQueue: List<Pair<String, SourceVerificationItem>>
    ): List<Pair<String, CollegeBriefingVersion>> {
        val kmc = colleges.firstOrNull { it.first == "demo_col_kmc" }?.second ?: return emptyList()
        val kmcCourses = courses.map { it.second }.filter { it.collegeId == "demo_col_kmc" }
        val kmcFees = feeDocs.map { it.second }.filter { it.collegeId == "demo_col_kmc" }
        val kmcQueue = sourceQueue.map { it.second }.filter { it.collegeId == "demo_col_kmc" }

        val kmcSectionsV1 = generate20PointBriefingSections(
            college = kmc,
            courses = kmcCourses,
            feeDocs = kmcFees,
            sourceQueue = kmcQueue
        )

        val rvce = colleges.firstOrNull { it.first == "demo_col_rvce" }?.second
        val rvceSectionsV1 = rvce?.let {
            generate20PointBriefingSections(
                college = it,
                courses = courses.map { c -> c.second }.filter { c -> c.collegeId == "demo_col_rvce" },
                feeDocs = feeDocs.map { f -> f.second }.filter { f -> f.collegeId == "demo_col_rvce" },
                sourceQueue = sourceQueue.map { s -> s.second }.filter { s -> s.collegeId == "demo_col_rvce" }
            )
        }

        return buildList {
            add(
                "demo_brf_kmc_v1" to CollegeBriefingVersion(
                    id = "demo_brf_kmc_v1",
                    userId = userId,
                    collegeId = "demo_col_kmc",
                    collegeName = kmc.name,
                    courseFocus = "MBBS (250 Intake — MCC Deemed Quota)",
                    versionNumber = 1L,
                    versionLabel = "v1.0 — Verified Clinical & MCC Fee Synthesis",
                    editedByRole = "Senior Reviewer",
                    sectionsJson = CollegeBriefingVersion.encodeSections(kmcSectionsV1),
                    summaryHeadline = "Top-10 NIRF (#9) Deemed Medical College under MAHE with 2,032-bed Kasturba Hospital teaching complex and verified ₹17.80L/yr MCC Deemed fee structure.",
                    clinicalExposureSummary = "Attached to Kasturba Hospital Manipal (2,032 Teaching Beds; 3,400+ daily OPD inflow; 1-Year Compulsory Rotating Medical Internship with ₹30,000/month stipend; Zero rural service bond for All-India MCC Deemed seats).",
                    enquiryFooterText = AppSettingsRecord.MANDATORY_FOOTER_BLOCK
                )
            )
            if (rvce != null && rvceSectionsV1 != null) {
                add(
                    "demo_brf_rvce_v1" to CollegeBriefingVersion(
                        id = "demo_brf_rvce_v1",
                        userId = userId,
                        collegeId = "demo_col_rvce",
                        collegeName = rvce.name,
                        courseFocus = "B.Tech CSE (KCET / COMEDK / Management)",
                        versionNumber = 1L,
                        versionLabel = "v1.0 — Autonomous vs VTU Degree Audit & Fee Brief",
                        editedByRole = "Admin",
                        sectionsJson = CollegeBriefingVersion.encodeSections(rvceSectionsV1),
                        summaryHeadline = "Premier Autonomous Engineering Institution in Bengaluru; academic autonomy under UGC, while B.E. degree is strictly awarded by Visvesvaraya Technological University (VTU), Belagavi.",
                        clinicalExposureSummary = "Engineering Stream — 8th Semester Mandatory Industry Internship & 18 Corporate Centers of Excellence (Cisco, Nvidia, Bosch, Mercedes-Benz R&D).",
                        enquiryFooterText = AppSettingsRecord.MANDATORY_FOOTER_BLOCK
                    )
                )
            }
        }
    }

    /**
     * Synthesizes a complete, domain-accurate 20-Point College Intelligence Briefing
     * from stored College, Courses, FeeDocuments, and SourceVerificationItems.
     */
    fun generate20PointBriefingSections(
        college: College,
        courses: List<Course>,
        feeDocs: List<FeeDocument>,
        sourceQueue: List<SourceVerificationItem>,
        enquiryFooter: String = AppSettingsRecord.MANDATORY_FOOTER_BLOCK
    ): List<BriefingSectionItem> {
        val isHealthcare = courses.any {
            it.stream.contains("Medical", true) ||
                it.stream.contains("Allied", true) ||
                it.stream.contains("Nursing", true) ||
                it.stream.contains("Dental", true) ||
                it.courseName in listOf("MBBS", "BDS", "BPT", "MPT", "B.Sc Nursing", "B.Optom")
        } || college.regulators.any { it in listOf("NMC", "DCI", "INC", "IAP") }

        val courseLines = if (courses.isEmpty()) {
            "No course records linked yet — add courses in Module 4."
        } else {
            courses.joinToString("\n") { c ->
                "• ${c.courseName} (${c.specialization}) — Intake: ${c.intake} seats | Duration: ${c.durationYears} yrs | Lateral Entry: ${if (c.isLateralEntry) "Available (Direct 2nd Year)" else "No"} | Regulator: ${c.regulatoryBody} (${c.approvalStatus})"
            }
        }

        val feeLines = if (feeDocs.isEmpty()) {
            courses.joinToString("\n") { c ->
                "• ${c.courseName}: ${c.quotaFeesSummary} (Est. Annual Range: ₹${c.annualTuitionMinInr / 100000.0}L – ₹${c.annualTuitionMaxInr / 100000.0}L)"
            }.ifBlank { "Official 2026-27 fee circular pending upload in Module 5." }
        } else {
            feeDocs.joinToString("\n") { f ->
                "• ${f.courseName} [${f.quotaCategory} | ${f.academicYear}]: Tuition ₹${f.tuitionFeeAnnualInr}/yr + Hostel/Mess ₹${f.hostelAndMessAnnualInr}/yr + Caution ₹${f.cautionDepositInr} + Other ₹${f.otherChargesInr} = Total 1st Yr ₹${f.totalFirstYearInr} (Status: ${f.reviewStatus})"
            }
        }

        val discrepancySummary = feeDocs.filter { it.hasDiscrepancy }
            .joinToString("; ") { "${it.courseName}: ${it.discrepancyDetails}" }
            .ifBlank { "Zero unresolved fee discrepancies in audited documents." }

        val clinicalSectionContent = if (isHealthcare) {
            when {
                college.name.contains("KMC", true) || college.name.contains("Manipal", true) ->
                    "Parent Teaching Hospital: Kasturba Hospital, Manipal (2,032 Teaching Beds; NABL & NABH Accredited). Daily OPD Inflow: 3,400+ patients/day; IPD Occupancy >86%. Compulsory Rotating Medical Internship (CRMI): 12 months across Medicine, Surgery, OBG, Paediatrics, Orthopaedics & Emergency with ₹30,000/month stipend. Service Bond: No mandatory rural service bond for MCC All-India Deemed Quota seats (1-year bond applies only to Karnataka Govt KEA subsidized seats)."
                college.name.contains("St. John", true) ->
                    "Parent Teaching Hospital: St. John's Medical College Hospital, Bengaluru (1,350 Teaching Beds; Super-specialty ICU & Neurological Rehabilitation Wing). Daily OPD Inflow: 2,600+ patients/day. Clinical Postings for MBBS, BPT, MPT & B.Sc Nursing conducted on-campus. Mandatory 2-Year Rural Medical Service Bond for MBBS graduates as per St. John's CBCI society agreement; 6-Month Compulsory Clinical Internship for BPT."
                college.name.contains("AIIMS", true) ->
                    "Parent Teaching Hospital: AIIMS New Delhi Hospital & Specialty Centers (2,478+ Teaching Beds across Main Hospital, Trauma Centre, RPC Ophthalmic & IRCH Cancer Centre). Daily OPD Inflow: 12,000+ patients/day. Stipend: ₹30,070/month during 1-year compulsory internship. Service Bond: Zero rural service bond."
                else ->
                    "Attached Multi-Specialty Teaching Hospital (1,200+ Beds) with dedicated Dental Chairs (250+ units), Optometry Vision Clinics & Physiotherapy Rehab OPD. 1-Year Compulsory Rotating Internship required for BDS/B.Optom degree registration."
            }
        } else {
            "Stream Focus (Engineering / Management): Mandatory 8th-Semester Industry Internship & Capstone Project. On-campus R&D laboratories, corporate incubation cell, and structured 8-week summer industrial training after 6th semester (no medical clinical hospital bond applicable)."
        }

        val placementPackageContent = if (isHealthcare) {
            "Institution-Wide vs Course-Specific Distinction: Medical/Allied Health graduates primarily pursue PG Residency (NEET-PG / INI-CET / USMLE / PLAB) or Hospital Clinical Fellowships rather than corporate campus drives. NIRF Submitted Median Stipend/CTC: MBBS PG Junior Resident ₹9.60L–₹13.20L LPA; BPT/MPT Clinical Physiotherapist ₹4.20L–₹7.80L LPA; B.Sc Nursing ₹4.50L–₹8.40L LPA (Domestic & UK NHS/Middle East pathways)."
        } else {
            "Course-Specific (B.Tech CSE/ISE): Highest Package ₹62.00 LPA (Domestic Product R&D), Average Package ₹18.40 LPA, Median Package ₹15.20 LPA. Institution-Wide Overall Engineering/MBA: Average ₹11.80 LPA, Median ₹10.10 LPA (NIRF 2026 Submitted Data)."
        }

        val citationsText = buildString {
            appendLine("1. Primary Website: ${college.websiteUrl.ifBlank { "Unable to verify online — manual document required" }}")
            appendLine("2. Regulatory Summary: ${college.regulatorDetailsSummary}")
            sourceQueue.forEachIndexed { idx, item ->
                appendLine("${idx + 3}. [${item.sourceType}] ${item.sourceTitle} — ${item.sourceUrl} (Retrieved: ${item.retrievedAtIso}, Confidence: ${item.confidenceScore}%)")
            }
        }.trim()

        val mainBadge = when (college.verificationStatus) {
            "Verified" -> "Verified Official"
            "Institution-Claimed" -> "College-Provided Unverified"
            "Outdated" -> "Third-Party"
            else -> "Not Publicly Reported"
        }

        return listOf(
            BriefingSectionItem(
                1,
                "Official College Name & Campus Location",
                "${college.name} (Code: ${college.shortCode}) — Located at ${college.city}, ${college.state}, India. Primary Portal: ${college.websiteUrl}",
                "Verified Official",
                "AISHE / Official Institute Registry (${college.websiteUrl})"
            ),
            BriefingSectionItem(
                2,
                "Executive Summary",
                "${college.name} is a ${college.ownership} ${college.institutionType} established in ${college.establishedYear} in ${college.city}, ${college.state}. Degrees are awarded by ${college.degreeAwardingUniversity}. Current Consultancy Verification Status: ${college.verificationStatus}. Key tracked programmes: ${courses.joinToString { it.courseName }.ifBlank { "Multi-disciplinary" }}. Audit Alert: $discrepancySummary",
                mainBadge,
                "Internal Consultancy Intelligence Synthesis"
            ),
            BriefingSectionItem(
                3,
                "College Background & Establishment Year",
                "Established in ${college.establishedYear}, the institution operates under ${college.ownership} governance. Administrative affiliation is recorded as '${college.affiliatedTo}'. Over ${(2026 - college.establishedYear).coerceAtLeast(1)} years of academic operations.",
                "Verified Official",
                "UGC / State Higher Education Council Gazette"
            ),
            BriefingSectionItem(
                4,
                "Institutional Ownership, Type, Recognition & Administrative Affiliation",
                "• Ownership Category: ${college.ownership}\n• Institution Classification: ${college.institutionType}\n• Administrative Affiliation: ${college.affiliatedTo}\n• Needs Annual Refresh Flag: ${if (college.needsRefresh) "YES — Scheduled for 2026-27 re-verification" else "NO — Current for 2026-27"}",
                "Verified Official",
                "AISHE & UGC Section 2(f)/12(B) / Section 3 Portal"
            ),
            BriefingSectionItem(
                5,
                "Degree-Awarding University & Applicable Regulatory Approvals",
                "• Degree-Awarding University (Strictly Separated from Affiliation): ${college.degreeAwardingUniversity}\n• Statutory Regulators: ${college.regulators.joinToString(", ")}\n• Regulatory Audit Notes: ${college.regulatorDetailsSummary}",
                mainBadge,
                "UGC / AICTE / NMC / IAP Statutory Portals"
            ),
            BriefingSectionItem(
                6,
                "Courses, Specializations & Approved Intake",
                courseLines,
                mainBadge,
                "Approved Seat Matrix 2026-27"
            ),
            BriefingSectionItem(
                7,
                "Eligibility, Entrance Examinations, Lateral Entry & Admission Process",
                courses.joinToString("\n") { c ->
                    "• ${c.courseName}: Eligibility: ${c.eligibility} | Accepted Exams: ${c.entranceExams.joinToString(", ")} | Lateral Entry (2nd Yr Direct): ${if (c.isLateralEntry) "Permitted via Diploma Equivalency" else "Not Applicable (Standard 1st Yr Entry Only)"}"
                }.ifBlank { "Entrance via national/state counselling (NEET-UG / KCET / COMEDK / CAT)." },
                "Verified Official",
                "MCC / KEA / University Admission Prospectus 2026-27"
            ),
            BriefingSectionItem(
                8,
                "Course-Wise & Quota-Wise Fee Structure, Total Estimated Cost & Bank Loan Eligibility Breakdown",
                "$feeLines\n\n• Bank Education Loan Eligibility Breakdown: Tuition Fee, Examination/University Registration Fee, Official Hostel & Mess Charges, and Refundable Caution Deposit (documented on official receipt) are 100% eligible under IBA Model Education Loan Scheme & Vidya Lakshmi Portal (Collateral-free up to ₹7.5L–₹40L under PM-Vidyalaxmi / Premier Institute Tier). Undisclosed cash/trust development surcharges are NOT eligible for bank disbursement.",
                if (feeDocs.any { it.reviewStatus == "Verified" }) "Verified Official" else "College-Provided Unverified",
                "Module 5 Gemini OCR Audited Fee Schedules"
            ),
            BriefingSectionItem(
                9,
                "Highest, Average & Median Placement Packages",
                placementPackageContent,
                "Third-Party",
                "NIRF 2026 Submitted Data & Training/Placement Cell Report"
            ),
            BriefingSectionItem(
                10,
                "Placement Rates & Reporting Period Details",
                "Reporting Period: Academic Cycle 2024-25 / 2025-26 Cohort. Graduating Cohort Placement / Higher-Studies Progression Rate: 89.4% verified via NIRF graduate outcome filing. Note: Figures exclude students opting out for family enterprise or USMLE/NEET-PG preparation.",
                "Verified Official",
                "NIRF India Rankings Graduate Outcome Filing"
            ),
            BriefingSectionItem(
                11,
                "Faculty, Laboratories, Infrastructure & Research Opportunities",
                "Faculty-to-Student Ratio maintained as per ${college.regulators.firstOrNull() ?: "UGC"} norms (PhD / MD / MS qualified senior cadre). Equipped with central digital library, NABL/simulation skill labs, high-performance computing clusters, and funded ICMR/DST/AICTE research grants.",
                "College-Provided Unverified",
                "Mandatory Disclosure Document & SSR Report"
            ),
            BriefingSectionItem(
                12,
                "Clinical Exposure, Parent/Affiliated Hospital Bed Strength, OPD Inflow, Internships & Service Bonds",
                clinicalSectionContent,
                if (isHealthcare) "Verified Official" else "College-Provided Unverified",
                if (isHealthcare) "NMC / RGUHS / Hospital Clinical Return" else "AICTE Mandatory Internship Guidelines"
            ),
            BriefingSectionItem(
                13,
                "Hostel, Mess, Transport, Campus Facilities & Student Support",
                "Separate on-campus boys and girls residential blocks (AC & Non-AC twin/triple occupancy). Annual Hostel + Mess ranges from ₹92,000 to ₹1,65,000/yr depending on room configuration. 24x7 campus medical centre, anti-ragging squad, student psychological counselling cell, and fleet transport across ${college.city}.",
                "College-Provided Unverified",
                "Hostel Warden Schedule & Student Handbook 2026-27"
            ),
            BriefingSectionItem(
                14,
                "Rankings & Accreditations (NIRF, NAAC Grade & Validity)",
                "• NAAC Accreditation: Grade ${college.naacGrade} (CGPA: ${college.naacCgpa} / 4.00)\n• NIRF National Rank: #${college.nirfRank} in Category\n• Statutory Council Status: ${college.verificationStatus}",
                "Verified Official",
                "NAAC Certificate & nirfindia.org"
            ),
            BriefingSectionItem(
                15,
                "Student Reviews & Recurring Themes (Separated from Internal Consultant Notes)",
                "• External Student Feedback Themes: Strong peer cohort, rigorous examination standards under ${college.degreeAwardingUniversity}, high clinical/practical lab exposure, strict attendance requirement (min 75%–85%).\n• Internal Consultant Advisory Note (Strictly Separated): Verify quota-specific ancillary charges in writing before paying booking deposit.",
                "Third-Party",
                "Verified Alumni & Parent Feedback Synthesis"
            ),
            BriefingSectionItem(
                16,
                "Documented Strengths & Limitations / Risks",
                "• Documented Strengths: Established in ${college.establishedYear}, NAAC ${college.naacGrade}, clear degree-awarding lineage (${college.degreeAwardingUniversity}), strong clinical/industry ecosystem in ${college.city}.\n• Documented Limitations / Risks: $discrepancySummary",
                mainBadge,
                "Consultancy Risk & Compliance Desk"
            ),
            BriefingSectionItem(
                17,
                "Admission Deadlines, Scholarships & Official Contact Details",
                "• Counselling Window: MCC / State Counselling Rounds (Aug – Nov 2026)\n• Merit Scholarships: Govt Post-Matric, AICTE Pragati/Saksham, and Institutional Merit-cum-Means waivers.\n• Official Institution Website: ${college.websiteUrl}",
                "Verified Official",
                "Official Admissions Portal"
            ),
            BriefingSectionItem(
                18,
                "Source Citations, Verification Timestamps & Confidence Notes",
                citationsText,
                "Verified Official",
                "Module 3 & Module 15 Grounding Ledger"
            ),
            BriefingSectionItem(
                19,
                "Data Gaps & Recommended Next Verification Steps",
                if (college.needsRefresh || feeDocs.any { it.hasDiscrepancy }) {
                    "1. Obtain signed 2026-27 Fee Regulatory Committee annexure for ${college.shortCode}.\n2. Resolve flagged fee variance ($discrepancySummary) in Module 7 & Module 15 before issuing final bank loan letter."
                } else {
                    "All primary statutory approvals, degree-awarding university mappings, and 2026-27 quota fee schedules are verified. Next routine check scheduled prior to Round 2 counselling."
                },
                mainBadge,
                "Senior Reviewer Sign-Off"
            ),
            BriefingSectionItem(
                20,
                "Mandatory Admission Enquiry Contact Footer",
                enquiryFooter,
                "Verified Official",
                "Locked App Settings (app_settings)"
            )
        )
    }

    /**
     * Module 6: Multi-Year Placement & Career Outcome Seed Dataset
     * Includes explicit Institution-Wide vs Course-Specific, UG vs PG, Domestic vs International,
     * and -1 ("Not Publicly Reported") examples.
     */
    fun buildDemoPlacements(userId: String): List<Pair<String, PlacementRecord>> = listOf(
        "demo_plc_rvce_cse_26_dom" to PlacementRecord(
            id = "demo_plc_rvce_cse_26_dom",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech",
            specialization = "Computer Science & Engineering (CSE)",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 62.0,
            averagePackageLpa = 19.4,
            medianPackageLpa = 16.5,
            placementRatePercent = 96.2,
            eligibleStudents = 176L,
            participatingStudents = 168L,
            placedStudents = 162L,
            totalRecruiters = 114L,
            internshipStipendMonthlyInr = 75000L,
            topRecruiters = "Atlassian, Microsoft India, Qualcomm, SAP Labs, Cisco, Goldman Sachs, Intuit",
            commonJobRoles = "Software Development Engineer (SDE-1), Cloud Systems Engineer, AI/ML Associate",
            sourceCitation = "RVCE Placement Cell Audited CSE Report 2025-26 & NIRF 2026 Engineering Filing",
            verificationStatus = "Verified"
        ),
        "demo_plc_rvce_cse_25_dom" to PlacementRecord(
            id = "demo_plc_rvce_cse_25_dom",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech",
            specialization = "Computer Science & Engineering (CSE)",
            academicYear = "2024-25",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 54.0,
            averagePackageLpa = 17.8,
            medianPackageLpa = 15.2,
            placementRatePercent = 94.8,
            eligibleStudents = 174L,
            participatingStudents = 165L,
            placedStudents = 156L,
            totalRecruiters = 105L,
            internshipStipendMonthlyInr = 65000L,
            topRecruiters = "Microsoft, Cisco, Flipkart, Boeing, Texas Instruments, Oracle",
            commonJobRoles = "SDE-1, Embedded Systems Engineer, Full-Stack Developer",
            sourceCitation = "RVCE NIRF 2025 Submitted Placement Data",
            verificationStatus = "Verified"
        ),
        "demo_plc_rvce_cse_24_dom" to PlacementRecord(
            id = "demo_plc_rvce_cse_24_dom",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech",
            specialization = "Computer Science & Engineering (CSE)",
            academicYear = "2023-24",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 48.0,
            averagePackageLpa = 16.2,
            medianPackageLpa = 14.0,
            placementRatePercent = 93.5,
            eligibleStudents = 170L,
            participatingStudents = 160L,
            placedStudents = 150L,
            totalRecruiters = 98L,
            internshipStipendMonthlyInr = 55000L,
            topRecruiters = "SAP Labs, Walmart Global Tech,PhonePe, Mercedes-Benz R&D",
            commonJobRoles = "Software Engineer, Data Analyst, Systems Engineer",
            sourceCitation = "RVCE NIRF 2024 Engineering Report",
            verificationStatus = "Verified"
        ),
        "demo_plc_rvce_inst_26_intl" to PlacementRecord(
            id = "demo_plc_rvce_inst_26_intl",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech (All Branches)",
            specialization = "Institution-Wide International Offers Only",
            academicYear = "2025-26",
            scopeType = "Institution-Wide",
            levelType = "UG",
            offerScope = "International",
            highestPackageLpa = 92.0,
            averagePackageLpa = -1.0, // Not Publicly Reported separately for international cohort
            medianPackageLpa = -1.0,
            placementRatePercent = -1.0,
            eligibleStudents = 980L,
            participatingStudents = 890L,
            placedStudents = 7L,
            totalRecruiters = 4L,
            internshipStipendMonthlyInr = 140000L,
            topRecruiters = " Tokyo Electron (Japan), Sony Global, European FinTech Recruiters",
            commonJobRoles = "International Graduate Engineer, Global R&D Associate",
            sourceCitation = "RVCE Press Release (Flagged as International Outlier — Do Not Mix With Domestic Average)",
            verificationStatus = "Institution-Claimed"
        ),
        "demo_plc_kmc_mbbs_26" to PlacementRecord(
            id = "demo_plc_kmc_mbbs_26",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            specialization = "General Medicine & Surgery",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 18.5,
            averagePackageLpa = 12.6,
            medianPackageLpa = 12.2,
            placementRatePercent = 98.4,
            eligibleStudents = 246L,
            participatingStudents = 192L,
            placedStudents = 189L,
            totalRecruiters = 34L,
            internshipStipendMonthlyInr = 35000L,
            topRecruiters = "Kasturba Hospital Manipal, Apollo Hospitals, Manipal Hospitals Group, Narayana Health",
            commonJobRoles = "Junior Resident Doctor, Medical Officer, Clinical Research Fellow, USMLE/PLAB/NEET-PG Progression",
            sourceCitation = "MAHE NIRF 2026 Medical Category Graduate Outcome Submission",
            verificationStatus = "Verified"
        ),
        "demo_plc_kmc_mbbs_25" to PlacementRecord(
            id = "demo_plc_kmc_mbbs_25",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            specialization = "General Medicine & Surgery",
            academicYear = "2024-25",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 16.8,
            averagePackageLpa = 11.8,
            medianPackageLpa = 11.4,
            placementRatePercent = 97.6,
            eligibleStudents = 244L,
            participatingStudents = 188L,
            placedStudents = 183L,
            totalRecruiters = 30L,
            internshipStipendMonthlyInr = 32000L,
            topRecruiters = "Manipal Hospitals, Aster DM Healthcare, Fortis Healthcare, Max Healthcare",
            commonJobRoles = "Resident Medical Officer, Clinical Registrar, PG Residency",
            sourceCitation = "MAHE NIRF 2025 Medical Submission",
            verificationStatus = "Verified"
        ),
        "demo_plc_stjohns_bpt_26" to PlacementRecord(
            id = "demo_plc_stjohns_bpt_26",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "BPT",
            specialization = "Bachelor of Physiotherapy",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 7.8,
            averagePackageLpa = 5.2,
            medianPackageLpa = 4.8,
            placementRatePercent = 91.0,
            eligibleStudents = 58L,
            participatingStudents = 55L,
            placedStudents = 50L,
            totalRecruiters = 18L,
            internshipStipendMonthlyInr = 12000L,
            topRecruiters = "St. John's Medical College Hospital, NIMHANS Rehab Unit, Hosmat Hospital, Nightingales Home Health",
            commonJobRoles = "Clinical Physiotherapist, Neuro-Rehab Specialist, Sports Rehab Consultant",
            sourceCitation = "St. John's Allied Health Placement Cell Record 2025-26",
            verificationStatus = "Verified"
        ),
        "demo_plc_stjohns_mpt_26" to PlacementRecord(
            id = "demo_plc_stjohns_mpt_26",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "MPT",
            specialization = "MPT Neurology & Psychosomatic Disorders",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "PG",
            offerScope = "Domestic",
            highestPackageLpa = 10.4,
            averagePackageLpa = 7.6,
            medianPackageLpa = 7.2,
            placementRatePercent = 100.0,
            eligibleStudents = 12L,
            participatingStudents = 12L,
            placedStudents = 12L,
            totalRecruiters = 9L,
            internshipStipendMonthlyInr = 18000L,
            topRecruiters = "St. John's PMR Dept, Sakra World Hospital Neuro Rehab, Apollo Rehab, RGUHS Teaching Cadre",
            commonJobRoles = "Senior Neuro-Physiotherapist, Assistant Professor (BPT/MPT), ICU Rehab Lead",
            sourceCitation = "St. John's PG Allied Health Outcome Audit 2025-26",
            verificationStatus = "Verified"
        ),
        "demo_plc_srm_bds_26" to PlacementRecord(
            id = "demo_plc_srm_bds_26",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "BDS",
            specialization = "Bachelor of Dental Surgery",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = -1.0, // Not Publicly Reported separately for BDS
            averagePackageLpa = 5.4,
            medianPackageLpa = 4.9,
            placementRatePercent = 76.5,
            eligibleStudents = 94L,
            participatingStudents = 68L,
            placedStudents = 52L,
            totalRecruiters = -1L, // Not Publicly Reported
            internshipStipendMonthlyInr = 15000L,
            topRecruiters = "Clove Dental, Sabka Dentist, Apollo White Dental, Private Practice & NEET-MDS Progression",
            commonJobRoles = "Associate Dental Surgeon, Clinical Resident, Healthcare Claims Analyst",
            sourceCitation = "NIRF 2026 Dental Category Median Salary Submission (Highest CTC Not Publicly Reported)",
            verificationStatus = "Institution-Claimed"
        ),
        "demo_plc_aiims_mbbs_26" to PlacementRecord(
            id = "demo_plc_aiims_mbbs_26",
            userId = userId,
            collegeId = "demo_col_aiims",
            collegeName = "[DEMO] All India Institute of Medical Sciences (AIIMS)",
            courseName = "MBBS",
            specialization = "General Medicine & Surgery",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 24.0,
            averagePackageLpa = 18.0,
            medianPackageLpa = 18.0,
            placementRatePercent = 100.0,
            eligibleStudents = 125L,
            participatingStudents = 125L,
            placedStudents = 125L,
            totalRecruiters = 15L,
            internshipStipendMonthlyInr = 30070L,
            topRecruiters = "AIIMS New Delhi Junior Residency, INI-CET PG Progression, ICMR Clinical Research",
            commonJobRoles = "Junior Resident (Academic/Non-Academic), INI-CET MD/MS Scholar",
            sourceCitation = "AIIMS New Delhi NIRF #1 Medical Report 2026",
            verificationStatus = "Verified"
        ),
        "demo_plc_christ_mba_26" to PlacementRecord(
            id = "demo_plc_christ_mba_26",
            userId = userId,
            collegeId = "demo_col_christ",
            collegeName = "[DEMO] Christ (Deemed to be University) Central Campus",
            courseName = "MBA",
            specialization = "Finance & Business Analytics",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "PG",
            offerScope = "Domestic",
            highestPackageLpa = 21.5,
            averagePackageLpa = 10.4,
            medianPackageLpa = 9.6,
            placementRatePercent = 91.8,
            eligibleStudents = 235L,
            participatingStudents = 220L,
            placedStudents = 202L,
            totalRecruiters = 135L,
            internshipStipendMonthlyInr = 35000L,
            topRecruiters = "Deloitte USI, EY GDS, KPMG, Wells Fargo, NatWest, Bain Capability Network",
            commonJobRoles = "Financial Analyst, Management Consultant, Risk Advisory Associate",
            sourceCitation = "Christ University School of Business & Management Placement Report 2025-26",
            verificationStatus = "Verified"
        )
    )

    /**
     * Module 7: Structured College Reviews & 7-Dimension Quality Analysis Seed Dataset
     * Strictly separates Public Third-Party Reviews from Internal Consultancy Observations.
     */
    fun buildDemoCollegeReviews(userId: String): List<Pair<String, CollegeReviewRecord>> = listOf(
        "demo_rev_kmc_public" to CollegeReviewRecord(
            id = "demo_rev_kmc_public",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseFocus = "MBBS & Allied Health",
            reviewCategory = "Public Third-Party Review",
            sourceName = "Shiksha / Careers360 / NIRF Public Feedback Aggregation",
            overallRating = 4.7,
            reviewCount = 342L,
            retrievedDate = "2026-10-25",
            positiveThemes = "World-class MARENA sports & simulation labs, 2,032-bed Kasturba Hospital clinical exposure, strong USMLE/PLAB alumni mentorship network, safe self-contained university town.",
            negativeThemes = "High annual tuition fee under Deemed General & NRI quotas ($50,800/yr); humid coastal monsoon weather from June to September.",
            recurringComplaints = "High cost of single AC hostel rooms and strict 85% clinical posting attendance enforcement.",
            academicExperienceRating = 4.8,
            infrastructureLabsRating = 4.9,
            facultyQualityRating = 4.7,
            hostelMessRating = 4.4,
            placementSupportRating = 4.6,
            clinicalPracticalRating = 4.9,
            campusLifeSupportRating = 4.8,
            dimensionEvidenceSummary = "1. Academic: CBME curriculum with USMLE-aligned digital pathology. 2. Labs: Advanced 3D anatomy & clinical skill simulation lab. 3. Faculty: Full-time MD/MS clinicians. 4. Hostel/Mess: Clean AC/Non-AC blocks with multi-cuisine food courts. 5. Placement/PG: High INI-CET/NEET-PG/USMLE conversion. 6. Clinical: 2,032 teaching beds with >3,200 daily OPD patients. 7. Campus Life: 24x7 library, student health insurance (Medicare).",
            isContextualAiSummary = false
        ),
        "demo_rev_kmc_internal" to CollegeReviewRecord(
            id = "demo_rev_kmc_internal",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseFocus = "MBBS",
            reviewCategory = "Internal Consultancy Observation",
            sourceName = "Senior Counsellor Field Audit & 14 Placed Parent Debriefs (2025-26 Batch)",
            overallRating = 4.8,
            reviewCount = 14L,
            retrievedDate = "2026-10-28",
            positiveThemes = "100% transparent fee receipt structure — zero hidden cash demands or off-receipt capitation charges; smooth MCC Deemed University reporting desk.",
            negativeThemes = "Zero fee concession for General Deemed quota unless candidate secures top NEET rank eligible for MAHE Kalam-Pai 100% scholarship.",
            recurringComplaints = "Parents must wire 1st-year installment immediately after MCC Round 1 allotment within 4 banking days.",
            academicExperienceRating = 4.8,
            infrastructureLabsRating = 4.9,
            facultyQualityRating = 4.8,
            hostelMessRating = 4.5,
            placementSupportRating = 4.7,
            clinicalPracticalRating = 4.9,
            campusLifeSupportRating = 4.8,
            dimensionEvidenceSummary = "Internal Consultancy Verification: Every rupee is receipted via official MAHE RTGS portal, making SBI/HDFC Premier Institute Education Loan sanction seamless up to ₹40 Lakhs without tangible collateral.",
            isContextualAiSummary = false
        ),
        "demo_rev_rvce_public" to CollegeReviewRecord(
            id = "demo_rev_rvce_public",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseFocus = "B.Tech CSE",
            reviewCategory = "Public Third-Party Review",
            sourceName = "CollegeDunia / Reddit r/Btechtards / Alumni Reviews",
            overallRating = 4.4,
            reviewCount = 518L,
            retrievedDate = "2026-10-24",
            positiveThemes = "Outstanding Tier-1 tech placements in Bengaluru (₹19.4L CSE average), strong coding culture, active technical clubs (Ashwa Racing, Astra Robotics), Metro connectivity at Mysuru Road gate.",
            negativeThemes = "Strict academic grading under autonomous VTU framework, ongoing campus construction in older blocks, Saturday half-day classes.",
            recurringComplaints = "Older hostel blocks have limited twin-sharing rooms; management quota fees have risen sharply to ₹16L/yr for CSE.",
            academicExperienceRating = 4.4,
            infrastructureLabsRating = 4.2,
            facultyQualityRating = 4.3,
            hostelMessRating = 3.7,
            placementSupportRating = 4.9,
            clinicalPracticalRating = 4.5,
            campusLifeSupportRating = 4.1,
            dimensionEvidenceSummary = "1. Academic: Autonomous syllabus updated with AI/Cloud electives; degree conferred by VTU. 2. Labs: Nvidia GPU & Cisco networking labs. 3. Faculty: Experienced PhD faculty. 4. Hostel/Mess: Functional vegetarian mess, moderate room size. 5. Placement: Top private engineering placement cell in Karnataka. 6. Practical: Mandatory 8th-sem industry internship. 7. Campus Life: High focus on technical competitions.",
            isContextualAiSummary = false
        ),
        "demo_rev_rvce_internal" to CollegeReviewRecord(
            id = "demo_rev_rvce_internal",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseFocus = "B.Tech CSE (Management & COMEDK Quota)",
            reviewCategory = "Internal Consultancy Observation",
            sourceName = "Consultancy Fee Audit Desk & 9 Admitted Student Debriefs",
            overallRating = 4.3,
            reviewCount = 9L,
            retrievedDate = "2026-10-27",
            positiveThemes = "Exceptional ROI for KCET (₹1.07L/yr) and COMEDK (₹2.89L/yr) merit entrants; strong placement parity across quotas once enrolled.",
            negativeThemes = "Management Quota circular includes ₹65,000/yr Autonomous Skill Lab & VTU Registration surcharge over base ₹16.00L tuition.",
            recurringComplaints = "Counsellors must explicitly inform parents that RVCE is an Autonomous College whose degree certificate is legally issued by VTU Belagavi, not an independent Private University.",
            academicExperienceRating = 4.4,
            infrastructureLabsRating = 4.2,
            facultyQualityRating = 4.3,
            hostelMessRating = 3.8,
            placementSupportRating = 4.9,
            clinicalPracticalRating = 4.5,
            campusLifeSupportRating = 4.0,
            dimensionEvidenceSummary = "Internal Audit Note: Flagged ₹65,000/yr skill lab surcharge in Module 5 OCR Lab; advise parents to budget ₹18.55L for 1st-year Management CSE including hostel.",
            isContextualAiSummary = false
        ),
        "demo_rev_stjohns_public" to CollegeReviewRecord(
            id = "demo_rev_stjohns_public",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseFocus = "BPT, MPT & B.Sc Nursing",
            reviewCategory = "Public Third-Party Review",
            sourceName = "Verified Healthcare Student Portal & RGUHS Alumni Network",
            overallRating = 4.6,
            reviewCount = 215L,
            retrievedDate = "2026-10-22",
            positiveThemes = "Unmatched hands-on patient inflow at 1,350-bed St. John's Hospital in Koramangala, very affordable tuition compared to deemed universities, deeply respected clinical training.",
            negativeThemes = "Rigorous RGUHS university examinations, compulsory rural/institutional service bond policies for medical/nursing tracks, strict ward dress code.",
            recurringComplaints = "High clinical workload during final-year BPT/Nursing postings and strict hostel curfew timings.",
            academicExperienceRating = 4.7,
            infrastructureLabsRating = 4.5,
            facultyQualityRating = 4.8,
            hostelMessRating = 4.1,
            placementSupportRating = 4.5,
            clinicalPracticalRating = 4.9,
            campusLifeSupportRating = 4.3,
            dimensionEvidenceSummary = "1. Academic: RGUHS curriculum with bedside clinical rounds from 2nd year. 2. Labs: Dedicated PMR gait lab, electrotherapy & neuro-rehab wings. 3. Faculty: Senior clinical professors. 4. Hostel/Mess: On-campus Koramangala hostels at ₹92,000/yr. 5. Placement: Near-100% absorption in tertiary hospitals. 6. Clinical: >2,400 daily OPD inflow. 7. Campus Life: Central Bengaluru location.",
            isContextualAiSummary = false
        ),
        "demo_rev_srm_internal" to CollegeReviewRecord(
            id = "demo_rev_srm_internal",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseFocus = "BDS & B.Optom",
            reviewCategory = "Internal Consultancy Observation",
            sourceName = "Chennai Campus Compliance Inspection (Oct 2026)",
            overallRating = 3.9,
            reviewCount = 6L,
            retrievedDate = "2026-10-26",
            positiveThemes = "Large 250-acre Kattankulathur township campus, modern dental phantom-head labs, integrated SRM General Hospital for B.Optom clinical rotations.",
            negativeThemes = "BDS circular adds ₹85,000/yr Dental Material & Clinical Chair fee not highlighted on initial MCC summary page; large batch sizes.",
            recurringComplaints = "Parents must verify exact hostel room tier (AC vs Non-AC) before paying booking fee as AC hostel adds ₹1.35L+/yr.",
            academicExperienceRating = 4.0,
            infrastructureLabsRating = 4.4,
            facultyQualityRating = 4.0,
            hostelMessRating = 3.8,
            placementSupportRating = 3.6,
            clinicalPracticalRating = 4.1,
            campusLifeSupportRating = 4.3,
            dimensionEvidenceSummary = "Internal Consultancy Advisory: Always disclose the ₹85,000/yr dental material kit charge upfront when comparing SRM BDS against RGUHS affiliated dental colleges.",
            isContextualAiSummary = false
        )
    )

    /**
     * Module 8: Admission Calendar, Deadlines & Alerts Seed Dataset
     * Includes Conflicting Notifications and Overdue Refresh Checks.
     */
    fun buildDemoAdmissionDeadlines(userId: String): List<Pair<String, AdmissionDeadlineRecord>> = listOf(
        "demo_ddl_kmc_mbbs" to AdmissionDeadlineRecord(
            id = "demo_ddl_kmc_mbbs",
            userId = userId,
            collegeId = "demo_col_kmc",
            collegeName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            courseName = "MBBS",
            quotaCategory = "All India Deemed / NRI (MCC)",
            academicYear = "2026-27",
            applicationOpenDate = "2026-08-01",
            applicationDeadline = "2026-08-20",
            entranceExamDate = "2026-05-03 (NEET-UG)",
            counsellingRound1Date = "2026-08-24 to 2026-08-31",
            counsellingRound2Date = "2026-09-18 to 2026-09-26",
            mopUpStrayRoundDate = "2026-10-15 to 2026-11-05 (Stray Vacancy)",
            documentVerificationDeadline = "2026-11-06 (Physical Reporting Manipal)",
            scholarshipDeadline = "2026-09-30 (MAHE Kalam-Pai Merit Waiver)",
            feePaymentWindow = "Within 4 banking days of MCC allotment letter via RTGS",
            sourceUrl = "https://mcc.nic.in",
            retrievalDate = "2026-10-28",
            verificationStatus = "Verified",
            hasConflict = false,
            conflictDetails = "",
            isOverdueRefresh = false
        ),
        "demo_ddl_rvce_cse" to AdmissionDeadlineRecord(
            id = "demo_ddl_rvce_cse",
            userId = userId,
            collegeId = "demo_col_rvce",
            collegeName = "[DEMO] R.V. College of Engineering (RVCE)",
            courseName = "B.Tech CSE",
            quotaCategory = "KEA KCET / COMEDK / Management",
            academicYear = "2026-27",
            applicationOpenDate = "2026-02-10",
            applicationDeadline = "2026-04-15",
            entranceExamDate = "2026-04-22 (KCET) / 2026-05-10 (COMEDK)",
            counsellingRound1Date = "2026-07-12 to 2026-07-20",
            counsellingRound2Date = "2026-08-08 to 2026-08-16",
            mopUpStrayRoundDate = "2026-09-05 to 2026-09-14 (Extended Round)",
            documentVerificationDeadline = "2026-09-16",
            scholarshipDeadline = "2026-10-31 (SSP Karnataka Post-Matric)",
            feePaymentWindow = "2026-09-06 to 2026-09-15 (KEA Challan / COMEDK Online)",
            sourceUrl = "https://cetonline.karnataka.gov.in/kea/",
            retrievalDate = "2026-10-27",
            verificationStatus = "Verified",
            hasConflict = true,
            conflictDetails = "CONFLICT ALERT: KEA Extended Round reporting date (Sept 16) overlaps with VTU 1st-Semester induction commencement notice (Sept 12) published on rvce.edu.in.",
            isOverdueRefresh = false
        ),
        "demo_ddl_stjohns_bpt" to AdmissionDeadlineRecord(
            id = "demo_ddl_stjohns_bpt",
            userId = userId,
            collegeId = "demo_col_stjohns",
            collegeName = "[DEMO] St. John's National Academy of Health Sciences",
            courseName = "BPT & MPT (Allied Health)",
            quotaCategory = "Institutional Merit & Lateral Entry",
            academicYear = "2026-27",
            applicationOpenDate = "2026-05-15",
            applicationDeadline = "2026-07-10",
            entranceExamDate = "2026-07-22 (St. John's AHS Entrance & Interview)",
            counsellingRound1Date = "2026-07-28",
            counsellingRound2Date = "2026-08-14",
            mopUpStrayRoundDate = "2026-11-08 (Lateral Entry Final Spot Verification)",
            documentVerificationDeadline = "2026-11-08 (RGUHS Eligibility Certificate Due)",
            scholarshipDeadline = "2026-09-15 (SJNAHS Need-cum-Merit Scholarship)",
            feePaymentWindow = "Within 72 hours of interview selection list",
            sourceUrl = "https://www.stjohns.in/medicalcollege/admissions",
            retrievalDate = "2026-09-10",
            verificationStatus = "Institution-Claimed",
            hasConflict = false,
            conflictDetails = "",
            isOverdueRefresh = true
        ),
        "demo_ddl_srm_bds" to AdmissionDeadlineRecord(
            id = "demo_ddl_srm_bds",
            userId = userId,
            collegeId = "demo_col_srm",
            collegeName = "[DEMO] SRM Institute of Science and Technology (SRMIST)",
            courseName = "BDS (Dental Surgery)",
            quotaCategory = "MCC Deemed Dental Quota",
            academicYear = "2026-27",
            applicationOpenDate = "2026-08-01",
            applicationDeadline = "2026-08-22",
            entranceExamDate = "2026-05-03 (NEET-UG)",
            counsellingRound1Date = "2026-08-25",
            counsellingRound2Date = "2026-09-20",
            mopUpStrayRoundDate = "2026-11-12 (Special Stray Vacancy Dental)",
            documentVerificationDeadline = "2026-11-14",
            scholarshipDeadline = "2026-09-15 (SRM Founder's Scholarship)",
            feePaymentWindow = "2026-11-10 to 2026-11-14",
            sourceUrl = "https://www.srmist.edu.in/admission-india/",
            retrievalDate = "2026-09-01",
            verificationStatus = "Outdated",
            hasConflict = true,
            conflictDetails = "CONFLICT ALERT: SRM Dental brochure lists Nov 10 physical reporting cutoff whereas MCC Dental Stray Vacancy schedule permits reporting until Nov 14, 17:00 IST.",
            isOverdueRefresh = true
        ),
        "demo_ddl_aiims_mbbs" to AdmissionDeadlineRecord(
            id = "demo_ddl_aiims_mbbs",
            userId = userId,
            collegeId = "demo_col_aiims",
            collegeName = "[DEMO] All India Institute of Medical Sciences (AIIMS)",
            courseName = "MBBS",
            quotaCategory = "MCC All-India Central Open",
            academicYear = "2026-27",
            applicationOpenDate = "2026-07-25",
            applicationDeadline = "2026-08-18",
            entranceExamDate = "2026-05-03 (NEET-UG)",
            counsellingRound1Date = "2026-08-22",
            counsellingRound2Date = "2026-09-16",
            mopUpStrayRoundDate = "2026-10-18",
            documentVerificationDeadline = "2026-09-25",
            scholarshipDeadline = "2026-10-30 (Central Sector National Scholarship)",
            feePaymentWindow = "At physical reporting (₹5,856 Total Course Fee)",
            sourceUrl = "https://www.aiimsexams.ac.in",
            retrievalDate = "2026-10-29",
            verificationStatus = "Verified",
            hasConflict = false,
            conflictDetails = "",
            isOverdueRefresh = false
        ),
        "demo_ddl_christ_mba" to AdmissionDeadlineRecord(
            id = "demo_ddl_christ_mba",
            userId = userId,
            collegeId = "demo_col_christ",
            collegeName = "[DEMO] Christ (Deemed to be University) Central Campus",
            courseName = "MBA",
            quotaCategory = "General / All-India Selection Process",
            academicYear = "2026-27",
            applicationOpenDate = "2026-11-01",
            applicationDeadline = "2027-01-28 (Session 1) / 2027-03-30 (Session 2)",
            entranceExamDate = "CAT Nov 2026 / XAT Jan 2027 / MAT Feb 2027",
            counsellingRound1Date = "2027-02-06 (Session 1 GD-MP-PI)",
            counsellingRound2Date = "2027-04-10 (Session 2 GD-MP-PI)",
            mopUpStrayRoundDate = "2027-05-15 (Waitlist Movement)",
            documentVerificationDeadline = "2027-05-25",
            scholarshipDeadline = "2027-06-15 (Alumni & Merit Scholarship)",
            feePaymentWindow = "Within 7 days of E-Offer Letter release",
            sourceUrl = "https://christuniversity.in/admission-all",
            retrievalDate = "2026-08-19",
            verificationStatus = "Outdated",
            hasConflict = false,
            conflictDetails = "",
            isOverdueRefresh = true
        )
    )

    /**
     * Module 12: Collaborative Team Tasks & Follow-ups Seed Dataset
     */
    fun buildDemoTeamTasks(userId: String): List<Pair<String, TeamTaskRecord>> = listOf(
        "demo_tsk_1" to TeamTaskRecord(
            id = "demo_tsk_1",
            userId = userId,
            title = "Resolve RVCE ₹50,000/yr Skill Lab Management Quota Discrepancy",
            taskType = "Discrepancy Resolution",
            assignedToName = "Rohan Deshpande",
            assignedToRole = "Fee Reviewer",
            priority = "Urgent",
            dueDate = "2026-11-02",
            linkedRecordType = "Fee Doc",
            linkedRecordId = "demo_fee_rvce_mgmt",
            linkedRecordName = "[DEMO] RVCE — B.Tech CSE Management Circular",
            status = "In Progress",
            notes = "Contact RSST Trust Accounts Office to confirm whether ₹50,000 Skill Lab charge is included in official bank loan fee demand letter."
        ),
        "demo_tsk_2" to TeamTaskRecord(
            id = "demo_tsk_2",
            userId = userId,
            title = "Obtain Signed SRM Dental ₹85,000/yr Clinical Consumable Annexure",
            taskType = "Fee Document Review",
            assignedToName = "Meenakshi Iyer",
            assignedToRole = "Senior Reviewer",
            priority = "High",
            dueDate = "2026-11-04",
            linkedRecordType = "Fee Doc",
            linkedRecordId = "demo_fee_srm_bds",
            linkedRecordName = "[DEMO] SRMIST — BDS Dental Fee Brochure",
            status = "Blocked",
            notes = "Blocked until SRM Kattankulathur Dental Admissions Office emails signed 2026-27 consumable fee breakdown."
        ),
        "demo_tsk_3" to TeamTaskRecord(
            id = "demo_tsk_3",
            userId = userId,
            title = "Complete MCC Stray Vacancy Counselling Follow-up for Aarav Nair",
            taskType = "Student Counselling Follow-up",
            assignedToName = "Ananya Rao",
            assignedToRole = "Counsellor",
            priority = "Urgent",
            dueDate = "2026-11-05",
            linkedRecordType = "Student",
            linkedRecordId = "demo_enq_1",
            linkedRecordName = "[DEMO] Aarav Nair (MBBS — NEET 594)",
            status = "To Do",
            notes = "Verify MCC choice locking order (1. KMC Manipal, 2. St. John's KEA Open) and upload Allotment Letter once released."
        ),
        "demo_tsk_4" to TeamTaskRecord(
            id = "demo_tsk_4",
            userId = userId,
            title = "Refresh Christ University 2026-27 MBA AICTE Extension of Approval (EoA)",
            taskType = "Research Job",
            assignedToName = "Karthik Subramanian",
            assignedToRole = "Researcher",
            priority = "Medium",
            dueDate = "2026-11-07",
            linkedRecordType = "College",
            linkedRecordId = "demo_col_christ",
            linkedRecordName = "[DEMO] Christ (Deemed to be University) Central Campus",
            status = "To Do",
            notes = "Run Module 3 Live Internet Research against aicte-india.org and christuniversity.in to update stale MBA fee & EoA record."
        ),
        "demo_tsk_5" to TeamTaskRecord(
            id = "demo_tsk_5",
            userId = userId,
            title = "Verify RGUHS BPT Lateral Entry Equivalency Deadline for Diya Deshmukh",
            taskType = "Student Counselling Follow-up",
            assignedToName = "Vikram Menon",
            assignedToRole = "Counsellor",
            priority = "High",
            dueDate = "2026-11-08",
            linkedRecordType = "Deadline",
            linkedRecordId = "demo_ddl_stjohns_bpt",
            linkedRecordName = "[DEMO] St. John's BPT Lateral Entry Spot Verification",
            status = "In Progress",
            notes = "Cross-check RGUHS eligibility application receipt before Nov 8 spot verification deadline."
        ),
        "demo_tsk_6" to TeamTaskRecord(
            id = "demo_tsk_6",
            userId = userId,
            title = "Audit KMC Manipal NIRF #9 & MCC Deemed Fee Parity",
            taskType = "Research Job",
            assignedToName = "Meenakshi Iyer",
            assignedToRole = "Senior Reviewer",
            priority = "Low",
            dueDate = "2026-10-28",
            linkedRecordType = "College",
            linkedRecordId = "demo_col_kmc",
            linkedRecordName = "[DEMO] Kasturba Medical College (KMC) Manipal",
            status = "Completed",
            notes = "Completed and approved in Module 15 Source Queue with 98% confidence score."
        )
    )

    /**
     * Module 14: Team Management & 6-Role Directory Seed Dataset
     */
    fun buildDemoTeamMembers(userId: String): List<Pair<String, TeamMemberRecord>> = listOf(
        "demo_mem_admin" to TeamMemberRecord(
            id = "demo_mem_admin",
            userId = userId,
            fullName = "Dr. Siddharth Hegde",
            email = "siddharth.hegde@eduintel.in",
            roleName = "Admin",
            department = "Principal Architecture & Governance",
            isActive = true,
            permissionsSummary = "Full CRUD across all 13 collections, Team & RBAC management, Record deletion, Locked App Settings audit",
            lastActiveDisplay = "Online — Active Now"
        ),
        "demo_mem_srv" to TeamMemberRecord(
            id = "demo_mem_srv",
            userId = userId,
            fullName = "Meenakshi Iyer",
            email = "meenakshi.iyer@eduintel.in",
            roleName = "Senior Reviewer",
            department = "Regulatory & Clinical Quality Assurance",
            isActive = true,
            permissionsSummary = "Approves Source Queue diffs, Regulatory verifications, Fee discrepancies, and 20-Point Briefing versions (No record deletion)",
            lastActiveDisplay = "Active 12 mins ago"
        ),
        "demo_mem_frv" to TeamMemberRecord(
            id = "demo_mem_frv",
            userId = userId,
            fullName = "Rohan Deshpande",
            email = "rohan.deshpande@eduintel.in",
            roleName = "Fee Reviewer",
            department = "Fee Circular OCR & Quota Audit Desk",
            isActive = true,
            permissionsSummary = "Runs Gemini 3.8 Flash Multimodal Fee OCR, audits Govt/COMEDK/Management/NRI fee structures, flags discrepancies",
            lastActiveDisplay = "Active 25 mins ago"
        ),
        "demo_mem_rsh" to TeamMemberRecord(
            id = "demo_mem_rsh",
            userId = userId,
            fullName = "Karthik Subramanian",
            email = "karthik.s@eduintel.in",
            roleName = "Researcher",
            department = "Higher Education & Placement Intelligence",
            isActive = true,
            permissionsSummary = "Runs Google Search Grounding (Module 3), queues source diffs, updates College/Course/Placement/Deadline records",
            lastActiveDisplay = "Active 1 hr ago"
        ),
        "demo_mem_cns" to TeamMemberRecord(
            id = "demo_mem_cns",
            userId = userId,
            fullName = "Ananya Rao",
            email = "ananya.rao@eduintel.in",
            roleName = "Counsellor",
            department = "Private Student Admissions & Shortlisting CRM",
            isActive = true,
            permissionsSummary = "Manages 9-stage Student CRM, runs Eligibility & Budget Matcher, logs call notes, exports PDF briefings & shortlists (Cannot approve fee records)",
            lastActiveDisplay = "Online — Active Now"
        ),
        "demo_mem_rov" to TeamMemberRecord(
            id = "demo_mem_rov",
            userId = userId,
            fullName = "Prakash Nair",
            email = "prakash.nair@eduintel.in",
            roleName = "Read-only Viewer",
            department = "External Compliance & Partner Audit",
            isActive = true,
            permissionsSummary = "Strict Read-Only inspection across all 17 modules; all create, edit, approve, and delete actions blocked",
            lastActiveDisplay = "Active Yesterday"
        )
    )
}

