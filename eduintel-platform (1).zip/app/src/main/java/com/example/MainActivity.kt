package com.example

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.AdmissionDeadlineRecord
import com.example.data.model.AuditLogEntry
import com.example.data.model.College
import com.example.data.model.CollegeBriefingVersion
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.ConsultancyModule
import com.example.data.model.ConsultancyRole
import com.example.data.model.Course
import com.example.data.model.FeeDocument
import com.example.data.model.PlacementRecord
import com.example.data.model.SourceVerificationItem
import com.example.data.model.StudentEnquiry
import com.example.data.model.TeamMemberRecord
import com.example.data.model.TeamTaskRecord
import com.example.data.repository.ConsultancyRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.components.CollegeEditorDialog
import com.example.ui.components.CourseEditorDialog
import com.example.ui.components.GlobalOmnisearchModal
import com.example.ui.components.PersistentAdmissionEnquiriesFooter
import com.example.ui.components.RoleSwitcherDialog
import com.example.ui.components.StudentEditorDialog
import com.example.ui.components.TaskEditorDialog
import com.example.ui.screens.AcceptanceTestSuiteDialog
import com.example.ui.screens.AdmissionCalendarDeadlinesScreen
import com.example.ui.screens.AiCollegeBriefingEngineScreen
import com.example.ui.screens.CollegeComparisonEngineScreen
import com.example.ui.screens.CollegeIntelligenceDatabaseScreen
import com.example.ui.screens.CollegeReviewsQualityScreen
import com.example.ui.screens.CourseCatalogMatrixScreen
import com.example.ui.screens.FeeOcrVerificationLabScreen
import com.example.ui.screens.LiveResearchEngineScreen
import com.example.ui.screens.OperationalDashboardScreen
import com.example.ui.screens.PlacementCareerOutcomesScreen
import com.example.ui.screens.PrivateStudentCrmScreen
import com.example.ui.screens.ReportsAndExportsScreen
import com.example.ui.screens.SourceVerificationQueueScreen
import com.example.ui.screens.SpecializedModuleScreen
import com.example.ui.screens.TeamManagementAndFeeMatrixScreen
import com.example.ui.screens.TeamTasksAndFollowUpsScreen
import com.example.ui.theme.AmberGold400
import com.example.ui.theme.DiscrepancyRose
import com.example.ui.theme.EduIntelTheme
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.viewmodel.ConsultancyViewModel
import com.example.ui.viewmodel.UiState
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        // STEP 2: Render Root UI with Auth Gate
        setContent {
            AppRoot()
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppRoot(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val effectiveUserId = currentUser?.uid ?: "admin_consultancy_workspace"
    val effectiveUserEmail = currentUser?.email ?: "admin@eduintel.in"
    val isCloudAuth = currentUser != null

    val viewModel: ConsultancyViewModel = viewModel(
        key = effectiveUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val prefs = app.getSharedPreferences("supabase_prefs", Context.MODE_PRIVATE)
                ConsultancyViewModel(
                    repository = ConsultancyRepository(db, auth),
                    currentUserId = effectiveUserId,
                    currentUserEmail = effectiveUserEmail,
                    isCloudAuthenticated = isCloudAuth,
                    sharedPrefs = prefs
                )
            }
        }
    )
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    EduIntelTheme(darkTheme = isDarkMode) {
        ConsultancyPlatformShell(viewModel = viewModel)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsultancyPlatformShell(viewModel: ConsultancyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val activeModule by viewModel.activeModule.collectAsStateWithLifecycle()
    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val showGlobalSearch by viewModel.showGlobalSearchModal.collectAsStateWithLifecycle()
    val globalSearchQuery by viewModel.globalSearchQuery.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val aiTaskState by viewModel.aiTaskState.collectAsStateWithLifecycle()

    // Filters
    val collegeSearch by viewModel.collegeSearchQuery.collectAsStateWithLifecycle()
    val stateFilter by viewModel.selectedStateFilter.collectAsStateWithLifecycle()
    val ownershipFilter by viewModel.selectedOwnershipFilter.collectAsStateWithLifecycle()
    val instTypeFilter by viewModel.selectedInstTypeFilter.collectAsStateWithLifecycle()
    val regulatorFilter by viewModel.selectedRegulatorFilter.collectAsStateWithLifecycle()
    val verificationFilter by viewModel.selectedVerificationFilter.collectAsStateWithLifecycle()
    val needsRefreshFilter by viewModel.onlyNeedsRefreshFilter.collectAsStateWithLifecycle()
    val streamFilter by viewModel.courseStreamFilter.collectAsStateWithLifecycle()
    val lateralFilter by viewModel.onlyLateralEntryFilter.collectAsStateWithLifecycle()
    val feeMaxLakhs by viewModel.feeMaxLakhsFilter.collectAsStateWithLifecycle()
    val feeDocStatusFilter by viewModel.feeDocStatusFilter.collectAsStateWithLifecycle()
    val enquiryOnlyDueToday by viewModel.enquiryOnlyDueToday.collectAsStateWithLifecycle()

    // Firestore Streams (All 13 Collections)
    val collegesState by viewModel.collegesState.collectAsStateWithLifecycle()
    val coursesState by viewModel.coursesState.collectAsStateWithLifecycle()
    val feeDocsState by viewModel.feeDocsState.collectAsStateWithLifecycle()
    val placementsState by viewModel.placementsState.collectAsStateWithLifecycle()
    val collegeReviewsState by viewModel.collegeReviewsState.collectAsStateWithLifecycle()
    val admissionDeadlinesState by viewModel.admissionDeadlinesState.collectAsStateWithLifecycle()
    val enquiriesState by viewModel.enquiriesState.collectAsStateWithLifecycle()
    val teamTasksState by viewModel.teamTasksState.collectAsStateWithLifecycle()
    val teamMembersState by viewModel.teamMembersState.collectAsStateWithLifecycle()
    val sourceQueueState by viewModel.sourceQueueState.collectAsStateWithLifecycle()
    val briefingVersionsState by viewModel.briefingVersionsState.collectAsStateWithLifecycle()
    val auditLogsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
    val appSettings by viewModel.appSettingsState.collectAsStateWithLifecycle()
    val showAcceptanceSuite by viewModel.showAcceptanceTestModal.collectAsStateWithLifecycle()
    val showAddCollegeModal by viewModel.showAddCollegeModal.collectAsStateWithLifecycle()
    val showAddCourseModal by viewModel.showAddCourseModal.collectAsStateWithLifecycle()
    val isSubmittingCourse by viewModel.isSubmittingCourse.collectAsStateWithLifecycle()
    val courseErrorAlert by viewModel.courseErrorAlert.collectAsStateWithLifecycle()
    val courseSuccessMessage by viewModel.courseSuccessMessage.collectAsStateWithLifecycle()
    val showAddStudentModal by viewModel.showAddStudentModal.collectAsStateWithLifecycle()
    val isSubmittingStudent by viewModel.isSubmittingStudent.collectAsStateWithLifecycle()
    val studentErrorAlert by viewModel.studentErrorAlert.collectAsStateWithLifecycle()
    val studentSuccessMessage by viewModel.studentSuccessMessage.collectAsStateWithLifecycle()
    val studentVaultDocuments by viewModel.studentVaultDocuments.collectAsStateWithLifecycle()
    val isUploadingStudentDocument by viewModel.isUploadingStudentDocument.collectAsStateWithLifecycle()
    val studentDocUploadError by viewModel.studentDocUploadError.collectAsStateWithLifecycle()
    val studentDocUploadSuccess by viewModel.studentDocUploadSuccess.collectAsStateWithLifecycle()
    val showAddTaskModal by viewModel.showAddTaskModal.collectAsStateWithLifecycle()
    val isSubmittingTask by viewModel.isSubmittingTask.collectAsStateWithLifecycle()
    val taskErrorAlert by viewModel.taskErrorAlert.collectAsStateWithLifecycle()
    val taskSuccessMessage by viewModel.taskSuccessMessage.collectAsStateWithLifecycle()
    val errorBannerMessage by viewModel.errorBannerMessage.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val supabaseUrl by viewModel.supabaseUrl.collectAsStateWithLifecycle()
    val supabaseAnonKey by viewModel.supabaseAnonKey.collectAsStateWithLifecycle()
    val geminiApiKey by viewModel.geminiApiKey.collectAsStateWithLifecycle()
    val ocrErrorAlert by viewModel.ocrErrorAlert.collectAsStateWithLifecycle()
    val feeSuccessMessage by viewModel.feeSuccessMessage.collectAsStateWithLifecycle()
    val isSupabaseConnected by viewModel.isSupabaseConnected.collectAsStateWithLifecycle()
    val supabaseStatusMessage by viewModel.supabaseStatusMessage.collectAsStateWithLifecycle()

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearToastMessage()
        }
    }

    val colleges = (collegesState as? UiState.Success<List<College>>)?.data ?: emptyList()
    val courses = (coursesState as? UiState.Success<List<Course>>)?.data ?: emptyList()
    val feeDocs = (feeDocsState as? UiState.Success<List<FeeDocument>>)?.data ?: emptyList()
    val placements = (placementsState as? UiState.Success<List<PlacementRecord>>)?.data ?: emptyList()
    val collegeReviews = (collegeReviewsState as? UiState.Success<List<CollegeReviewRecord>>)?.data ?: emptyList()
    val admissionDeadlines = (admissionDeadlinesState as? UiState.Success<List<AdmissionDeadlineRecord>>)?.data ?: emptyList()
    val enquiries = (enquiriesState as? UiState.Success<List<StudentEnquiry>>)?.data ?: emptyList()
    val teamTasks = (teamTasksState as? UiState.Success<List<TeamTaskRecord>>)?.data ?: emptyList()
    val teamMembers = (teamMembersState as? UiState.Success<List<TeamMemberRecord>>)?.data ?: emptyList()
    val sourceQueue = (sourceQueueState as? UiState.Success<List<SourceVerificationItem>>)?.data ?: emptyList()
    val briefingVersions = (briefingVersionsState as? UiState.Success<List<CollegeBriefingVersion>>)?.data ?: emptyList()
    val auditLogs = (auditLogsState as? UiState.Success<List<AuditLogEntry>>)?.data ?: emptyList()

    var showRoleDialog by remember { mutableStateOf(false) }
    var showRoleDropdown by remember { mutableStateOf(false) }

    // Mandatory BackHandler for custom state-switched navigation
    BackHandler(enabled = activeModule != ConsultancyModule.OPERATIONAL_DASHBOARD) {
        viewModel.navigateBack()
    }

    val groupedModules = remember {
        ConsultancyModule.entries.groupBy { it.category }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(310.dp)
                    .fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = AmberGold400
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("EduIntel Platform", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "17-Module Consultancy Suite",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Dedicated visible "Settings & Integrations" quick-access button in main sidebar menu
                    NavigationDrawerItem(
                        label = {
                            Column {
                                Text(
                                    text = "Settings & Integrations",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isSupabaseConnected) "Supabase Live Connected" else "Configure VITE_SUPABASE_URL & Key",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSupabaseConnected) VerifiedEmerald else AmberGold400
                                )
                            }
                        },
                        icon = {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "Settings & Integrations",
                                tint = if (isSupabaseConnected) VerifiedEmerald else AmberGold400
                            )
                        },
                        selected = activeModule == ConsultancyModule.RBAC_SECURITY_GOVERNANCE,
                        onClick = {
                            viewModel.navigateToModule(ConsultancyModule.RBAC_SECURITY_GOVERNANCE)
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(vertical = 2.dp)
                            .testTag("sidebar_settings_integrations_btn")
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // All 17 Routes in Sidebar grouped by category
                    groupedModules.forEach { (category, mods) ->
                        Text(
                            text = category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                        mods.forEach { mod ->
                            NavigationDrawerItem(
                                label = {
                                    Text(
                                        text = "${mod.number}. ${mod.title}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (activeModule == mod) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                selected = activeModule == mod,
                                onClick = {
                                    viewModel.navigateToModule(mod)
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier
                                    .padding(vertical = 1.dp)
                                    .testTag("nav_route_${mod.routeId}")
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Sign Out Button
                    NavigationDrawerItem(
                        label = { Text("Sign Out (${viewModel.currentUserEmail.take(18)})") },
                        icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign Out") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            signOutUser(context, onSignOutComplete = {}, scope = scope)
                        },
                        modifier = Modifier.testTag("sign_out_drawer_item")
                    )
                }
            }
        }
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        navigationIcon = {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("open_sidebar_btn")
                            ) {
                                Icon(Icons.Default.Menu, contentDescription = "Open 17-Module Sidebar")
                            }
                        },
                        title = {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${activeModule.number}. ${activeModule.shortTitle}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    // Live Firestore Sync Indicator
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(VerifiedEmerald)
                                    )
                                    Text(
                                        text = "LIVE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VerifiedEmerald
                                    )
                                }
                                Text(
                                    text = activeModule.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        },
                        actions = {
                            // Cmd+K Global Search Button
                            IconButton(
                                onClick = { viewModel.setShowGlobalSearch(true) },
                                modifier = Modifier.testTag("cmd_k_search_btn")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Cmd+K Global Search")
                            }

                            // 18-Point Acceptance Test Suite Button
                            IconButton(
                                onClick = { viewModel.setShowAcceptanceTestModal(true) },
                                modifier = Modifier.testTag("acceptance_test_suite_btn")
                            ) {
                                Icon(
                                    Icons.Default.VerifiedUser,
                                    contentDescription = "18-Point Acceptance Test Suite",
                                    tint = VerifiedEmerald
                                )
                            }

                            // Prominent Global RBAC Role Switcher Dropdown at the Top Navigation Bar
                            Box {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .clickable { showRoleDropdown = true }
                                        .testTag("active_role_badge_btn")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Security,
                                            contentDescription = "Active RBAC Role Switcher",
                                            tint = AmberGold400,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "Role: ${activeRole.label}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Icon(
                                            Icons.Default.ArrowDropDown,
                                            contentDescription = "Switch Role",
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                DropdownMenu(
                                    expanded = showRoleDropdown,
                                    onDismissRequest = { showRoleDropdown = false }
                                ) {
                                    val primaryRbacRoles = listOf(
                                        ConsultancyRole.ADMIN,
                                        ConsultancyRole.SENIOR_REVIEWER,
                                        ConsultancyRole.COUNSELLOR
                                    )
                                    primaryRbacRoles.forEach { roleOption ->
                                        val isSelected = activeRole == roleOption
                                        val accessTag = if (roleOption == ConsultancyRole.COUNSELLOR) "Read-Only" else "Read-Write"
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(
                                                        text = "${roleOption.label} ($accessTag)",
                                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        text = roleOption.description,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.Security,
                                                    contentDescription = roleOption.label,
                                                    tint = if (isSelected) VerifiedEmerald else AmberGold400
                                                )
                                            },
                                            onClick = {
                                                viewModel.setRole(roleOption)
                                                showRoleDropdown = false
                                            },
                                            modifier = Modifier.testTag("top_role_dropdown_item_${roleOption.name.lowercase()}")
                                        )
                                    }
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = "All Roles & RBAC Matrix...",
                                                style = MaterialTheme.typography.labelMedium
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Tune,
                                                contentDescription = "All Roles Matrix"
                                            )
                                        },
                                        onClick = {
                                            showRoleDropdown = false
                                            showRoleDialog = true
                                        },
                                        modifier = Modifier.testTag("top_role_dropdown_all_roles_btn")
                                    )
                                }
                            }

                            // Light / Dark Theme Toggle
                            IconButton(
                                onClick = { viewModel.toggleDarkMode() },
                                modifier = Modifier.testTag("theme_toggle_btn")
                            ) {
                                Icon(
                                    imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Toggle Light/Dark Theme"
                                )
                            }
                        }
                    )

                    // Universal Global Search Input in Top Navigation Bar (filters active view & respects RBAC)
                    val searchPlaceholder = when (activeModule) {
                        ConsultancyModule.STUDENT_ENQUIRY_CRM ->
                            "Global Search (${activeRole.label}): Filter students by name, email, or phone..."
                        ConsultancyModule.COLLEGE_INTELLIGENCE_DB ->
                            "Global Search (${activeRole.label}): Filter colleges by institution name, code, or city..."
                        ConsultancyModule.COURSE_CATALOG_MATRIX ->
                            "Global Search (${activeRole.label}): Filter courses by course name, degree, or college..."
                        ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK ->
                            "Global Search (${activeRole.label}): Filter tasks by description or student..."
                        else ->
                            "Global Search (${activeRole.label}): Filter active view (students, colleges, courses, tasks)..."
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .testTag("top_nav_global_search_container")
                    ) {
                        OutlinedTextField(
                            value = globalSearchQuery,
                            onValueChange = viewModel::setGlobalSearchQuery,
                            placeholder = {
                                Text(
                                    text = searchPlaceholder,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Search,
                                    contentDescription = "Universal Global Search",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            trailingIcon = {
                                if (globalSearchQuery.isNotBlank()) {
                                    IconButton(
                                        onClick = { viewModel.setGlobalSearchQuery("") },
                                        modifier = Modifier.testTag("clear_global_top_search_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Clear global search"
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("global_top_search_input")
                        )
                    }
                }
            },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Global Persistent Footer across all dashboard screens
                    PersistentAdmissionEnquiriesFooter()

                    val primaryTabs = listOf(
                        Triple(ConsultancyModule.OPERATIONAL_DASHBOARD, "Dashboard", Icons.Default.Dashboard),
                        Triple(ConsultancyModule.COLLEGE_INTELLIGENCE_DB, "Colleges", Icons.Default.AccountBalance),
                        Triple(ConsultancyModule.COURSE_CATALOG_MATRIX, "Courses", Icons.Default.MenuBook),
                        Triple(ConsultancyModule.STUDENT_ENQUIRY_CRM, "Students/Leads", Icons.Default.People),
                        Triple(ConsultancyModule.FEE_OCR_VERIFICATION_LAB, "Fee OCR", Icons.Default.DocumentScanner)
                    )
                    NavigationBar {
                        primaryTabs.forEach { (mod, label, icon) ->
                            NavigationBarItem(
                                selected = activeModule == mod,
                                onClick = { viewModel.navigateToModule(mod) },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("bottom_tab_${mod.routeId}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Always-Visible Top Menu Bar to switch between all 17 modules including Settings & Integrations + Role Switcher
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("top_17_module_menu_bar")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Open Full 17-Module Sidebar Drawer Button
                        FilterChip(
                            selected = false,
                            onClick = { scope.launch { drawerState.open() } },
                            label = {
                                Text(
                                    text = "All 17 Modules",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Menu,
                                    contentDescription = "Open 17-Module Sidebar",
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            modifier = Modifier.testTag("open_sidebar_btn_strip")
                        )

                        // Dedicated "+ Add College" and "+ Add Course" Quick-Action Buttons in Top Menu Bar (Hidden for Read-Only Counselor)
                        if (activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
                            FilterChip(
                                selected = showAddCollegeModal,
                                onClick = { viewModel.setShowAddCollegeModal(true) },
                                label = {
                                    Text(
                                        text = "+ Add College",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("top_menu_add_college_btn")
                            )

                            FilterChip(
                                selected = showAddCourseModal,
                                onClick = { viewModel.setShowAddCourseModal(true) },
                                label = {
                                    Text(
                                        text = "+ Add Course",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("top_menu_add_course_btn")
                            )
                        }

                        if (activeRole.canManageEnquiries) {
                            FilterChip(
                                selected = showAddStudentModal,
                                onClick = { viewModel.setShowAddStudentModal(true) },
                                label = {
                                    Text(
                                        text = "+ Add Student",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("top_menu_add_student_btn")
                            )

                            FilterChip(
                                selected = showAddTaskModal,
                                onClick = { viewModel.setShowAddTaskModal(true) },
                                label = {
                                    Text(
                                        text = "+ Add Task",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("top_menu_add_task_btn")
                            )
                        }

                        // Dedicated Settings & Integrations Quick-Access Button in Top Menu Bar
                        FilterChip(
                            selected = activeModule == ConsultancyModule.RBAC_SECURITY_GOVERNANCE,
                            onClick = {
                                viewModel.navigateToModule(ConsultancyModule.RBAC_SECURITY_GOVERNANCE)
                            },
                            label = {
                                Text(
                                    text = "Settings & Integrations",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Settings,
                                    contentDescription = "Settings & Integrations",
                                    tint = if (isSupabaseConnected) VerifiedEmerald else AmberGold400,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.testTag("top_menu_settings_integrations_btn")
                        )

                        // All 17 Modules Directly Switchable in the Top Menu Bar
                        ConsultancyModule.entries.forEach { mod ->
                            FilterChip(
                                selected = activeModule == mod,
                                onClick = { viewModel.navigateToModule(mod) },
                                label = {
                                    Text(
                                        text = "${mod.number}. ${mod.shortTitle}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (activeModule == mod) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("top_module_chip_${mod.routeId}")
                            )
                        }
                    }
                }

                // Visible Red Banner for Supabase Errors
                if (errorBannerMessage != null) {
                    Surface(
                        color = DiscrepancyRose.copy(alpha = 0.2f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DiscrepancyRose)
                            .testTag("supabase_error_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = errorBannerMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = DiscrepancyRose,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearErrorBanner() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss Supabase error",
                                    tint = DiscrepancyRose,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Status/RBAC/Supabase Success Feedback Banner
                if (bannerMessage != null) {
                    val isSupabaseSuccess = bannerMessage!!.startsWith("SUCCESS!") ||
                        bannerMessage!!.contains("College added to Supabase successfully!") ||
                        bannerMessage!!.contains("Course added to Supabase successfully!") ||
                        bannerMessage!!.contains("Student added to Supabase successfully!") ||
                        bannerMessage!!.contains("Task added to Supabase successfully!") ||
                        bannerMessage!!.contains("Fee structure saved")
                    Surface(
                        color = if (isSupabaseSuccess) VerifiedEmerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("status_feedback_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = bannerMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isSupabaseSuccess) VerifiedEmerald else MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = if (isSupabaseSuccess) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearBanner() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss notification",
                                    tint = if (isSupabaseSuccess) VerifiedEmerald else MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Stream Loading / Error Banner if applicable
                if (collegesState is UiState.Loading && colleges.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Syncing Indian Higher Education Cloud Workspace...")
                        }
                    }
                } else {
                    when (activeModule) {
                        ConsultancyModule.OPERATIONAL_DASHBOARD -> OperationalDashboardScreen(
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            enquiries = enquiries,
                            tasks = teamTasks,
                            activeRole = activeRole,
                            globalSearchQuery = globalSearchQuery,
                            onKpiClicked = viewModel::onKpiCardClicked,
                            onNavigateModule = viewModel::navigateToModule,
                            onReseedDemo = viewModel::reseedDemoData,
                            onOpenAddCollegeModal = { viewModel.setShowAddCollegeModal(true) },
                            onOpenAddCourseModal = { viewModel.setShowAddCourseModal(true) },
                            onOpenAddStudentModal = { viewModel.setShowAddStudentModal(true) },
                            onOpenAddTaskModal = { viewModel.setShowAddTaskModal(true) },
                            onRefreshDashboard = viewModel::refreshDashboardFromSupabase
                        )
                        ConsultancyModule.COLLEGE_INTELLIGENCE_DB -> CollegeIntelligenceDatabaseScreen(
                            colleges = colleges,
                            courses = courses,
                            activeRole = activeRole,
                            searchQuery = collegeSearch,
                            onSearchQueryChange = viewModel::updateCollegeSearch,
                            selectedState = stateFilter,
                            onStateChange = viewModel::updateStateFilter,
                            selectedOwnership = ownershipFilter,
                            onOwnershipChange = viewModel::updateOwnershipFilter,
                            selectedInstType = instTypeFilter,
                            onInstTypeChange = viewModel::updateInstTypeFilter,
                            selectedRegulator = regulatorFilter,
                            onRegulatorChange = viewModel::updateRegulatorFilter,
                            selectedVerification = verificationFilter,
                            onVerificationChange = viewModel::updateVerificationFilter,
                            onlyNeedsRefresh = needsRefreshFilter,
                            onNeedsRefreshChange = viewModel::updateNeedsRefreshFilter,
                            onResetFilters = viewModel::resetFilters,
                            onSaveCollege = viewModel::addOrUpdateCollege,
                            onVerifyStatus = viewModel::verifyCollegeStatus,
                            onDeleteCollege = viewModel::deleteCollege,
                            enquiryHeader = appSettings.enquiryHeader,
                            enquiryPhone = appSettings.enquiryPhone
                        )
                        ConsultancyModule.LIVE_RESEARCH_ENGINE -> LiveResearchEngineScreen(
                            colleges = colleges,
                            courses = courses,
                            sourceQueue = sourceQueue,
                            activeRole = activeRole,
                            aiTaskState = aiTaskState,
                            onRunLiveResearch = viewModel::runLiveInternetResearch,
                            onPushToSourceQueue = viewModel::pushResearchFindingToSourceQueue,
                            onNavigateToSourceQueue = {
                                viewModel.navigateToModule(ConsultancyModule.SOURCE_VERIFICATION_QUEUE)
                            }
                        )
                        ConsultancyModule.COURSE_CATALOG_MATRIX -> CourseCatalogMatrixScreen(
                            courses = courses,
                            colleges = colleges,
                            activeRole = activeRole,
                            globalSearchQuery = globalSearchQuery,
                            onGlobalSearchQueryChange = viewModel::setGlobalSearchQuery,
                            selectedStream = streamFilter,
                            onStreamChange = viewModel::updateCourseStreamFilter,
                            onlyLateralEntry = lateralFilter,
                            onLateralEntryChange = viewModel::updateLateralEntryFilter,
                            maxFeeLakhs = feeMaxLakhs,
                            onMaxFeeLakhsChange = viewModel::updateFeeMaxLakhsFilter,
                            onAddCourse = { viewModel.addOrUpdateCourse(it, isEdit = false) },
                            onToggleLateralEntry = viewModel::toggleCourseLateralEntry,
                            showAddCourseModal = showAddCourseModal,
                            onSetShowAddCourseModal = viewModel::setShowAddCourseModal,
                            isSubmittingCourse = isSubmittingCourse,
                            courseErrorAlert = courseErrorAlert,
                            onDismissCourseErrorAlert = viewModel::clearCourseErrorAlert,
                            courseSuccessMessage = courseSuccessMessage,
                            onDismissCourseSuccessMessage = viewModel::clearCourseSuccessMessage,
                            onCreateCourseInSupabase = viewModel::createCourseInSupabase,
                            onRefreshFromSupabase = {
                                viewModel.fetchCollegesFromSupabase()
                                viewModel.fetchCoursesFromSupabase()
                            }
                        )
                        ConsultancyModule.REGULATORY_APPROVAL_TRACKER -> AdmissionCalendarDeadlinesScreen(
                            deadlines = admissionDeadlines,
                            colleges = colleges,
                            courses = courses,
                            activeRole = activeRole,
                            onAddDeadline = { viewModel.addOrUpdateAdmissionDeadline(it, isEdit = false) },
                            onCreateReminderTask = viewModel::createReminderTaskFromDeadline,
                            onVerifyCollege = viewModel::verifyCollegeStatus
                        )
                        ConsultancyModule.FEE_OCR_VERIFICATION_LAB -> FeeOcrVerificationLabScreen(
                            colleges = colleges,
                            feeDocs = feeDocs,
                            activeRole = activeRole,
                            feeDocStatusFilter = feeDocStatusFilter,
                            onFeeDocStatusFilterChange = viewModel::updateFeeDocStatusFilter,
                            aiTaskState = aiTaskState,
                            ocrErrorAlert = ocrErrorAlert,
                            onDismissOcrErrorAlert = viewModel::clearOcrErrorAlert,
                            feeSuccessMessage = feeSuccessMessage,
                            onDismissFeeSuccessMessage = viewModel::clearFeeSuccessMessage,
                            onRunOcr = viewModel::runMultimodalFeeOcr,
                            onSaveOcrResult = viewModel::saveOcrExtractedFeeDocument,
                            onUpdateReviewStatus = viewModel::updateFeeDocReviewStatus
                        )
                        ConsultancyModule.PLACEMENT_CAREER_OUTCOMES -> PlacementCareerOutcomesScreen(
                            colleges = colleges,
                            courses = courses,
                            placements = placements,
                            activeRole = activeRole,
                            onAddPlacementRecord = { viewModel.addOrUpdatePlacementRecord(it, isEdit = false) }
                        )
                        ConsultancyModule.COLLEGE_REVIEWS_ANALYSIS -> CollegeReviewsQualityScreen(
                            colleges = colleges,
                            reviews = collegeReviews,
                            activeRole = activeRole,
                            aiTaskState = aiTaskState,
                            onRunAiThemeSummarizer = viewModel::runAiReviewThemeSummarizer,
                            onSaveReviewRecord = viewModel::addCollegeReviewRecord
                        )
                        ConsultancyModule.COLLEGE_COMPARISON_ENGINE -> CollegeComparisonEngineScreen(
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            placements = placements,
                            reviews = collegeReviews,
                            sourceQueue = sourceQueue,
                            appSettings = appSettings
                        )
                        ConsultancyModule.STUDENT_ENQUIRY_CRM -> PrivateStudentCrmScreen(
                            enquiries = enquiries,
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            appSettings = appSettings,
                            activeRole = activeRole,
                            globalSearchQuery = globalSearchQuery,
                            onGlobalSearchQueryChange = viewModel::setGlobalSearchQuery,
                            onlyDueToday = enquiryOnlyDueToday,
                            onToggleOnlyDueToday = viewModel::updateEnquiryOnlyDueToday,
                            onAddEnquiry = { viewModel.addOrUpdateEnquiry(it, isEdit = false) },
                            onUpdateStage = viewModel::updateEnquiryStage,
                            onUpdateProfileAndShortlist = { enq, meta, shortlist ->
                                viewModel.updateStudentProfileAndShortlist(enq, meta, shortlist)
                            },
                            computeMatchedColleges = { student ->
                                viewModel.computeMatchedCollegesForStudent(student, colleges, courses, feeDocs)
                            },
                            showAddStudentModal = showAddStudentModal,
                            onSetShowAddStudentModal = viewModel::setShowAddStudentModal,
                            isSubmittingStudent = isSubmittingStudent,
                            studentErrorAlert = studentErrorAlert,
                            onDismissStudentErrorAlert = viewModel::clearStudentErrorAlert,
                            studentSuccessMessage = studentSuccessMessage,
                            onDismissStudentSuccessMessage = viewModel::clearStudentSuccessMessage,
                            onCreateStudentInSupabase = viewModel::createStudentInSupabase,
                            onRefreshStudentsFromSupabase = {
                                viewModel.fetchCollegesFromSupabase()
                                viewModel.fetchCoursesFromSupabase()
                                viewModel.fetchStudentsFromSupabase()
                            },
                            studentVaultDocuments = studentVaultDocuments,
                            isUploadingStudentDocument = isUploadingStudentDocument,
                            studentDocUploadError = studentDocUploadError,
                            onDismissStudentDocUploadError = viewModel::clearStudentDocUploadError,
                            studentDocUploadSuccess = studentDocUploadSuccess,
                            onDismissStudentDocUploadSuccess = viewModel::clearStudentDocUploadSuccess,
                            onFetchStudentDocuments = viewModel::fetchStudentDocumentsFromStorage,
                            onUploadStudentDocument = viewModel::uploadStudentDocumentToSupabase
                        )
                        ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK -> TeamTasksAndFollowUpsScreen(
                            tasks = teamTasks,
                            colleges = colleges,
                            courses = courses,
                            teamMembers = teamMembers,
                            activeRole = activeRole,
                            globalSearchQuery = globalSearchQuery,
                            onAddTask = { viewModel.addOrUpdateTeamTask(it, isEdit = false) },
                            onUpdateTaskStatus = viewModel::updateTeamTaskStatus,
                            onDeleteTask = viewModel::deleteTeamTask,
                            enquiries = enquiries,
                            showAddTaskModal = showAddTaskModal,
                            onSetShowAddTaskModal = viewModel::setShowAddTaskModal,
                            isSubmittingTask = isSubmittingTask,
                            taskErrorAlert = taskErrorAlert,
                            onDismissTaskErrorAlert = viewModel::clearTaskErrorAlert,
                            taskSuccessMessage = taskSuccessMessage,
                            onDismissTaskSuccessMessage = viewModel::clearTaskSuccessMessage,
                            onCreateTaskInSupabase = viewModel::createTaskInSupabase,
                            onRefreshTasksFromSupabase = {
                                viewModel.fetchStudentsFromSupabase()
                                viewModel.fetchTasksFromSupabase()
                            }
                        )
                        ConsultancyModule.QUOTA_FEE_COMPARATOR -> TeamManagementAndFeeMatrixScreen(
                            teamMembers = teamMembers,
                            courses = courses,
                            feeDocs = feeDocs,
                            appSettings = appSettings,
                            activeRole = activeRole,
                            onSelectSessionRole = viewModel::setRole,
                            onAddTeamMember = { viewModel.addOrUpdateTeamMember(it, isEdit = false) },
                            onUpdateMemberRole = viewModel::updateTeamMemberRole,
                            onToggleMemberActive = viewModel::toggleTeamMemberActive,
                            onUpdateFeeDocStatus = viewModel::updateFeeDocReviewStatus,
                            onOpenAcceptanceSuite = { viewModel.setShowAcceptanceTestModal(true) }
                        )
                        ConsultancyModule.AI_COLLEGE_BRIEFINGS -> AiCollegeBriefingEngineScreen(
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            sourceQueue = sourceQueue,
                            briefingVersions = briefingVersions,
                            appSettings = appSettings,
                            activeRole = activeRole,
                            onSaveBriefingVersion = viewModel::saveNewBriefingVersion,
                            onNavigateToExports = {
                                viewModel.navigateToModule(ConsultancyModule.CONSULTANCY_EXPORT_REPORTS)
                            }
                        )
                        ConsultancyModule.CONSULTANCY_EXPORT_REPORTS -> ReportsAndExportsScreen(
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            sourceQueue = sourceQueue,
                            appSettings = appSettings
                        )
                        ConsultancyModule.SOURCE_VERIFICATION_QUEUE -> SourceVerificationQueueScreen(
                            sourceQueue = sourceQueue,
                            colleges = colleges,
                            courses = courses,
                            activeRole = activeRole,
                            onResolveQueueItem = viewModel::resolveSourceQueueItem,
                            onNavigateToLiveResearch = {
                                viewModel.navigateToModule(ConsultancyModule.LIVE_RESEARCH_ENGINE)
                            }
                        )
                        else -> SpecializedModuleScreen(
                            module = activeModule,
                            colleges = colleges,
                            courses = courses,
                            feeDocs = feeDocs,
                            enquiries = enquiries,
                            auditLogs = auditLogs,
                            appSettings = appSettings,
                            sourceQueueCount = sourceQueue.size,
                            briefingsCount = briefingVersions.size,
                            placementsCount = placements.size,
                            reviewsCount = collegeReviews.size,
                            deadlinesCount = admissionDeadlines.size,
                            tasksCount = teamTasks.size,
                            teamMembersCount = teamMembers.size,
                            activeRole = activeRole,
                            onSelectRole = viewModel::setRole,
                            aiTaskState = aiTaskState,
                            onRunGroundingStream = viewModel::runRegulatoryGroundingStream,
                            onUpdateFeeDocStatus = viewModel::updateFeeDocReviewStatus,
                            onVerifyCollegeStatus = viewModel::verifyCollegeStatus,
                            onOpenAcceptanceSuite = { viewModel.setShowAcceptanceTestModal(true) },
                            supabaseUrl = supabaseUrl,
                            supabaseAnonKey = supabaseAnonKey,
                            geminiApiKey = geminiApiKey,
                            isSupabaseConnected = isSupabaseConnected,
                            supabaseStatusMessage = supabaseStatusMessage,
                            onSaveSupabaseKeys = viewModel::saveSupabaseKeys,
                            onSaveGeminiApiKey = viewModel::saveGeminiApiKey,
                            onDisconnectSupabaseKeys = viewModel::disconnectSupabaseKeys
                        )
                    }
                }
            }
        }
    }

    if (showRoleDialog) {
        RoleSwitcherDialog(
            activeRole = activeRole,
            onSelectRole = viewModel::setRole,
            onDismiss = { showRoleDialog = false }
        )
    }

    if (showGlobalSearch) {
        GlobalOmnisearchModal(
            query = globalSearchQuery,
            onQueryChange = viewModel::setGlobalSearchQuery,
            colleges = colleges,
            courses = courses,
            feeDocs = feeDocs,
            enquiries = enquiries,
            activeRole = activeRole,
            onNavigateModule = viewModel::navigateToModule,
            onSelectCollegeSearch = viewModel::updateCollegeSearch,
            onDismiss = { viewModel.setShowGlobalSearch(false) }
        )
    }

    if (showAcceptanceSuite) {
        val suiteResults = remember(
            colleges, courses, feeDocs, sourceQueue, briefingVersions,
            placements, collegeReviews, admissionDeadlines, enquiries,
            teamTasks, teamMembers, appSettings
        ) {
            viewModel.evaluate18PointAcceptanceTests(
                colleges = colleges,
                courses = courses,
                feeDocs = feeDocs,
                sourceQueue = sourceQueue,
                briefings = briefingVersions,
                placements = placements,
                reviews = collegeReviews,
                deadlines = admissionDeadlines,
                enquiries = enquiries,
                tasks = teamTasks,
                teamMembers = teamMembers,
                appSettings = appSettings
            )
        }
        AcceptanceTestSuiteDialog(
            results = suiteResults,
            activeRole = activeRole,
            onSelectRole = viewModel::setRole,
            appSettings = appSettings,
            onDismiss = { viewModel.setShowAcceptanceTestModal(false) }
        )
    }

    if (showAddCollegeModal && activeRole != ConsultancyRole.COUNSELLOR && activeRole.canManageColleges) {
        CollegeEditorDialog(
            initialCollege = null,
            onSave = viewModel::addOrUpdateCollege,
            onDismiss = { viewModel.setShowAddCollegeModal(false) }
        )
    }

    if (showAddCourseModal &&
        activeRole != ConsultancyRole.COUNSELLOR &&
        activeRole.canManageColleges &&
        activeModule != ConsultancyModule.COURSE_CATALOG_MATRIX
    ) {
        CourseEditorDialog(
            colleges = colleges,
            isSubmitting = isSubmittingCourse,
            supabaseErrorAlert = courseErrorAlert,
            onSubmitCourse = viewModel::createCourseInSupabase,
            onDismiss = { viewModel.setShowAddCourseModal(false) }
        )
    }

    if (showAddStudentModal &&
        activeRole.canManageEnquiries &&
        activeModule != ConsultancyModule.STUDENT_ENQUIRY_CRM
    ) {
        StudentEditorDialog(
            colleges = colleges,
            courses = courses,
            isSubmitting = isSubmittingStudent,
            supabaseErrorAlert = studentErrorAlert,
            onSubmitStudent = viewModel::createStudentInSupabase,
            onDismiss = { viewModel.setShowAddStudentModal(false) }
        )
    }

    if (showAddTaskModal &&
        activeRole != ConsultancyRole.READ_ONLY_VIEWER &&
        activeModule != ConsultancyModule.ALLIED_HEALTH_COUNCIL_DESK
    ) {
        TaskEditorDialog(
            students = enquiries,
            isSubmitting = isSubmittingTask,
            supabaseErrorAlert = taskErrorAlert,
            onSubmitTask = viewModel::createTaskInSupabase,
            onDismiss = { viewModel.setShowAddTaskModal(false) }
        )
    }
}
