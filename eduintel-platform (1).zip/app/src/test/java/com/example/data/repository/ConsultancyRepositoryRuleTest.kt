package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AdmissionDeadlineRecord
import com.example.data.model.AppSettingsRecord
import com.example.data.model.College
import com.example.data.model.CollegeReviewRecord
import com.example.data.model.PlacementRecord
import com.example.data.model.SourceVerificationItem
import com.example.data.model.TeamMemberRecord
import com.example.data.model.TeamTaskRecord
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class ConsultancyRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun sampleCollege(id: String) = College(
        id = id,
        name = "Manipal College of Health Professions",
        shortCode = "MCHP-MPL",
        state = "Karnataka",
        city = "Manipal",
        ownership = "Private Unaided",
        institutionType = "Deemed-to-be University",
        degreeAwardingUniversity = "Manipal Academy of Higher Education (MAHE)",
        affiliatedTo = "MAHE Constituent",
        establishedYear = 1999L,
        websiteUrl = "https://manipal.edu/mchp-manipal.html",
        verificationStatus = "Verified",
        naacGrade = "A++",
        naacCgpa = 3.65,
        nirfRank = 9L,
        regulators = listOf("UGC", "IAP", "NAAC"),
        regulatorDetailsSummary = "Verified BPT, MPT & B.Optom programs under MAHE.",
        needsRefresh = false,
        isDemo = false
    )

    @Test
    fun createAndObserveCollege_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = ConsultancyRepository(firestore, auth)
        val docId = "col_${UUID.randomUUID().toString().take(8)}"

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createCollege(sampleCollege(docId))
        }
        assertTrue(createResult.isSuccess)
        assertEquals(docId, createResult.getOrThrow())

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeColleges(aliceUid).first { list -> list.any { it.id == docId } }
        }
        assertTrue(emitted.any { it.id == docId })
    }

    @Test
    fun createAndObserveSourceQueueAndAppSettings_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = ConsultancyRepository(firestore, auth)
        val sqId = "sq_${UUID.randomUUID().toString().take(8)}"
        val settingsId = "set_${UUID.randomUUID().toString().take(8)}"

        val sqItem = SourceVerificationItem(
            id = sqId,
            collegeId = "col_kmc",
            collegeName = "KMC Manipal",
            courseName = "MBBS",
            researchTarget = "Check NIRF/NAAC Accreditation",
            fieldKey = "regulatorDetailsSummary",
            previousValue = "NMC 250 MBBS seats",
            extractedValue = "NIRF Rank #9 Medical, NMC 250 seats verified",
            sourceTitle = "NIRF India Rankings",
            sourceUrl = "https://www.nirfindia.org/",
            sourceType = "Government/Regulator Portal",
            academicYear = "2026-27",
            confidenceScore = 97L,
            hasContradiction = false,
            contradictionNote = "",
            verificationStatus = "Pending Verification",
            retrievedAtIso = "2026-10-29 10:30 IST"
        )

        val sqResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createSourceQueueItem(sqItem)
        }
        assertTrue("sqResult failed: ${sqResult.exceptionOrNull()}", sqResult.isSuccess)

        val settingsResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createAppSettings(AppSettingsRecord(id = settingsId))
        }
        assertTrue("settingsResult failed: ${settingsResult.exceptionOrNull()}", settingsResult.isSuccess)

        val emittedQueue = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSourceQueue(aliceUid).first { list -> list.any { it.id == sqId } }
        }
        assertTrue(emittedQueue.any { it.id == sqId })

        val emittedSettings = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeAppSettings(aliceUid).first { it.id == settingsId }
        }
        assertEquals("ADMISSION ENQUIRIES", emittedSettings.enquiryHeader)
        assertEquals("+91 70122 74141", emittedSettings.enquiryPhone)
    }

    @Test
    fun createAndObservePlacementsAndReviews_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = ConsultancyRepository(firestore, auth)
        val plId = "pl_${UUID.randomUUID().toString().take(8)}"
        val revId = "rev_${UUID.randomUUID().toString().take(8)}"

        val placement = PlacementRecord(
            id = plId,
            collegeId = "demo_col_rvce",
            collegeName = "R.V. College of Engineering",
            courseName = "B.E.",
            specialization = "Computer Science & Engineering",
            academicYear = "2025-26",
            scopeType = "Course-Specific",
            levelType = "UG",
            offerScope = "Domestic",
            highestPackageLpa = 62.0,
            averagePackageLpa = 19.4,
            medianPackageLpa = 17.5,
            placementRatePercent = 94.2,
            eligibleStudents = 210L,
            participatingStudents = 198L,
            placedStudents = 186L,
            totalRecruiters = 142L,
            internshipStipendMonthlyInr = 75000L,
            topRecruiters = "Microsoft, SAP Labs, Qualcomm",
            commonJobRoles = "Software Development Engineer",
            sourceCitation = "RVCE Placement Cell 2025-26",
            verificationStatus = "Verified"
        )

        val plResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createPlacementRecord(placement)
        }
        assertTrue("plResult failed: ${plResult.exceptionOrNull()}", plResult.isSuccess)

        val review = CollegeReviewRecord(
            id = revId,
            collegeId = "demo_col_kmc",
            collegeName = "Kasturba Medical College Manipal",
            courseFocus = "MBBS & Allied Health",
            reviewCategory = "Internal Consultancy Observation",
            sourceName = "EduIntel Medical Counsellor Field Audit",
            overallRating = 4.6,
            reviewCount = 38L,
            retrievedDate = "2026-10-29",
            positiveThemes = "2,032-bed teaching hospital clinical exposure.",
            negativeThemes = "High Deemed University fee band.",
            recurringComplaints = "Strict 85% clinical attendance requirement.",
            academicExperienceRating = 4.8,
            infrastructureLabsRating = 4.7,
            facultyQualityRating = 4.6,
            hostelMessRating = 4.3,
            placementSupportRating = 4.5,
            clinicalPracticalRating = 4.9,
            campusLifeSupportRating = 4.4,
            dimensionEvidenceSummary = "Evaluated across all 7 clinical and campus dimensions.",
            isContextualAiSummary = false
        )

        val revResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createCollegeReviewRecord(review)
        }
        assertTrue("revResult failed: ${revResult.exceptionOrNull()}", revResult.isSuccess)

        val emittedPlacements = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observePlacements(aliceUid).first { list -> list.any { it.id == plId } }
        }
        assertTrue(emittedPlacements.any { it.id == plId })

        val emittedReviews = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCollegeReviews(aliceUid).first { list -> list.any { it.id == revId } }
        }
        assertTrue(emittedReviews.any { it.id == revId })
    }

    @Test
    fun getCollegeById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val aliceRepo = ConsultancyRepository(firestore, auth)
        val docId = "col_${UUID.randomUUID().toString().take(8)}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createCollege(sampleCollege(docId)).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = ConsultancyRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getCollegeById(docId).getOrThrow()
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED for cross-user read")
        } catch (e: FirebaseFirestoreException) {
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, e.code)
        }
    }

    @Test
    fun observeColleges_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = ConsultancyRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeColleges("unauthenticated_uid").first()
            }
            fail("Expected exception for unauthenticated flow observation")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }

    @Test
    fun createAndObservePhase4Collections_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = ConsultancyRepository(firestore, auth)
        val dlId = "dl_${UUID.randomUUID().toString().take(8)}"
        val tskId = "tsk_${UUID.randomUUID().toString().take(8)}"
        val usrId = "usr_${UUID.randomUUID().toString().take(8)}"

        val dl = AdmissionDeadlineRecord(
            id = dlId,
            collegeId = "col_rvce",
            collegeName = "RV College of Engineering",
            courseName = "B.E. CSE",
            quotaCategory = "KCET / COMEDK",
            academicYear = "2026-27",
            applicationOpenDate = "2026-01-10",
            applicationDeadline = "2026-04-15",
            entranceExamDate = "2026-04-22",
            counsellingRound1Date = "2026-06-18",
            counsellingRound2Date = "2026-07-08",
            mopUpStrayRoundDate = "2026-07-28",
            documentVerificationDeadline = "2026-06-10",
            scholarshipDeadline = "2026-08-31",
            feePaymentWindow = "2026-06-20 to 2026-06-28",
            sourceUrl = "https://cetonline.karnataka.gov.in/kea/",
            retrievalDate = "2026-03-30",
            verificationStatus = "Verified",
            hasConflict = false,
            conflictDetails = "",
            isOverdueRefresh = false
        )
        val dlRes = withTimeout(DEFAULT_TIMEOUT_MS) { repository.createAdmissionDeadline(dl) }
        assertTrue("dlRes failed: ${dlRes.exceptionOrNull()}", dlRes.isSuccess)

        val tsk = TeamTaskRecord(
            id = tskId,
            title = "Resolve RVCE Fee Discrepancy",
            taskType = "Discrepancy Resolution",
            assignedToName = "Karthik Iyer",
            assignedToRole = "Fee Reviewer",
            priority = "Urgent",
            dueDate = "2026-04-02",
            linkedRecordType = "Fee Doc",
            linkedRecordId = "fdoc_1",
            linkedRecordName = "RVCE_Fee_Circular_2026.pdf",
            status = "In Progress",
            notes = "Verify VTU skill lab fee line item."
        )
        val tskRes = withTimeout(DEFAULT_TIMEOUT_MS) { repository.createTeamTask(tsk) }
        assertTrue("tskRes failed: ${tskRes.exceptionOrNull()}", tskRes.isSuccess)

        val usr = TeamMemberRecord(
            id = usrId,
            fullName = "Arjun Menon",
            email = "arjun.menon@eduintel.in",
            roleName = "Admin",
            department = "Platform Governance",
            isActive = true,
            permissionsSummary = "Full platform governance",
            lastActiveDisplay = "Online — Active Today"
        )
        val usrRes = withTimeout(DEFAULT_TIMEOUT_MS) { repository.createTeamMember(usr) }
        assertTrue("usrRes failed: ${usrRes.exceptionOrNull()}", usrRes.isSuccess)

        val emittedDeadlines = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeAdmissionDeadlines(aliceUid).first { list -> list.any { it.id == dlId } }
        }
        assertTrue(emittedDeadlines.any { it.id == dlId })

        val emittedTasks = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeTeamTasks(aliceUid).first { list -> list.any { it.id == tskId } }
        }
        assertTrue(emittedTasks.any { it.id == tskId })

        val emittedMembers = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeTeamMembers(aliceUid).first { list -> list.any { it.id == usrId } }
        }
        assertTrue(emittedMembers.any { it.id == usrId })
    }

    private companion object {
        const val ALICE_EMAIL = "alice@eduintel.test"
        const val BOB_EMAIL = "bob@eduintel.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
