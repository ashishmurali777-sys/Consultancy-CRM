-- =============================================================================
-- EDUINTEL PLATFORM — NORMALIZED POSTGRESQL SCHEMA & RLS POLICIES (PHASE 1 + 2)
-- Private Education Consultancy Intelligence Platform (Indian Higher Education)
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Role Enum for 6 Consultancy RBAC Tiers
CREATE TYPE consultancy_role AS ENUM (
  'Admin',
  'Senior Reviewer',
  'Fee Reviewer',
  'Researcher',
  'Counsellor',
  'Read-only Viewer'
);

-- 2. Verification Status Enum
CREATE TYPE verification_status AS ENUM (
  'Verified',
  'Institution-Claimed',
  'Outdated',
  'Unverified'
);

-- 3. Locked Application Settings (Mandatory Admission Enquiry Contact Footer)
CREATE TABLE app_settings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  enquiry_header TEXT NOT NULL DEFAULT 'ADMISSION ENQUIRIES' CHECK (enquiry_header = 'ADMISSION ENQUIRIES'),
  enquiry_phone TEXT NOT NULL DEFAULT '+91 70122 74141' CHECK (enquiry_phone = '+91 70122 74141'),
  is_locked BOOLEAN NOT NULL DEFAULT TRUE CHECK (is_locked = TRUE),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Colleges Table (Distinct Ownership, Institution Type & Degree-Awarding University)
CREATE TABLE colleges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 200),
  short_code TEXT NOT NULL CHECK (char_length(short_code) BETWEEN 1 AND 40),
  state TEXT NOT NULL,
  city TEXT NOT NULL,
  ownership TEXT NOT NULL CHECK (ownership IN ('Public/Government', 'Private Unaided', 'PPP')),
  institution_type TEXT NOT NULL CHECK (institution_type IN (
    'Central University',
    'State University',
    'Private University',
    'Deemed-to-be University',
    'Autonomous College',
    'Affiliated College',
    'Institution of National Importance'
  )),
  degree_awarding_university TEXT NOT NULL,
  affiliated_to TEXT DEFAULT '',
  established_year INTEGER NOT NULL CHECK (established_year BETWEEN 1800 AND 2030),
  website_url TEXT DEFAULT '',
  verification_status verification_status NOT NULL DEFAULT 'Unverified',
  naac_grade TEXT DEFAULT 'N/A',
  naac_cgpa NUMERIC(3,2) DEFAULT 0.00,
  nirf_rank INTEGER DEFAULT 0,
  regulators TEXT[] DEFAULT '{}',
  regulator_details_summary TEXT DEFAULT '',
  needs_refresh BOOLEAN NOT NULL DEFAULT FALSE,
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Courses Table (Indian Healthcare/Technical Nuances & Lateral Entry Tracking)
CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id UUID NOT NULL REFERENCES colleges(id) ON DELETE CASCADE,
  college_name TEXT NOT NULL,
  course_name TEXT NOT NULL,
  specialization TEXT DEFAULT '',
  stream TEXT NOT NULL,
  duration_years NUMERIC(3,1) NOT NULL,
  intake INTEGER NOT NULL CHECK (intake > 0),
  eligibility TEXT NOT NULL,
  entrance_exams TEXT[] NOT NULL DEFAULT '{}',
  is_lateral_entry BOOLEAN NOT NULL DEFAULT FALSE,
  annual_tuition_min_inr BIGINT NOT NULL DEFAULT 0,
  annual_tuition_max_inr BIGINT NOT NULL DEFAULT 0,
  quota_fees_summary TEXT DEFAULT '',
  regulatory_body TEXT NOT NULL,
  approval_status verification_status NOT NULL DEFAULT 'Unverified',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Fee Documents & Multimodal OCR Verification Table
CREATE TABLE fee_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id UUID REFERENCES colleges(id) ON DELETE SET NULL,
  college_name TEXT NOT NULL,
  course_name TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  quota_category TEXT NOT NULL,
  tuition_fee_annual_inr BIGINT NOT NULL DEFAULT 0,
  hostel_and_mess_annual_inr BIGINT NOT NULL DEFAULT 0,
  caution_deposit_inr BIGINT NOT NULL DEFAULT 0,
  other_charges_inr BIGINT NOT NULL DEFAULT 0,
  extracted_raw_summary TEXT NOT NULL,
  web_comparison_notes TEXT DEFAULT '',
  has_discrepancy BOOLEAN NOT NULL DEFAULT FALSE,
  discrepancy_details TEXT DEFAULT '',
  review_status TEXT NOT NULL CHECK (review_status IN (
    'Pending Review',
    'Verified',
    'Flagged Discrepancy',
    'Rejected'
  )),
  source_title TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Student Admissions Enquiries & Counselling Pipeline
CREATE TABLE enquiries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  target_stream TEXT NOT NULL,
  preferred_course TEXT NOT NULL,
  preferred_colleges TEXT DEFAULT '',
  entrance_exam_score TEXT DEFAULT '',
  budget_max_lakhs NUMERIC(6,2) NOT NULL DEFAULT 0.0,
  quota_preference TEXT NOT NULL,
  stage TEXT NOT NULL CHECK (stage IN (
    'New Enquiry',
    'Shortlisting',
    'Document Verification',
    'Counselling Applied',
    'Seat Allotted',
    'Enrolled'
  )),
  follow_up_due_today BOOLEAN NOT NULL DEFAULT FALSE,
  deadline_date TEXT DEFAULT '',
  counsellor_notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. Live Internet Research & Source Verification Queue (Module 3 & Module 15)
CREATE TABLE source_queue (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id TEXT NOT NULL,
  college_name TEXT NOT NULL,
  course_name TEXT DEFAULT '',
  research_target TEXT NOT NULL,
  target_field_key TEXT NOT NULL,
  current_stored_value TEXT NOT NULL,
  extracted_new_value TEXT NOT NULL,
  has_contradiction BOOLEAN NOT NULL DEFAULT FALSE,
  source_title TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN (
    'Official Website',
    'Government/Regulator Portal',
    'Counselling Authority',
    'Third-Party/Secondary',
    'Manual Document Required'
  )),
  academic_year TEXT NOT NULL,
  confidence_score INTEGER NOT NULL CHECK (confidence_score BETWEEN 0 AND 100),
  retrieved_at_iso TEXT NOT NULL,
  queue_status TEXT NOT NULL CHECK (queue_status IN (
    'Pending Approval',
    'Approved & Applied',
    'Rejected'
  )),
  reviewer_notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. 20-Point AI College Briefing Versions (Module 10)
CREATE TABLE college_briefing_versions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id TEXT NOT NULL,
  college_name TEXT NOT NULL,
  course_name TEXT NOT NULL,
  version_number INTEGER NOT NULL CHECK (version_number >= 1),
  version_label TEXT NOT NULL,
  sections_json TEXT NOT NULL,
  citations_list TEXT NOT NULL,
  reviewer_sign_off TEXT NOT NULL,
  enquiry_footer TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Immutable Consultancy Audit Logs
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action_type TEXT NOT NULL,
  target_entity TEXT NOT NULL,
  summary TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Placement & Career Outcome Intelligence (Module 6)
CREATE TABLE placements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id UUID REFERENCES colleges(id) ON DELETE CASCADE,
  college_name TEXT NOT NULL,
  course_name TEXT NOT NULL,
  specialization TEXT NOT NULL DEFAULT '',
  academic_year TEXT NOT NULL DEFAULT '2025-26',
  scope_type TEXT NOT NULL CHECK (scope_type IN ('Institution-Wide', 'Course-Specific')),
  level_type TEXT NOT NULL CHECK (level_type IN ('UG', 'PG')),
  offer_scope TEXT NOT NULL CHECK (offer_scope IN ('Domestic', 'International')),
  highest_package_lpa NUMERIC(8,2) NOT NULL DEFAULT -1,
  average_package_lpa NUMERIC(8,2) NOT NULL DEFAULT -1,
  median_package_lpa NUMERIC(8,2) NOT NULL DEFAULT -1,
  placement_rate_percent NUMERIC(6,2) NOT NULL DEFAULT -1,
  eligible_students INTEGER NOT NULL DEFAULT -1,
  participating_students INTEGER NOT NULL DEFAULT -1,
  placed_students INTEGER NOT NULL DEFAULT -1,
  total_recruiters INTEGER NOT NULL DEFAULT -1,
  internship_stipend_monthly_inr BIGINT NOT NULL DEFAULT -1,
  top_recruiters TEXT NOT NULL DEFAULT 'Not Publicly Reported',
  common_job_roles TEXT NOT NULL DEFAULT 'Not Publicly Reported',
  source_citation TEXT NOT NULL DEFAULT 'NIRF / Official Placement Report',
  verification_status TEXT NOT NULL CHECK (verification_status IN ('Verified', 'Institution-Claimed', 'Outdated', 'Unverified')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. College Reviews & 7-Dimension Quality Analysis (Module 7)
CREATE TABLE college_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id UUID REFERENCES colleges(id) ON DELETE CASCADE,
  college_name TEXT NOT NULL,
  course_focus TEXT NOT NULL DEFAULT 'All Programmes',
  review_category TEXT NOT NULL CHECK (review_category IN ('Public Third-Party Review', 'Internal Consultancy Observation')),
  source_name TEXT NOT NULL,
  overall_rating NUMERIC(3,2) NOT NULL CHECK (overall_rating >= 0 AND overall_rating <= 5.0),
  review_count INTEGER NOT NULL DEFAULT 1,
  retrieved_date TEXT NOT NULL,
  positive_themes TEXT NOT NULL,
  negative_themes TEXT NOT NULL,
  recurring_complaints TEXT NOT NULL,
  academic_experience_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  infrastructure_labs_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  faculty_quality_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  hostel_mess_rating NUMERIC(3,2) NOT NULL DEFAULT 3.5,
  placement_support_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  clinical_practical_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  campus_life_support_rating NUMERIC(3,2) NOT NULL DEFAULT 4.0,
  dimension_evidence_summary TEXT NOT NULL DEFAULT '',
  is_contextual_ai_summary BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. Admission Calendar, Deadlines & Alerts (Module 8)
CREATE TABLE admission_deadlines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  college_id UUID REFERENCES colleges(id) ON DELETE CASCADE,
  college_name TEXT NOT NULL,
  course_name TEXT NOT NULL,
  quota_category TEXT NOT NULL DEFAULT 'Government / Merit',
  academic_year TEXT NOT NULL DEFAULT '2026-27',
  application_open_date TEXT NOT NULL,
  application_deadline TEXT NOT NULL,
  entrance_exam_date TEXT NOT NULL,
  counselling_round1_date TEXT NOT NULL,
  counselling_round2_date TEXT NOT NULL,
  mop_up_stray_date TEXT NOT NULL,
  doc_verification_deadline TEXT NOT NULL,
  scholarship_deadline TEXT NOT NULL,
  fee_payment_window TEXT NOT NULL,
  source_url TEXT NOT NULL,
  retrieval_date TEXT NOT NULL,
  verification_status TEXT NOT NULL CHECK (verification_status IN ('Verified', 'Institution-Claimed', 'Outdated', 'Unverified')),
  has_conflict BOOLEAN NOT NULL DEFAULT FALSE,
  conflict_details TEXT NOT NULL DEFAULT '',
  is_overdue_refresh BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. Collaborative Team Tasks & Follow-ups (Module 12)
CREATE TABLE team_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  task_category TEXT NOT NULL CHECK (task_category IN ('Research Job', 'Fee Document Review', 'Discrepancy Resolution', 'Student Counselling Follow-up')),
  priority TEXT NOT NULL CHECK (priority IN ('Low', 'Medium', 'High', 'Urgent')),
  status TEXT NOT NULL CHECK (status IN ('To Do', 'In Progress', 'Blocked', 'Completed')),
  due_date TEXT NOT NULL,
  assigned_to_name TEXT NOT NULL,
  assigned_to_role TEXT NOT NULL,
  linked_record_type TEXT NOT NULL CHECK (linked_record_type IN ('College', 'Fee Doc', 'Student', 'Deadline')),
  linked_record_id TEXT NOT NULL DEFAULT '',
  linked_record_name TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. Team Management & RBAC Directory (Module 14)
CREATE TABLE team_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  role_code TEXT NOT NULL CHECK (role_code IN ('Admin', 'Senior Reviewer', 'Fee Reviewer', 'Researcher', 'Counsellor', 'Read-only Viewer')),
  department TEXT NOT NULL DEFAULT 'Admissions & Research',
  assigned_region TEXT NOT NULL DEFAULT 'Pan-India (Karnataka / TN / Delhi)',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_active_summary TEXT NOT NULL DEFAULT 'Active today',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Row-Level Security (RLS)
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE colleges ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE fee_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE enquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE source_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE college_briefing_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE placements ENABLE ROW LEVEL SECURITY;
ALTER TABLE college_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE admission_deadlines ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner isolation on app_settings" ON app_settings
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on colleges" ON colleges
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on courses" ON courses
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on fee_documents" ON fee_documents
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on enquiries" ON enquiries
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on source_queue" ON source_queue
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on college_briefing_versions" ON college_briefing_versions
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on audit_logs" ON audit_logs
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on placements" ON placements
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on college_reviews" ON college_reviews
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on admission_deadlines" ON admission_deadlines
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on team_tasks" ON team_tasks
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Owner isolation on team_members" ON team_members
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);


